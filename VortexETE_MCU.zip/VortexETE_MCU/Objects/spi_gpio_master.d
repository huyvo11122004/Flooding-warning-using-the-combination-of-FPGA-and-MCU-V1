./objects/spi_gpio_master.o: firmware\spi_gpio_master.c \
  firmware\spi0_master.h
