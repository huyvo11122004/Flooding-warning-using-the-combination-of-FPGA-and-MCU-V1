./objects/main.o: firmware\main.c firmware\rs485_sn32f407.h \
  firmware\rs485.h firmware\app_config.h firmware\app_time.h \
  firmware\rain.h firmware\sim_uart.h firmware\sim_a7680c.h \
  firmware\telemetry.h firmware\dht11.h firmware\spi0_master.h \
  firmware\fpga_decision.h firmware\fpga_spi.h firmware\txs_spi_p21.h \
  firmware\rs485_sn32f407_config.h
