./objects/fpga_decision.o: firmware\fpga_decision.c \
  firmware\fpga_decision.h firmware\fpga_spi.h firmware\spi0_master.h \
  firmware\sim_a7680c.h firmware\app_config.h
