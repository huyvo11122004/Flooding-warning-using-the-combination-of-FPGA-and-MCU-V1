./objects/rs485_sn32f407.o: firmware\rs485_sn32f407.c \
  firmware\rs485_sn32f407.h firmware\rs485.h \
  firmware\rs485_sn32f407_config.h firmware\sn32_time_math.h
