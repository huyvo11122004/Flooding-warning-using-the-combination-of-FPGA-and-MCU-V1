./objects/telemetry.o: firmware\telemetry.c firmware\telemetry.h \
  firmware\rs485.h firmware\dht11.h firmware\app_config.h
