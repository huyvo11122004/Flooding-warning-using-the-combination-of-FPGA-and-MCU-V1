./objects/dht11_sn32f407.o: firmware\dht11_sn32f407.c firmware\dht11.h \
  firmware\app_config.h firmware\rs485.h
