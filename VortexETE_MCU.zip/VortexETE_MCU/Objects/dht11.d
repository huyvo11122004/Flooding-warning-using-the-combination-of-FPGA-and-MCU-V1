./objects/dht11.o: firmware\dht11.c firmware\dht11.h \
  firmware\app_config.h
