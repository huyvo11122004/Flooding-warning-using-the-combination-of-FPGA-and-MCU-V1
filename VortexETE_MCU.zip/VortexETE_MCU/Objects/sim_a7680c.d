./objects/sim_a7680c.o: firmware\sim_a7680c.c firmware\sim_a7680c.h \
  firmware\sim_uart.h firmware\app_config.h
