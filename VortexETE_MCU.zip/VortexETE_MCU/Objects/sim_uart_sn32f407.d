./objects/sim_uart_sn32f407.o: firmware\sim_uart_sn32f407.c \
  firmware\sim_uart.h firmware\sim_baud.h firmware\rs485.h \
  firmware\rs485_sn32f407_config.h
