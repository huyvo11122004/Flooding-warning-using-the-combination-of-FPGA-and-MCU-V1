./objects/rs485.o: firmware\rs485.c firmware\rs485.h \
  firmware\app_config.h
