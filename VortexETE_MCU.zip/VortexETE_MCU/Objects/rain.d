./objects/rain.o: firmware\rain.c firmware\rain.h firmware\app_config.h
