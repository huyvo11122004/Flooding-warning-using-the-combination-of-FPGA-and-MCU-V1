./objects/fpga_spi.o: firmware\fpga_spi.c firmware\fpga_spi.h \
  firmware\spi0_master.h
