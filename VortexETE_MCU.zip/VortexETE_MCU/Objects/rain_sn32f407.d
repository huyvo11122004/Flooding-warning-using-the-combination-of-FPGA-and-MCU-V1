./objects/rain_sn32f407.o: firmware\rain_sn32f407.c firmware\rain.h \
  firmware\dht11.h firmware\app_config.h firmware\app_time.h
