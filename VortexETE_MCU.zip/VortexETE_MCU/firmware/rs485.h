#ifndef RS485_H
#define RS485_H
#include <stdint.h>
#include <stddef.h>

#define RS485_MAX_REGISTERS 16u
typedef enum {
    RS485_OK = 0,
    RS485_ERR_ARGUMENT,
    RS485_ERR_NOT_READY,
    RS485_ERR_TIMEOUT,
    RS485_ERR_BUS_BUSY,
    RS485_ERR_UART,
    RS485_ERR_LENGTH,
    RS485_ERR_CRC,
    RS485_ERR_ADDRESS,
    RS485_ERR_FUNCTION,
    RS485_ERR_GAP,
    RS485_ERR_EXCEPTION
} RS485_Status;

/* Configure timing AFTER the UART has been configured with the same settings. */
RS485_Status RS485_ConfigureTiming(uint32_t baud, uint8_t bits_per_character);
uint16_t RS485_CRC16(const uint8_t *data, size_t length);
RS485_Status RS485_ReadRegisters(uint8_t address, uint8_t function,
    uint16_t first_register, uint16_t count, uint16_t *values,
    uint8_t *exception_code, uint32_t timeout_ms);
/* Safe replacements: output arguments change only on success. Raw units. */
RS485_Status getRS485(uint16_t values[2]);
RS485_Status getWind(uint16_t *value);
RS485_Status getWind_huong(uint16_t *value);
RS485_Status getWater_level(uint16_t *value);

const char *RS485_StatusText(RS485_Status status);

/* Last WIND_MODBUS_ID transaction only. Other sensor reads do not overwrite.
 * ready=0 while capture is in progress; ready=1 after returning to caller. */
enum {
    WIND_DIAG_CHECK=1,WIND_DIAG_QUIET=2,WIND_DIAG_TX=3,
    WIND_DIAG_RX=4,WIND_DIAG_VALIDATE=5,WIND_DIAG_DONE=6
};
extern volatile uint32_t wind_diag_ready,wind_diag_attempts,wind_diag_phase;
extern volatile uint32_t wind_diag_status,wind_diag_tx_status;
extern volatile uint32_t wind_diag_tx_len,wind_diag_rx_count,wind_diag_uart_error;
extern volatile uint32_t wind_diag_exception;
extern volatile uint32_t wind_diag_tx[8],wind_diag_rx[16];

/* Port contract: dedicated UART, one caller, interrupts enabled. */
uint32_t RS485_PortNowUs(void);
int RS485_PortIsReady(void);
int RS485_PortReceiveByte(uint8_t *byte); /* 1=byte, 0=none, -1=UART error */
RS485_Status RS485_PortTransmit(const uint8_t *data, size_t length,
    uint32_t timeout_us); /* Must finish the stop bit, then release DE. */
#endif
