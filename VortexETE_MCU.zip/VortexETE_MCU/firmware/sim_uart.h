#ifndef SIM_UART_H
#define SIM_UART_H
#include <stdint.h>
int SIM_UART_Init(uint32_t hclk,uint32_t baud);
int SIM_UART_Read(uint8_t *byte); /* 1 data,0 empty,-1 transport error */
int SIM_UART_Send(const char *cmd);
extern volatile uint32_t sim_uart_overflows,sim_uart_line_errors;
extern volatile uint32_t sim_actual_baud,sim_oversampling,sim_init_error;
#endif
