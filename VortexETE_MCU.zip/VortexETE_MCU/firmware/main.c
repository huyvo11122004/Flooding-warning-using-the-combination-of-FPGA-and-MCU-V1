#include "rs485_sn32f407.h"
#include "app_config.h"
#include "app_time.h"
#include "rain.h"
#include "sim_uart.h"
#include "sim_a7680c.h"
#include "telemetry.h"
#include "dht11.h"
#include "spi0_master.h"
#include "fpga_decision.h"
#include "txs_spi_p21.h"
volatile uint32_t build_tag; /* Assigned at runtime so the linker retains Watch symbol. */
extern uint32_t SystemCoreClock;
extern void SystemCoreClockUpdate(void);
volatile uint32_t app_ms;
volatile uint32_t spi_backend_seen,txs_p21_initialized,txs_p21_level;
volatile RS485_Status init_status,device01_status,wind_status,direction_status,water_status;
volatile uint16_t device01_register04,device01_register05,wind_raw,direction_raw,water_raw;
volatile uint32_t water_sample_at_ms,water_sample_valid;
volatile uint32_t completed_cycles,rain_pulses;
volatile uint64_t rain_total_um,rain_hour_um,rain_day_um;
volatile uint32_t rain_hour_valid,rain_day_valid;
volatile uint32_t rain_hw_ready;
static RainSnapshot rain_snapshot;
volatile int rain_calibrated,sim_hw_ready;
volatile uint32_t telemetry_queued,telemetry_build_errors;
char telemetry_json[SIM_PAYLOAD_CAPACITY]; /* inspect as a string in Watch */
void SysTick_Handler(void)
{
    RS485_SN32F407_Tick1ms();
    ++app_ms;
}
static void service(void)
{
    txs_p21_level=TXS_P21_ReadLevel();
    Rain_GetSnapshot(app_ms,&rain_snapshot);
    rain_hour_valid=(uint32_t)rain_snapshot.hour_valid;rain_day_valid=(uint32_t)rain_snapshot.day_valid;
    rain_hour_um=(uint64_t)rain_snapshot.hour_pulses*RAIN_UM_PER_TIP;
    rain_day_um=(uint64_t)rain_snapshot.day_pulses*RAIN_UM_PER_TIP;
    rain_pulses=Rain_Pulses();
    rain_calibrated=Rain_Calibrated();
    rain_total_um=Rain_TotalUm(); /* unknown when rain_calibrated==0 */
    FPGA_UpdateSensorInputs(water_sample_at_ms,water_raw,(int)water_sample_valid,
                            Rain_QuietMs(app_ms),(int)rain_hw_ready);
    if(!DHT11_IsBusy()){
        if(sim_hw_ready)SIM_Task(app_ms);
        FPGA_DecisionTask(app_ms);
    }
}
int main(void){
#if !CAMERA_TEST_WITHOUT_SENSORS
    uint16_t wind,direction,water;
#endif
    uint32_t wait_start,last_publish=0;
    TelemetrySample sample;
    SIM_Health sim_health;
    build_tag=0x57443134u; /* WD14: YJ-FS ID5 transaction diagnostics */
    SystemCoreClockUpdate();
    TXS_P21_InitHigh();
    txs_p21_initialized=1;txs_p21_level=TXS_P21_ReadLevel();
    init_status=RS485_SN32F407_Init(SystemCoreClock,SENSOR_BAUD,
                                   SENSOR_PARITY,SENSOR_STOP_BITS);
    if(init_status!=RS485_OK)for(;;){}
    Rain_ResetAt(app_ms);
    rain_hw_ready=(uint32_t)Rain_HWInit();
    DHT11_HWInit();
    DHT11_Init(app_ms);
    /* Complete the one-time Flash sleep delay before enabling modem RX, so
     * the UART queue is not left unattended during the startup wait. */
    SN32_SPI_Init(SystemCoreClock);
    spi_backend_seen=spi0_backend;
    FPGA_DecisionInit(SN32_SPI_Bus(),app_ms);
    sim_hw_ready=SIM_UART_Init(SystemCoreClock,SIM_UART_BAUD);
    SIM_Init();
    for(;;) {
        service();
#if CAMERA_TEST_WITHOUT_SENSORS
        /* No requests to absent RS485 sensors during camera bring-up.
         * Preserve missing-data status; never fabricate water/depth values. */
        device01_status=wind_status=direction_status=water_status=RS485_ERR_NOT_READY;
        water_sample_valid=0;
        service();
#else
        /* Old generic ID1/register4 probe is disabled: ID1 is now water.
         * getRS485() is retained for diagnostics but not polled blindly. */
        device01_status=RS485_ERR_NOT_READY;
        wind_status=getWind(&wind);
        if(wind_status==RS485_OK)wind_raw=wind;
        service();
        direction_status=getWind_huong(&direction);
        if(direction_status==RS485_OK)direction_raw=direction;
        service();
        water_status=getWater_level(&water);
        if(water_status==RS485_OK)water_raw=water;
        water_sample_at_ms=app_ms;
        water_sample_valid=water_status==RS485_OK;
        service();
#endif
        ++completed_cycles;
        if(completed_cycles==1u||
           (uint32_t)(app_ms-last_publish)>=MQTT_PUBLISH_INTERVAL_MS) {
            last_publish=app_ms;
            sample.uptime_ms=app_ms;
            Rain_GetSnapshot(sample.uptime_ms,&rain_snapshot);
            sample.rain_pulses=Rain_Pulses();
            sample.rain_hour_pulses=rain_snapshot.hour_pulses;
            sample.rain_day_pulses=rain_snapshot.day_pulses;
            sample.rain_hour_elapsed_s=rain_snapshot.hour_elapsed_ms/1000u;
            sample.rain_day_elapsed_s=rain_snapshot.day_elapsed_ms/1000u;
            sample.rain_hour_valid=rain_snapshot.hour_valid;sample.rain_day_valid=rain_snapshot.day_valid;
            sample.water=water_raw;sample.wind=wind_raw;sample.direction=direction_raw;
            sample.water_status=water_status;sample.wind_status=wind_status;
            sample.direction_status=direction_status;
            sample.temperature_x10=dht_temperature_x10;
            sample.humidity_x10=dht_humidity_x10;
            sample.dht_valid=DHT11_IsFresh(app_ms);
            sample.dht_status=dht_status;
            SIM_ReadHealth(app_ms,&sim_health);
            sample.sim_voltage_mv=sim_health.voltage_mv;
            sample.sim_signal_percent=sim_health.signal_percent;
            sample.sim_voltage_valid=sim_health.voltage_valid;
            sample.sim_signal_valid=sim_health.signal_valid;
            if(Telemetry_Build(telemetry_json,sizeof telemetry_json,&sample)&&
               SIM_SetTelemetry(telemetry_json))++telemetry_queued;
            else ++telemetry_build_errors;
        }
        if(!RS485_PortIsReady()) {
            init_status=RS485_SN32F407_Init(SystemCoreClock,SENSOR_BAUD,
                                           SENSOR_PARITY,SENSOR_STOP_BITS);
            if(init_status!=RS485_OK)for(;;){}
        }
        /* Rain and UART0 RX interrupts continue throughout Modbus waits.
         * Service parser while waiting instead of a blocking one-second delay. */
        wait_start=app_ms;
        while((uint32_t)(app_ms-wait_start)<1000u||DHT11_IsBusy()) {
            /* No blocking Modbus or SIM TX while the DHT start pulse is active.
             * UART RX, rain and DHT edge IRQs all remain enabled. */
            DHT11_Task(app_ms);
            service();
        }
    }
}
