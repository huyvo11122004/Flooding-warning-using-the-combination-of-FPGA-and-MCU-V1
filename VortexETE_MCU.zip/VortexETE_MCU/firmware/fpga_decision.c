#include "fpga_decision.h"
#include "spi0_master.h"
#include "sim_a7680c.h"
#include "app_config.h"
#include <stdio.h>
volatile uint32_t fpga_stage,fpga_results_received,fpga_decisions_sent;
volatile uint32_t fpga_frames_failed,fpga_frame_id,fpga_bytes_read;
volatile uint32_t fpga_water_pixels,fpga_roi_pixels,fpga_water_percent_x100;
volatile uint32_t fpga_level,fpga_result_valid,fpga_last_ok_ms;
volatile uint32_t flash_sleep_request_sent;
volatile int32_t fpga_last_error,flash_sleep_result;
volatile uint32_t camera_enabled,camera_gate_reason,camera_test_mode;
volatile uint32_t camera_fallback_active,fpga_result_from_fallback;
volatile uint64_t camera_water_milli_mm;
volatile uint32_t camera_rain_quiet_ms;
static uint32_t water_sample_at;
static unsigned water_good,rain_good;
enum {CHECK_LINK=FPGA_STAGE_CHECK_LINK,WAIT_PERIOD=FPGA_STAGE_WAIT_PERIOD,
      WAIT_SCAN=FPGA_STAGE_WAIT_SCAN,BACKOFF=FPGA_STAGE_BACKOFF};
volatile uint32_t fpga_roi_skipped,fpga_whole_water_pixels;
volatile uint32_t fpga_status_register,fpga_command_status,fpga_error_status;
volatile uint32_t fpga_status_polls,fpga_scan_requests;
volatile uint32_t fpga_scan_elapsed_ms,fpga_last_scan_ms,fpga_wait_remaining_ms;
static const FPGA_Bus *link;
static uint32_t last,scan_at,poll_at,version,queued_version,token,waiting_token;
static unsigned requested,dirty,scan_fallback;
static char json[SIM_APP_PAYLOAD_CAPACITY];
static void invalidate(int error)
{
    fpga_last_error=error;fpga_result_valid=0;fpga_level=FPGA_LEVEL_UNKNOWN;
    ++version;dirty=1;
}
static void failed(uint32_t now,int error)
{
    fpga_error_status=fpga_status_register;
    if(fpga_stage==WAIT_SCAN)fpga_last_scan_ms=(uint32_t)(now-scan_at);
    invalidate(error);++fpga_frames_failed;
    last=now;fpga_stage=BACKOFF;
}
void FPGA_RequestScan(void){requested=1;}
void FPGA_UpdateSensorInputs(uint32_t at,uint16_t raw,int water_valid,
                             uint32_t rain_quiet_ms,int rain_valid)
{
    water_sample_at=at;
    water_good=water_valid && WATER_MILLI_MM_PER_RAW!=0u;
    rain_good=rain_valid!=0;
    camera_water_milli_mm=(uint64_t)raw*WATER_MILLI_MM_PER_RAW;
    camera_rain_quiet_ms=rain_quiet_ms;
}
static void update_gate(uint32_t now)
{
    unsigned was_enabled=camera_enabled,was_fallback=camera_fallback_active;
    camera_fallback_active=0;
#if CAMERA_TEST_WITHOUT_SENSORS
    (void)now;
    camera_gate_reason=CAMERA_GATE_TEST_MODE;
#else
    if(!water_good){
        camera_fallback_active=CAMERA_WATER_FAILOVER_ENABLE ? 1u : 0u;
        camera_gate_reason=camera_fallback_active ? CAMERA_GATE_WATER_FAILOVER : CAMERA_GATE_WATER_INVALID;
    }else if((uint32_t)(now-water_sample_at)>=CAMERA_SENSOR_STALE_MS){
        camera_fallback_active=CAMERA_WATER_FAILOVER_ENABLE ? 1u : 0u;
        camera_gate_reason=camera_fallback_active ? CAMERA_GATE_STALE_FAILOVER : CAMERA_GATE_WATER_STALE;
    }
    else if(!rain_good)camera_gate_reason=CAMERA_GATE_RAIN_INVALID;
    else if(camera_rain_quiet_ms<CAMERA_RAIN_QUIET_MS)
        camera_gate_reason=CAMERA_GATE_RAIN_RECENT;
    else if(camera_water_milli_mm<=CAMERA_WATER_HIGH_THRESHOLD_MILLI_MM)
        camera_gate_reason=CAMERA_GATE_WATER_LOW;
    else camera_gate_reason=CAMERA_GATE_ALLOWED;
#endif
    camera_enabled=CAMERA_TEST_WITHOUT_SENSORS || camera_fallback_active || camera_gate_reason==CAMERA_GATE_ALLOWED;
    if(!camera_enabled)requested=0;
    else if(!was_enabled || (!was_fallback && camera_fallback_active))requested=1; /* scan on permission/fallback entry */
}
void FPGA_DecisionInit(const FPGA_Bus *bus,uint32_t now)
{
    link=bus;fpga_stage=CHECK_LINK;camera_fallback_active=fpga_result_from_fallback=scan_fallback=0;
    camera_test_mode=CAMERA_TEST_WITHOUT_SENSORS ? 1u : 0u;
    fpga_status_register=fpga_command_status=fpga_error_status=0;
    fpga_status_polls=fpga_scan_requests=0;
    fpga_scan_elapsed_ms=fpga_last_scan_ms=fpga_wait_remaining_ms=0;fpga_results_received=fpga_decisions_sent=0;
    fpga_frames_failed=fpga_frame_id=fpga_bytes_read=0;
    fpga_water_pixels=fpga_roi_pixels=fpga_water_percent_x100=fpga_last_ok_ms=0;
    fpga_roi_skipped=fpga_whole_water_pixels=0;
    fpga_result_valid=0;fpga_level=FPGA_LEVEL_UNKNOWN;fpga_last_error=0;
    last=now;token=waiting_token=0;version=1;dirty=1;requested=0;
    camera_enabled=water_good=rain_good=0;water_sample_at=now;
    camera_gate_reason=CAMERA_GATE_WATER_INVALID;
    camera_water_milli_mm=0;camera_rain_quiet_ms=0;
    flash_sleep_request_sent=0;flash_sleep_result=FPGA_ERR_ARGUMENT;
    if(!link||!link->select||!link->transfer)return;
    /* Proven shared Puya Flash workaround: B9, separate CS frame, startup wait.
     * This flag confirms transmission only; the Flash does not ACK B9. */
    link->select(link->context,1);
    (void)link->transfer(link->context,0xB9);
    link->select(link->context,0);
    flash_sleep_result=link->error&&link->error(link->context)?FPGA_ERR_BACKEND:FPGA_OK;
    SN32_SPI_Pause();flash_sleep_request_sent=flash_sleep_result==FPGA_OK;
}
static void publish(uint32_t now)
{
    static const char *const names[]={"NORMAL","WARNING","CRITICAL"};
    char topic[96],decision[12],coverage[20];int n,state;
    if(waiting_token){
        state=SIM_PublishState(waiting_token);
        if(state==0)return;
        if(state>0){++fpga_decisions_sent;if(queued_version==version)dirty=0;}
        waiting_token=0;
    }
    if(!dirty||!sim_mqtt_connected)return;
    if(fpga_result_valid){
        (void)snprintf(decision,sizeof decision,"%lu",(unsigned long)fpga_level);
        (void)snprintf(coverage,sizeof coverage,"%lu.%02lu",
          (unsigned long)(fpga_water_percent_x100/100u),(unsigned long)(fpga_water_percent_x100%100u));
    }else{
        (void)snprintf(decision,sizeof decision,"null");
        (void)snprintf(coverage,sizeof coverage,"null");
    }
    /* Old web field names; unknown depth/confidence stay JSON null.
     * Compact v13 JSON fits the modem's independent 511-byte application slot. */
    n=snprintf(json,sizeof json,
      "{\"v\":13,\"device_id\":%lu,\"valid\":%s,\"frame_id\":%lu,\"sample_age_ms\":%lu,"
      "\"road_condition\":%s,\"flood_level\":%s%s%s,\"water_coverage_percent\":%s,"
      "\"estimated_water_level_cm\":null,\"confidence\":null,\"mcu_verification\":\"%s\","
      "\"decision\":%s,\"water_pixels\":%lu,\"roi_pixels\":%lu,\"whole_water_pixels\":%lu,"
      "\"roi_status\":\"%s\",\"water_sensor_fallback\":%s,\"error\":%ld}",
      (unsigned long)MQTT_DEVICE_ID,fpga_result_valid?"true":"false",
      (unsigned long)fpga_frame_id,(unsigned long)(now-fpga_last_ok_ms),
      fpga_result_valid?(fpga_level==FPGA_LEVEL_NORMAL?"\"DRY\"":"\"FLOODED\""):"null",
      fpga_result_valid?"\"":"",fpga_result_valid?names[fpga_level]:"null",fpga_result_valid?"\"":"",coverage,
      fpga_result_valid?"CRC_OK":"INVALID",decision,
      (unsigned long)fpga_water_pixels,(unsigned long)fpga_roi_pixels,(unsigned long)fpga_whole_water_pixels,
      fpga_result_valid?(fpga_roi_skipped?"skipped_no_water":"computed"):"invalid",
      fpga_result_valid&&fpga_result_from_fallback?"true":"false",(long)fpga_last_error);
    if(n<=0||(size_t)n>=sizeof json){fpga_last_error=FPGA_ERR_ARGUMENT;return;}
    n=snprintf(topic,sizeof topic,"vortexete/station/%lu/fpga",(unsigned long)MQTT_DEVICE_ID);
    if(n<=0||(size_t)n>=sizeof topic)return;
    ++token;if(!token)++token;
    if(SIM_QueuePublish(topic,json,token)){waiting_token=token;queued_version=version;}
}
void FPGA_DecisionTask(uint32_t now)
{
    FPGA_Status s;FPGA_Result result;uint32_t interval,elapsed;uint8_t status_byte,command_byte;
    update_gate(now);
    fpga_wait_remaining_ms=0;
    if(fpga_stage==WAIT_SCAN)fpga_scan_elapsed_ms=(uint32_t)(now-scan_at);
    if(!link||flash_sleep_result!=FPGA_OK)return;
    if(fpga_result_valid&&(uint32_t)(now-fpga_last_ok_ms)>=FPGA_RESULT_STALE_MS)
        invalidate(FPGA_ERR_NOT_READY);
    switch(fpga_stage){
    case CHECK_LINK:
        s=FPGA_TestLink(link);if(s!=FPGA_OK){failed(now,s);break;}
        s=FPGA_Command(link,FPGA_CMD_ACK);
        if(s!=FPGA_OK){failed(now,s);break;}
        requested=1;fpga_stage=WAIT_PERIOD;break;
    case WAIT_PERIOD:
        if(!camera_enabled)break;
#if CAMERA_TEST_WITHOUT_SENSORS
        interval=CAMERA_TEST_INTERVAL_MS;
#else
        interval=fpga_level==FPGA_LEVEL_CRITICAL?FPGA_CRITICAL_INTERVAL_MS:
                 fpga_level==FPGA_LEVEL_WARNING?FPGA_WARNING_INTERVAL_MS:FPGA_NORMAL_DEMO_INTERVAL_MS;
        if(camera_fallback_active && (!interval || interval>CAMERA_FALLBACK_INTERVAL_MS))
            interval=CAMERA_FALLBACK_INTERVAL_MS;
#endif
        if(!requested){
            elapsed=(uint32_t)(now-last);
            if(!interval)break; /* event-only when configured as zero */
            if(elapsed<interval){fpga_wait_remaining_ms=interval-elapsed;break;}
        }
        s=FPGA_Command(link,FPGA_CMD_START);if(s!=FPGA_OK){failed(now,s);break;}
        requested=0;scan_at=poll_at=now;fpga_scan_elapsed_ms=0;scan_fallback=camera_fallback_active;
        ++fpga_scan_requests;fpga_stage=WAIT_SCAN;break;
    case WAIT_SCAN:
        if((uint32_t)(now-scan_at)>=FPGA_SCAN_TIMEOUT_MS){failed(now,FPGA_ERR_NOT_READY);break;}
        if((uint32_t)(now-poll_at)<FPGA_RESULT_POLL_MS)break;
        poll_at=now;
        s=FPGA_ReadStatus(link,&status_byte,&command_byte);fpga_bytes_read+=8;
        ++fpga_status_polls;fpga_status_register=status_byte;fpga_command_status=command_byte;
        if(s!=FPGA_OK){failed(now,s);break;}
        if(!(status_byte&FPGA_STATUS_READY)){
            if(status_byte&FPGA_STATUS_ERROR)failed(now,FPGA_ERR_STATE);
            break;
        }
        /* The SPI adapter advertises READY only after latching and CRC.
         * Require BUSY to clear before reading the held 60-byte record. */
        if(status_byte&FPGA_STATUS_BUSY)break;
        s=FPGA_GetResult(link,&result);fpga_bytes_read+=60;
        fpga_status_register=result.status;fpga_command_status=result.command_status;
        if(s==FPGA_ERR_NOT_READY)break;
        if(s!=FPGA_OK){failed(now,s);break;}
        if(fpga_results_received&&result.frame_id==fpga_frame_id){failed(now,FPGA_ERR_CHANGED);break;}
        s=FPGA_Command(link,FPGA_CMD_ACK);if(s!=FPGA_OK){failed(now,s);break;}
        fpga_frame_id=result.frame_id;fpga_water_pixels=result.water_pixels;fpga_roi_pixels=result.roi_pixels;
        fpga_result_from_fallback=scan_fallback;
        fpga_roi_skipped=result.roi_skipped;fpga_whole_water_pixels=result.whole_water;
        fpga_water_percent_x100=result.coverage_basis_points; // authoritative FPGA result
        fpga_level=result.decision;fpga_result_valid=1;fpga_last_error=0;
        fpga_last_scan_ms=(uint32_t)(now-scan_at);
        fpga_last_ok_ms=last=now;++fpga_results_received;++version;dirty=1;fpga_stage=WAIT_PERIOD;break;
    case BACKOFF:
        elapsed=(uint32_t)(now-last);
        if(elapsed>=FPGA_RETRY_BACKOFF_MS)fpga_stage=CHECK_LINK;
        else fpga_wait_remaining_ms=FPGA_RETRY_BACKOFF_MS-elapsed;
        break;
    default:failed(now,FPGA_ERR_STATE);break;
    }
    publish(now);
}
