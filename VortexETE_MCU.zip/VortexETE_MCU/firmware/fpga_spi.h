#ifndef FPGA_SPI_H
#define FPGA_SPI_H
#include <stdint.h>
#include <stddef.h>

#include "spi0_master.h"
typedef SPI_Bus FPGA_Bus;

typedef enum {
    FPGA_OK=0, FPGA_ERR_ARGUMENT=-1, FPGA_ERR_ID=-2,
    FPGA_ERR_ECHO=-3, FPGA_ERR_NOT_READY=-4, FPGA_ERR_STATE=-5,
    FPGA_ERR_CRC=-6, FPGA_ERR_CHANGED=-7, FPGA_ERR_BACKEND=-8
} FPGA_Status;

typedef struct {
    uint8_t capabilities,status,command_status;
    uint32_t frame_id,water_pixels,roi_pixels,whole_water;
    uint16_t width,height,result_crc,coverage_basis_points;
    uint8_t warning_percent,critical_percent,decision,source_schema,roi_skipped;
} FPGA_Result;
#define FPGA_LEVEL_NORMAL 0u
#define FPGA_LEVEL_WARNING 1u
#define FPGA_LEVEL_CRITICAL 2u
#define FPGA_LEVEL_UNKNOWN 3u

#define FPGA_STATUS_READY 1u
#define FPGA_STATUS_BUSY 2u
#define FPGA_STATUS_ERROR 4u
#define FPGA_STATUS_INITIALIZED 8u
#define FPGA_CMD_START 1u
#define FPGA_CMD_ACK 2u
#define FPGA_CMD_CLEAR_ERROR 3u

/* V3 diagnostics: 32-bit snapshots remain readable after the local frame ends.
 * ready=1 means all six scratch patterns were read; inspect error_mask/results.
 * A set bit i in error_mask means rx[i] != expected[i]. No error is bypassed. */
extern volatile uint32_t fpga_diag_tag,fpga_diag_step,fpga_diag_ready;
extern volatile uint32_t fpga_diag_id[5];
/* Scalar aliases for Keil Watch, updated from the same actual SPI bytes. */
extern volatile uint32_t fpga_id0,fpga_id1,fpga_id2,fpga_id3,fpga_id4;
extern volatile uint32_t fpga_echo_expected[6],fpga_echo_rx[6];
extern volatile uint32_t fpga_echo_error_mask,fpga_echo_saved;

FPGA_Status FPGA_Read(const FPGA_Bus *bus,uint16_t address,uint8_t *data,size_t count);
FPGA_Status FPGA_WriteByte(const FPGA_Bus *bus,uint16_t address,uint8_t value);
FPGA_Status FPGA_TestLink(const FPGA_Bus *bus);
FPGA_Status FPGA_Command(const FPGA_Bus *bus,uint8_t command);
/* Read only the application header while waiting; no result RAM download. */
FPGA_Status FPGA_ReadStatus(const FPGA_Bus *bus,uint8_t *status,uint8_t *command_status);
FPGA_Status FPGA_GetResult(const FPGA_Bus *bus,FPGA_Result *result);
unsigned FPGA_Level(uint32_t water,uint32_t roi);
uint16_t FPGA_Crc16(uint16_t crc,const uint8_t *data,size_t count);
#endif
