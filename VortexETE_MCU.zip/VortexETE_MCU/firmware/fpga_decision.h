#ifndef FPGA_DECISION_H
#define FPGA_DECISION_H
#include "fpga_spi.h"
/* Keep the original numeric stage values used by Keil Watch. */
enum {FPGA_STAGE_CHECK_LINK=0,FPGA_STAGE_WAIT_PERIOD=1,
      FPGA_STAGE_WAIT_SCAN=2,FPGA_STAGE_BACKOFF=3};
extern volatile uint32_t camera_test_mode,camera_fallback_active,fpga_result_from_fallback;
extern volatile uint32_t fpga_roi_skipped,fpga_whole_water_pixels;
extern volatile uint32_t fpga_status_register,fpga_command_status;
extern volatile uint32_t fpga_error_status,fpga_status_polls,fpga_scan_requests;
extern volatile uint32_t fpga_scan_elapsed_ms,fpga_last_scan_ms,fpga_wait_remaining_ms;
void FPGA_DecisionInit(const FPGA_Bus *bus,uint32_t now_ms);
/* Foreground only; call while DHT is idle. Runs even with SIM disconnected. */
void FPGA_DecisionTask(uint32_t now_ms);
void FPGA_RequestScan(void); /* still subject to the sensor gate */
/* Foreground inputs: raw water uses WATER_MILLI_MM_PER_RAW; quiet time comes
 * from Rain_QuietMs(). Timestamp water at acquisition, not each service call. */
void FPGA_UpdateSensorInputs(uint32_t water_at_ms,uint16_t water_raw,int water_valid,
                             uint32_t rain_quiet_ms,int rain_activity_valid);
enum {
    CAMERA_GATE_ALLOWED=0,CAMERA_GATE_WATER_INVALID=1,
    CAMERA_GATE_WATER_STALE=2,CAMERA_GATE_RAIN_INVALID=3,
    CAMERA_GATE_RAIN_RECENT=4,CAMERA_GATE_WATER_LOW=5,
    CAMERA_GATE_TEST_MODE=6,CAMERA_GATE_WATER_FAILOVER=7,
    CAMERA_GATE_STALE_FAILOVER=8
};
/* enabled = permission for a new capture, not a physical PWDN readback. */
extern volatile uint32_t camera_enabled,camera_gate_reason;
extern volatile uint64_t camera_water_milli_mm;
extern volatile uint32_t camera_rain_quiet_ms;
extern volatile uint32_t fpga_stage,fpga_results_received,fpga_decisions_sent;
extern volatile uint32_t fpga_frames_failed,fpga_frame_id,fpga_bytes_read;
extern volatile uint32_t fpga_water_pixels,fpga_roi_pixels,fpga_water_percent_x100;
extern volatile uint32_t fpga_level,fpga_result_valid,fpga_last_ok_ms;
extern volatile int32_t fpga_last_error;
extern volatile uint32_t flash_sleep_request_sent;
extern volatile int32_t flash_sleep_result;
#endif
