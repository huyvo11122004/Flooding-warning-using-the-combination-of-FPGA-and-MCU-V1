#ifndef SIM_A7680C_H
#define SIM_A7680C_H
#include <stdint.h>
#define SIM_PAYLOAD_CAPACITY 640u
#define SIM_APP_PAYLOAD_CAPACITY 512u
typedef struct {
    uint32_t voltage_mv;
    unsigned signal_percent;
    int voltage_valid,signal_valid;
} SIM_Health;
void SIM_ReadHealth(uint32_t now_ms,SIM_Health *health);
extern volatile uint32_t sim_voltage_mv,sim_voltage_valid,sim_signal_valid;
extern volatile uint32_t sim_voltage_at_ms,sim_signal_at_ms,sim_health_errors,sim_health_poll_count;
extern volatile int sim_signal_percent,sim_signal_dbm,sim_cbc_supported;
void SIM_Init(void);
void SIM_Task(uint32_t now_ms); /* call frequently, foreground only */
int SIM_SetTelemetry(const char *json); /* copy latest; foreground only */
/* One reliable application slot (payload up to 511 bytes). No overwrite; cleared on connection failure. Caller must requeue latest state.
 * Successful completion requires modem +CMQTTPUB:0,0. token must be nonzero and unique until acknowledged. */
int SIM_QueuePublish(const char *topic,const char *json,uint32_t token);
int SIM_PublishState(uint32_t token); /* 1=broker ACK, 0=queued/in flight, -1=unknown */
extern volatile uint32_t sim_at_ok,sim_timeouts,sim_command_errors,sim_parse_errors;
extern volatile int sim_pin_ready,sim_rssi,sim_registration,sim_attached;
extern volatile unsigned sim_step;
extern volatile uint32_t sim_mqtt_connected,sim_publish_count,sim_reconnects;
extern volatile int sim_last_mqtt_error,sim_requires_reset;
extern volatile unsigned sim_failed_step;
extern char sim_last_line[160],sim_mqtt_topic[96];
#endif
