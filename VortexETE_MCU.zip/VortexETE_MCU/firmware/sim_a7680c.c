#include "sim_a7680c.h"
#include "sim_uart.h"
#include "app_config.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
volatile uint32_t sim_at_ok,sim_timeouts,sim_command_errors,sim_parse_errors;
volatile int sim_pin_ready,sim_rssi,sim_registration,sim_attached;
volatile uint32_t sim_voltage_mv,sim_voltage_valid,sim_signal_valid;
volatile uint32_t sim_voltage_at_ms,sim_signal_at_ms,sim_health_errors,sim_health_poll_count;
volatile int sim_signal_percent,sim_signal_dbm,sim_cbc_supported;
volatile unsigned sim_step;
volatile uint32_t sim_mqtt_connected,sim_publish_count,sim_reconnects;
volatile int sim_last_mqtt_error,sim_requires_reset;
volatile unsigned sim_failed_step;
char sim_last_line[160],sim_mqtt_topic[96];
static char line[160],command[224],latest[SIM_PAYLOAD_CAPACITY];
static char sending[SIM_PAYLOAD_CAPACITY];
static char message[SIM_APP_PAYLOAD_CAPACITY],message_topic[96];
static uint32_t message_token,ack_token;
static unsigned message_pending,sending_message,prefer_telemetry;
static size_t used;
static unsigned pending,waiting,got_ok,got_result,discard_line;
static uint32_t sent_at,delay_at,timeout_ms,health_at;
static unsigned health_seen;
static int health_rssi;
static uint32_t health_voltage;
enum { S_AT,S_ECHO,S_PIN,S_CSQ,S_CBC,S_REG,S_ATTACH,S_APN,
       S_DISC,S_REL,S_STOP,S_START,S_ACQUIRE,S_CONNECT,S_IDLE,
       S_TOPIC_PROMPT,S_TOPIC_DATA,S_PAYLOAD_PROMPT,S_PAYLOAD_DATA,S_PUBLISH,
       S_BACKOFF,S_FATAL,S_HEALTH_CSQ,S_HEALTH_CBC };
/* Signal percent is a display mapping of CSQ, not BER or data throughput. */
static int health_csq(void){return sim_step==S_CSQ||sim_step==S_HEALTH_CSQ;}
static int health_cbc(void){return sim_step==S_CBC||sim_step==S_HEALTH_CBC;}
static void clear_signal(void)
{
    sim_signal_valid=0;sim_rssi=-1;sim_signal_percent=-1;sim_signal_dbm=-32768;
}
static void clear_voltage(void){sim_voltage_valid=0;sim_voltage_mv=0;}
void SIM_ReadHealth(uint32_t now,SIM_Health *h)
{
    if(!h)return;
    h->voltage_valid=sim_voltage_valid&&(uint32_t)(now-sim_voltage_at_ms)<SIM_HEALTH_STALE_MS;
    h->signal_valid=sim_signal_valid&&(uint32_t)(now-sim_signal_at_ms)<SIM_HEALTH_STALE_MS;
    h->voltage_mv=h->voltage_valid?sim_voltage_mv:0;
    h->signal_percent=h->signal_valid?(unsigned)sim_signal_percent:0;
}
static int parse_csq(const char *text,int *rssi)
{
    char *end;long a,b;
    while(*text==' ')++text;
    if(*text<'0'||*text>'9')return 0;
    a=strtol(text,&end,10);while(*end==' ')++end;
    if(*end++!=',')return 0;
    while(*end==' ')++end;
    if(*end<'0'||*end>'9')return 0;
    text=end;b=strtol(text,&end,10);while(*end==' ')++end;
    if(*end||!((a>=0&&a<=31)||a==99)||!((b>=0&&b<=7)||b==99))return 0;
    *rssi=(int)a;return 1;
}
static int parse_cbc(const char *text,uint32_t *mv)
{
    uint32_t whole=0,fraction=0;unsigned digits=0,n=0;
    while(*text==' ')++text;
    while(*text>='0'&&*text<='9'){
        if(++digits>2)return 0;
        whole=whole*10u+(unsigned)(*text++-'0');
    }
    if(!digits)return 0;
    if(*text=='.'){
        ++text;
        while(*text>='0'&&*text<='9'){
            if(++n>3)return 0;
            fraction=fraction*10u+(unsigned)(*text++-'0');
        }
        if(!n)return 0;
    }
    while(n<3){fraction*=10u;++n;}
    while(*text==' ')++text;
    if(*text=='V'||*text=='v')++text;
    while(*text==' ')++text;
    if(*text)return 0;
    *mv=whole*1000u+fraction;
    return *mv>0&&*mv<=20000u; /* reject malformed/ambiguous mV-only responses */
}
static void health_complete(uint32_t now,int ok)
{
    unsigned s=sim_step;
    waiting=0;
    if(health_csq()){
        clear_signal();
        if(ok&&health_seen){
            sim_rssi=health_rssi;sim_signal_at_ms=now;
            if(health_rssi<=31){
                sim_signal_percent=(health_rssi*100+15)/31;
                sim_signal_dbm=-113+2*health_rssi;sim_signal_valid=1;
            }
        }else ++sim_health_errors;
        sim_step=s==S_CSQ?S_CBC:(sim_cbc_supported==0?S_IDLE:S_HEALTH_CBC);
        if(sim_step==S_IDLE)health_at=now;
    }else{
        clear_voltage();
        if(ok&&health_seen){
            sim_voltage_mv=health_voltage;sim_voltage_at_ms=now;
            sim_voltage_valid=1;sim_cbc_supported=1;
        }else{
            ++sim_health_errors;
            if(!ok)sim_cbc_supported=0; /* unsupported command: keep MQTT alive */
        }
        sim_step=s==S_CBC?S_REG:S_IDLE;
        health_at=now;
    }
}
/* One owner for the AT stream. OK and asynchronous result can arrive in either order. */
static int cleanup(void){return sim_step>=S_DISC&&sim_step<=S_STOP;}
static int needs_result(void)
{
    return sim_step==S_DISC||sim_step==S_STOP||sim_step==S_START||
           sim_step==S_CONNECT||sim_step==S_PUBLISH;
}
static void fail(uint32_t now,int fatal)
{
    sim_failed_step=sim_step;sim_mqtt_connected=0;waiting=0;
    sim_step=fatal?S_FATAL:S_BACKOFF;sim_requires_reset=fatal;
    delay_at=now;used=0;discard_line=0;
    /* Drop obsolete application state; owner requeues its latest result. */
    message_pending=sending_message=0;
    clear_signal();clear_voltage();
}
void SIM_Init(void)
{
    sim_at_ok=sim_timeouts=sim_command_errors=sim_parse_errors=0;
    sim_mqtt_connected=sim_publish_count=sim_reconnects=0;
    sim_pin_ready=sim_rssi=sim_registration=sim_attached=-1;
    sim_last_mqtt_error=-1;sim_requires_reset=0;sim_failed_step=0;
    sim_step=S_AT;waiting=got_ok=got_result=pending=discard_line=0;
    clear_signal();clear_voltage();sim_cbc_supported=-1;
    sim_voltage_at_ms=sim_signal_at_ms=sim_health_errors=sim_health_poll_count=0;
    health_at=0;health_seen=0;
    message_pending=sending_message=prefer_telemetry=0;message_token=ack_token=0;
    used=0;sent_at=delay_at=0;sim_last_line[0]=0;
    (void)snprintf(sim_mqtt_topic,sizeof sim_mqtt_topic,
                   "vortexete/station/%lu/telemetry",(unsigned long)MQTT_DEVICE_ID);
}
int SIM_SetTelemetry(const char *json)
{
    size_t n;
    if(!json)return 0;
    n=strlen(json);if(!n||n>=sizeof latest)return 0;
    memcpy(latest,json,n+1u);pending=1;return 1;
}
int SIM_QueuePublish(const char *topic,const char *json,uint32_t token)
{
    size_t n,t;
    if(!topic||!json||!token||message_pending)return 0;
    n=strlen(json);t=strlen(topic);
    if(!n||n>=sizeof message||!t||t>=sizeof message_topic)return 0;
    memcpy(message,json,n+1u);memcpy(message_topic,topic,t+1u);
    message_token=token;message_pending=1;return 1;
}
int SIM_PublishState(uint32_t token)
{
    if(token&&ack_token==token)return 1;
    return token&&message_pending&&message_token==token?0:-1;
}
static void complete(uint32_t now)
{
    unsigned s=sim_step;
    waiting=0;
    if(health_csq()||health_cbc()){health_complete(now,1);return;}
    if(s==S_AT)sim_at_ok=1;
    if((s==S_PIN&&sim_pin_ready!=1)||
       (s==S_REG&&sim_registration!=1&&sim_registration!=5)||
       (s==S_ATTACH&&sim_attached!=1)){fail(now,0);return;}
    if(s==S_CONNECT){sim_mqtt_connected=1;sim_step=S_IDLE;return;}
    if(s==S_PUBLISH){
        ++sim_publish_count;
        if(sending_message){ack_token=message_token;message_pending=0;prefer_telemetry=1;}
        else prefer_telemetry=0;
        sending_message=0;sim_step=S_IDLE;return;
    }
    if(s==S_TOPIC_DATA){sim_step=S_PAYLOAD_PROMPT;return;}
    if(s==S_PAYLOAD_DATA){sim_step=S_PUBLISH;return;}
    sim_step=s+1u;
}
static void result(uint32_t now,int code)
{
    sim_last_mqtt_error=code;
    if(code!=0&&!cleanup()){++sim_command_errors;fail(now,0);return;}
    got_result=1;if(got_ok)complete(now);
}
static int mqtt_result(const char *text,const char *prefix,int with_client,int *code)
{
    char *end;long a;size_t n=strlen(prefix);
    if(strncmp(text,prefix,n))return 0;
    text+=n;a=strtol(text,&end,10);if(end==text)return 0;
    if(with_client){
        if(a!=0||*end!=',')return 0;
        text=end+1;a=strtol(text,&end,10);if(end==text)return 0;
    }
    while(*end==' ')++end;
    if(*end||a<0||a>255)return 0;
    *code=(int)a;return 1;
}
static void parse_line(uint32_t now)
{
    const char *p;int a;
    line[used]=0;memcpy(sim_last_line,line,used+1u);
    if(!strcmp(line,"RDY")){
        sim_at_ok=0;sim_pin_ready=sim_registration=sim_attached=-1;sim_cbc_supported=-1;
        fail(now,0);return;
    }
    if(!strncmp(line,"+CMQTTCONNLOST:",15)||!strcmp(line,"+CIPEVENT: NETWORK CLOSED")){
        fail(now,0);return;
    }
    if(!strncmp(line,"+CPIN:",6)) {
        p=line+6;while(*p==' ')++p;sim_pin_ready=!strcmp(p,"READY");
    } else if(!strncmp(line,"+CSQ:",5)&&waiting&&health_csq()){
        health_seen=(unsigned)parse_csq(line+5,&health_rssi);
        if(!health_seen)++sim_parse_errors;
    }else if(!strncmp(line,"+CBC:",5)&&waiting&&health_cbc()){
        health_seen=(unsigned)parse_cbc(line+5,&health_voltage);
        if(!health_seen)++sim_parse_errors;
    }
    else if(!strncmp(line,"+CEREG:",7)) {
        char *end;int first=(int)strtol(line+7,&end,10);
        p=end;if(*p==','){++p;while(*p==' ')++p;
            sim_registration=(*p>='0'&&*p<='9')?atoi(p):first;
        }else sim_registration=first;
        if(sim_mqtt_connected&&sim_registration!=1&&sim_registration!=5){fail(now,0);return;}
    }else if(!strncmp(line,"+CGATT:",7))sim_attached=atoi(line+7);
    if(!waiting)return;
    if(!strcmp(line,"ERROR")||!strncmp(line,"+CME ERROR:",11)) {
        if(health_csq()||health_cbc())health_complete(now,0);
        else if(cleanup())complete(now);else{++sim_command_errors;fail(now,0);}
        return;
    }
    if(!strcmp(line,"OK")) {
        if(sim_step==S_TOPIC_PROMPT||sim_step==S_PAYLOAD_PROMPT)return;
        got_ok=1;if(!needs_result()||got_result)complete(now);
    }else if(sim_step==S_START&&mqtt_result(line,"+CMQTTSTART:",0,&a))result(now,a);
    else if(sim_step==S_STOP&&mqtt_result(line,"+CMQTTSTOP:",0,&a))result(now,a);
    else if(sim_step==S_DISC&&mqtt_result(line,"+CMQTTDISC:",1,&a))result(now,a);
    else if(sim_step==S_CONNECT&&mqtt_result(line,"+CMQTTCONNECT:",1,&a))result(now,a);
    else if(sim_step==S_PUBLISH&&mqtt_result(line,"+CMQTTPUB:",1,&a))result(now,a);
}
static void prompt(uint32_t now)
{
    const char *data;
    if(!waiting||(sim_step!=S_TOPIC_PROMPT&&sim_step!=S_PAYLOAD_PROMPT))return;
    data=sim_step==S_TOPIC_PROMPT?sim_mqtt_topic:sending;
    sim_step=sim_step==S_TOPIC_PROMPT?S_TOPIC_DATA:S_PAYLOAD_DATA;
    used=0;got_ok=got_result=0;sent_at=now;timeout_ms=SIM_COMMAND_TIMEOUT_MS;
    /* Exact byte count, no CR/LF or Ctrl-Z appended. */
    if(!SIM_UART_Send(data)){++sim_command_errors;fail(now,1);}
}
void SIM_Task(uint32_t now)
{
    uint8_t c;unsigned count=0;int r,n=0;
    if(sim_signal_valid&&(uint32_t)(now-sim_signal_at_ms)>=SIM_HEALTH_STALE_MS)clear_signal();
    if(sim_voltage_valid&&(uint32_t)(now-sim_voltage_at_ms)>=SIM_HEALTH_STALE_MS)clear_voltage();
    while(count++<512u&&(r=SIM_UART_Read(&c))!=0) {
        if(r<0){++sim_parse_errors;fail(now,1);return;}
        if(c=='>'&&(sim_step==S_TOPIC_PROMPT||sim_step==S_PAYLOAD_PROMPT)){
            prompt(now);continue;
        }
        if(c=='\r')continue;
        if(c=='\n'){
            if(!discard_line&&used)parse_line(now);
            used=0;discard_line=0;
        }else if(!discard_line){
            if(c==' '&&used==0u)continue; /* space after prompt */
            if(used<sizeof line-1u)line[used++]=(char)c;
            else{++sim_parse_errors;fail(now,1);return;}
        }
    }
    if(sim_step==S_FATAL)return;
    if(waiting){
        if((uint32_t)(now-sent_at)>=timeout_ms){
            ++sim_timeouts;
            /* A late prompt could swallow following AT commands as raw data. */
            if(sim_step>=S_TOPIC_PROMPT&&sim_step<=S_PAYLOAD_DATA)fail(now,1);
            else fail(now,0);
        }return;
    }
    if(sim_step==S_BACKOFF){
        if((uint32_t)(now-delay_at)<SIM_POLL_MS)return;
        ++sim_reconnects;sim_step=S_AT;
        sim_pin_ready=sim_registration=sim_attached=-1;
    }
    if(sim_step==S_IDLE){
        if((uint32_t)(now-health_at)>=SIM_HEALTH_POLL_MS){
            health_at=now;sim_step=S_HEALTH_CSQ;++sim_health_poll_count;
        }else{
            if(!pending&&!message_pending)return;
            if(message_pending&&(!pending||!prefer_telemetry)){
                strcpy(sending,message);strcpy(sim_mqtt_topic,message_topic);sending_message=1;
            }else{
                strcpy(sending,latest);pending=0;sending_message=0;
                (void)snprintf(sim_mqtt_topic,sizeof sim_mqtt_topic,
                    "vortexete/station/%lu/telemetry",(unsigned long)MQTT_DEVICE_ID);
            }
            sim_step=S_TOPIC_PROMPT;
        }
    }
    timeout_ms=SIM_COMMAND_TIMEOUT_MS;
    switch(sim_step){
    case S_AT:n=snprintf(command,sizeof command,"AT\r\n");break;
    case S_ECHO:n=snprintf(command,sizeof command,"ATE0\r\n");break;
    case S_PIN:n=snprintf(command,sizeof command,"AT+CPIN?\r\n");break;
    case S_CSQ:case S_HEALTH_CSQ:
        health_seen=0;n=snprintf(command,sizeof command,"AT+CSQ\r\n");
        timeout_ms=SIM_HEALTH_TIMEOUT_MS;break;
    case S_CBC:case S_HEALTH_CBC:
        health_seen=0;n=snprintf(command,sizeof command,"AT+CBC\r\n");
        timeout_ms=SIM_HEALTH_TIMEOUT_MS;break;
    case S_REG:n=snprintf(command,sizeof command,"AT+CEREG?\r\n");break;
    case S_ATTACH:n=snprintf(command,sizeof command,"AT+CGATT?\r\n");break;
    case S_APN:
        if(!SIM_APN[0]){sim_step=S_DISC;return;}
        n=snprintf(command,sizeof command,"AT+CGDCONT=1,\"IP\",\"%s\"\r\n",SIM_APN);break;
    case S_DISC:n=snprintf(command,sizeof command,"AT+CMQTTDISC=0,60\r\n");timeout_ms=65000u;break;
    case S_REL:n=snprintf(command,sizeof command,"AT+CMQTTREL=0\r\n");break;
    case S_STOP:n=snprintf(command,sizeof command,"AT+CMQTTSTOP\r\n");timeout_ms=65000u;break;
    case S_START:n=snprintf(command,sizeof command,"AT+CMQTTSTART\r\n");timeout_ms=150000u;break;
    case S_ACQUIRE:n=snprintf(command,sizeof command,"AT+CMQTTACCQ=0,\"%s\",0\r\n",MQTT_CLIENT_ID);break;
    case S_CONNECT:n=snprintf(command,sizeof command,"AT+CMQTTCONNECT=0,\"tcp://%s:%u\",60,1\r\n",MQTT_BROKER,(unsigned)MQTT_PORT);timeout_ms=150000u;break;
    case S_TOPIC_PROMPT:n=snprintf(command,sizeof command,"AT+CMQTTTOPIC=0,%u\r\n",(unsigned)strlen(sim_mqtt_topic));break;
    case S_PAYLOAD_PROMPT:n=snprintf(command,sizeof command,"AT+CMQTTPAYLOAD=0,%u\r\n",(unsigned)strlen(sending));break;
    case S_PUBLISH:n=snprintf(command,sizeof command,"AT+CMQTTPUB=0,1,60\r\n");timeout_ms=65000u;break;
    default:return;
    }
    if(n<=0||(size_t)n>=sizeof command||!SIM_UART_Send(command)){
        ++sim_command_errors;fail(now,1);return;
    }
    waiting=1;got_ok=got_result=0;sent_at=now;
}
