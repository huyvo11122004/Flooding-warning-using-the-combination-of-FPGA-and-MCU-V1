#ifndef RS485_SN32F407_CONFIG_H
#define RS485_SN32F407_CONFIG_H
/* UART1 RS485: P2.2 TX, P2.3 RX, EVK J7 pins 2/3. */
#ifndef RS485_UART_INDEX
#define RS485_UART_INDEX 1u
#endif
#ifndef RS485_TX_SELECT
#define RS485_TX_SELECT 1u  /* UART1 TX=P2.2 */
#endif
#ifndef RS485_RX_SELECT
#define RS485_RX_SELECT 1u  /* UART1 RX=P2.3 */
#endif
#ifndef RS485_MANUAL_DE
#define RS485_MANUAL_DE 0u /* 0 only for a verified auto-direction module */
#endif
#ifndef RS485_DE_PORT
#define RS485_DE_PORT 1u
#endif
#ifndef RS485_DE_PIN
#define RS485_DE_PIN 0u /* P1.0; DE and /RE tied together on transceiver */
#endif
#ifndef RS485_DE_ACTIVE_HIGH
#define RS485_DE_ACTIVE_HIGH 1u
#endif
#ifndef RS485_DE_SETUP_US
#define RS485_DE_SETUP_US 10u /* Check actual transceiver enable time. */
#endif
#ifndef RS485_DE_HOLD_US
#define RS485_DE_HOLD_US 0u /* TEMT already waits for the final stop bit. */
#endif
/* FPGA SPI owns these P1 pins; require another DE pin if manual direction is enabled. */
#if RS485_MANUAL_DE && RS485_DE_PORT == 1u && (RS485_DE_PIN == 0u || RS485_DE_PIN == 1u || RS485_DE_PIN == 2u || RS485_DE_PIN == 8u)
#error RS485_DE_conflicts_with_FPGA_SPI_select_another_pin
#endif
#endif
