/* Direct register port, SONiX SN32F400 User's Manual v2.2.
 * No STM32 HAL; no guessed vendor function names.
 * Dedicated UART; foreground polling; do not enable UART IRQ or DMA.
 */
#include "rs485_sn32f407.h"
#include "rs485_sn32f407_config.h"
#include "sn32_time_math.h"
#define SN_REG(address) (*(volatile uint32_t *)(uintptr_t)(address))
#define SN_SYS1_CLOCK SN_REG(0x4005E000u)
#define SN_SYS1_RESET SN_REG(0x4005E010u)
#define SN_PFPA_UART SN_REG(0x40042020u + 4u * RS485_UART_INDEX)
#define SN_UART_BASE ((RS485_UART_INDEX == 0u) ? 0x40016000u : 0x40056000u)
#define SN_UART_DATA SN_REG(SN_UART_BASE + 0x00u)
#define SN_UART_IE SN_REG(SN_UART_BASE + 0x04u)
#define SN_UART_FIFO SN_REG(SN_UART_BASE + 0x08u)
#define SN_UART_LC SN_REG(SN_UART_BASE + 0x0Cu)
#define SN_UART_LS SN_REG(SN_UART_BASE + 0x14u)
#define SN_UART_FD SN_REG(SN_UART_BASE + 0x28u)
#define SN_UART_CTRL SN_REG(SN_UART_BASE + 0x30u)
#define SN_UART_HDEN SN_REG(SN_UART_BASE + 0x34u)
#define SN_UART_DMA SN_REG(SN_UART_BASE + 0x50u)
#define SN_GPIO_BASE (0x40044000u + 0x2000u * RS485_DE_PORT)
#define SN_GPIO_MODE SN_REG(SN_GPIO_BASE + 0x04u)
#define SN_GPIO_CFG SN_REG(SN_GPIO_BASE + 0x08u)
#define SN_GPIO_SET SN_REG(SN_GPIO_BASE + 0x24u)
#define SN_GPIO_CLEAR SN_REG(SN_GPIO_BASE + 0x28u)
#define SN_SYSTICK_CTRL SN_REG(0xE000E010u)
#define SN_SYSTICK_LOAD SN_REG(0xE000E014u)
#define SN_SYSTICK_VAL SN_REG(0xE000E018u)
#define SN_ICSR SN_REG(0xE000ED04u)

#if RS485_UART_INDEX > 1 || RS485_TX_SELECT > 3 || RS485_RX_SELECT > 3
#error "Invalid UART index or PFPA selection"
#endif
#if RS485_DE_PORT > 3 || RS485_DE_PIN > 13
#error "Invalid DE GPIO"
#endif

static volatile uint32_t tick_us;
static uint32_t cycles_per_us,us_reciprocal;
static uint32_t actual_baud;
static int ready;

static void direction(int transmit)
{
#if RS485_MANUAL_DE
    int level = transmit ? (int)RS485_DE_ACTIVE_HIGH : !(int)RS485_DE_ACTIVE_HIGH;
    if (level) SN_GPIO_SET = 1u << RS485_DE_PIN;
    else SN_GPIO_CLEAR = 1u << RS485_DE_PIN;
#else
    (void)transmit;
#endif
}

void RS485_SN32F407_Tick1ms(void) { tick_us += 1000u; }

uint32_t RS485_PortNowUs(void)
{
    uint32_t before, after, value, pending;
    if (cycles_per_us == 0u) return 0u;
    /* Consistent snapshot across a SysTick rollover or handler invocation.
     * Interrupts must stay enabled; never mask SysTick for >= 1 ms.
     */
    do {
        before = tick_us;
        value = SN_SYSTICK_VAL;
        pending = SN_ICSR & (1u << 26);
        if (pending != 0u) value = SN_SYSTICK_VAL;
        after = tick_us;
    } while (before != after);
    if (pending != 0u) before += 1000u;
    return before + SN32_CyclesToUs(SN_SYSTICK_LOAD-value,cycles_per_us,us_reciprocal);
}

static void delay_us(uint32_t duration)
{
    uint32_t start = RS485_PortNowUs();
    while ((uint32_t)(RS485_PortNowUs() - start) < duration) { }
}

void RS485_SN32F407_DelayMs(uint32_t milliseconds)
{
    if (!ready) return;
    while (milliseconds-- > 0u) delay_us(1000u);
}

static int de_overlaps_uart(void)
{
#if RS485_MANUAL_DE
    static const uint8_t tx_port[2][4] = {{0,2,3,2},{1,2,2,1}};
    static const uint8_t tx_pin[2][4] = {{10,1,1,9},{9,2,7,0}};
    static const uint8_t rx_port[2][4] = {{0,2,3,2},{1,2,2,1}};
    static const uint8_t rx_pin[2][4] = {{11,0,2,10},{8,3,8,1}};
    return (RS485_DE_PORT == tx_port[RS485_UART_INDEX][RS485_TX_SELECT]
            && RS485_DE_PIN == tx_pin[RS485_UART_INDEX][RS485_TX_SELECT])
        || (RS485_DE_PORT == rx_port[RS485_UART_INDEX][RS485_RX_SELECT]
            && RS485_DE_PIN == rx_pin[RS485_UART_INDEX][RS485_RX_SELECT]);
#else
    return 0;
#endif
}

RS485_Status RS485_SN32F407_Init(uint32_t hclk, uint32_t baud,
    char parity, uint8_t stop_bits)
{
    uint32_t divisor, line = 3u, error, reset_budget, calculated_baud;
    uint8_t bits;
    RS485_Status status;
    /* Integer divider, oversampling 16, fractional divider disabled. */
    if (hclk < 1000000u || hclk > 60000000u || hclk % 1000000u != 0u
        || baud < 1200u || baud > 1000000u || (stop_bits != 1u && stop_bits != 2u)
        || (parity != 'N' && parity != 'E' && parity != 'O') || de_overlaps_uart())
        return RS485_ERR_ARGUMENT;
    divisor = (hclk + 8u * baud) / (16u * baud);
    if (divisor == 0u || divisor > 65535u) return RS485_ERR_ARGUMENT;
    calculated_baud = hclk / (16u * divisor);
    error = calculated_baud > baud ? calculated_baud - baud : baud - calculated_baud;
    if (error > baud / 50u) return RS485_ERR_ARGUMENT; /* >2% rejected */
    if (parity != 'N') line |= 1u << 3;
    if (parity == 'E') line |= 1u << 4;
    if (stop_bits == 2u) line |= 1u << 2;
    bits = (uint8_t)(1u + 8u + (parity != 'N' ? 1u : 0u) + stop_bits);
    /* Timing uses the requested baud; small divider error is bounded above. */
    status = RS485_ConfigureTiming(baud, bits);
    if (status != RS485_OK) return status;
    ready = 0;
    actual_baud = calculated_baud;
    cycles_per_us = hclk / 1000000u;
    us_reciprocal = (65536u+cycles_per_us-1u)/cycles_per_us;

    SN_SYS1_CLOCK |= 1u << (16u + RS485_UART_INDEX);
    SN_SYS1_RESET = 1u << (16u + RS485_UART_INDEX);
    reset_budget = 100000u;
    while ((SN_SYS1_RESET & (1u << (16u + RS485_UART_INDEX))) != 0u) {
        if (--reset_budget == 0u) return RS485_ERR_NOT_READY;
    }
    SN_UART_CTRL = 0u;
#if RS485_MANUAL_DE
    direction(0); /* Set latch before output mode. */
    SN_GPIO_CFG = (SN_GPIO_CFG & ~(3u << (2u * RS485_DE_PIN)))
        | (2u << (2u * RS485_DE_PIN));
    SN_GPIO_MODE |= 1u << RS485_DE_PIN;
#endif
    SN_PFPA_UART = (SN_PFPA_UART & ~15u)
        | (RS485_RX_SELECT << 2) | RS485_TX_SELECT;
    SN_UART_LC = line | (1u << 7); /* DLAB: DATA=DLL, IE=DLM */
    SN_UART_DATA = divisor & 255u;
    SN_UART_IE = (divisor >> 8) & 255u;
    SN_UART_FD = 0u;
    SN_UART_LC = line; /* DLAB cleared: DATA=RX/TX, IE=interrupt enables */
    SN_UART_IE = 0u;
    SN_UART_FIFO = 1u; /* Required; SN32F400 has only one-byte buffering. */
    SN_UART_HDEN = 0u; /* External transceiver provides half-duplex bus. */
    SN_UART_DMA = 0u;
    SN_UART_CTRL = (1u << 7) | (1u << 6) | 1u;

    SN_SYSTICK_CTRL = 0u;
    SN_ICSR = 1u << 25; /* Clear a stale pending SysTick, W1C field. */
    tick_us = 0u;
    SN_SYSTICK_LOAD = hclk / 1000u - 1u;
    SN_SYSTICK_VAL = 0u;
    SN_SYSTICK_CTRL = 7u; /* CPU clock, 1 kHz interrupt, enabled */
    while (SN_SYSTICK_VAL == 0u) { } /* Let the initial reload take effect. */
    ready = 1;
    return RS485_OK;
}

int RS485_PortIsReady(void) { return ready; }
uint32_t RS485_SN32F407_ActualBaud(void) { return actual_baud; }

int RS485_PortReceiveByte(uint8_t *byte)
{
    uint32_t line = SN_UART_LS;
    /* LS must be read before DATA: reading LS clears the error flags. */
    if ((line & 0x9Eu) != 0u) {
        if ((line & 1u) != 0u) (void)SN_UART_DATA;
        return -1;
    }
    if ((line & 1u) == 0u) return 0;
    *byte = (uint8_t)SN_UART_DATA;
    return 1;
}

RS485_Status RS485_PortTransmit(const uint8_t *data, size_t length,
    uint32_t timeout_us)
{
    uint32_t start;
    RS485_Status status = RS485_OK;
    size_t i;
    if (!ready) return RS485_ERR_NOT_READY;
    if (data == NULL || length == 0u) return RS485_ERR_ARGUMENT;
    start = RS485_PortNowUs();
    if (timeout_us <= RS485_DE_SETUP_US + RS485_DE_HOLD_US)
        return RS485_ERR_TIMEOUT;
    SN_UART_CTRL &= ~(1u << 6); /* Prevent local echo, even with auto-DE. */
    direction(1);
    delay_us(RS485_DE_SETUP_US);
    for (i = 0u; i < length; ++i) {
        while ((SN_UART_LS & (1u << 5)) == 0u) {
            if ((uint32_t)(RS485_PortNowUs() - start) >= timeout_us) {
                status = RS485_ERR_TIMEOUT;
                goto release_bus;
            }
        }
        if ((uint32_t)(RS485_PortNowUs() - start) >= timeout_us) {
            status = RS485_ERR_TIMEOUT;
            goto release_bus;
        }
        SN_UART_DATA = data[i];
    }
    while ((SN_UART_LS & (1u << 6)) == 0u) { /* TEMT, not merely THRE */
        if ((uint32_t)(RS485_PortNowUs() - start) >= timeout_us) {
            status = RS485_ERR_TIMEOUT;
            goto release_bus;
        }
    }
    delay_us(RS485_DE_HOLD_US);
    if ((uint32_t)(RS485_PortNowUs() - start) >= timeout_us)
        status = RS485_ERR_TIMEOUT;
release_bus:
    /* If timed out, reset the UART on re-init before any subsequent request. */
    if (status != RS485_OK) {
        ready = 0;
        SN_UART_CTRL = 0u;
    } else {
        SN_UART_CTRL |= 1u << 6;
    }
    direction(0);
    return status;
}
