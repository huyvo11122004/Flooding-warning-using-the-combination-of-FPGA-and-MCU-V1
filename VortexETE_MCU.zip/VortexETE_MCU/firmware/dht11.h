#ifndef DHT11_H
#define DHT11_H
#include <stdint.h>
typedef enum {
    DHT11_OK=0,DHT11_NOT_READY=1,DHT11_BUSY=2,DHT11_ERR_TIMEOUT=3,
    DHT11_ERR_CHECKSUM=4,DHT11_ERR_TIMING=5,DHT11_ERR_RANGE=6,DHT11_ERR_BUS=7
} DHT11_Status;
void DHT11_Init(uint32_t now_ms);
/* Call repeatedly only in the foreground idle window, before any blocking I/O. */
void DHT11_Task(uint32_t now_ms);
int DHT11_IsBusy(void);
int DHT11_IsFresh(uint32_t now_ms);
/* high MUST be the physical DATA level, not a synthetic edge toggle. */
void DHT11_OnEdgeISR(int high,uint32_t now_us);
DHT11_Status DHT11_Decode(const uint8_t bytes[5],uint16_t *temperature_x10,uint16_t *humidity_x10);
extern volatile DHT11_Status dht_status;
extern volatile uint32_t dht_valid,dht_success_count,dht_fail_count,dht_last_ok_ms;
extern volatile uint32_t dht_edge_count,dht_bit_count;
extern volatile uint16_t dht_temperature_x10,dht_humidity_x10;
extern volatile uint8_t dht_raw[5];
/* Last timing failure, retained across retries. Phase values match the
 * internal state machine: 1=start low, 2=waiting response fall,
 * 3/4=response, 5/6=data low/high. Timeout captures these fields too.
 * error_us is the measured interval, error_level is the sampled DATA level;
 * level=2 means no edge was sampled (foreground start-low overrun). */
extern volatile uint32_t dht_error_phase,dht_error_us,dht_error_level,dht_error_bits;
/* Implemented by the GPIO adapter; no masking of global interrupts. */
void DHT11_HWInit(void);
void DHT11_HWBeginLow(void);
void DHT11_HWArmRelease(void);
void DHT11_HWEnd(void);
int DHT11_HWRead(void);
uint32_t DHT11_HWNowUs(void);
#endif
