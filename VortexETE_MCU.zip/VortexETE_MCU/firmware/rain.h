#ifndef RAIN_H
#define RAIN_H
#include <stdint.h>
typedef struct {
    uint32_t hour_pulses,day_pulses,hour_elapsed_ms,day_elapsed_ms;
    int hour_valid,day_valid;
} RainSnapshot;
void Rain_Reset(void); /* boot only, before enabling GPIO interrupt */
void Rain_ResetAt(uint32_t now_ms);
void Rain_Process(uint32_t now_ms); /* foreground; drain timestamp queue */
void Rain_GetSnapshot(uint32_t now_ms,RainSnapshot *snapshot);
/* Foreground only. Accepted tips reset quiet time, including queue overruns.
 * Starts at zero on boot; saturates rather than wrapping after a long dry spell. */
uint32_t Rain_QuietMs(uint32_t now_ms);
extern volatile uint32_t rain_queue_overflows;
void Rain_OnFallingEdgeISR(uint32_t now_ms);
uint32_t Rain_Pulses(void);
uint64_t Rain_TotalUm(void); /* valid only if Rain_Calibrated() */
int Rain_Calibrated(void);
extern volatile uint32_t rain_rejected_edges, rain_saturated;
int Rain_HWInit(void);
#endif
