#include "dht11.h"
#include "app_config.h"
#include <stddef.h>
volatile DHT11_Status dht_status;
volatile uint32_t dht_valid,dht_success_count,dht_fail_count,dht_last_ok_ms;
volatile uint32_t dht_edge_count,dht_bit_count;
volatile uint16_t dht_temperature_x10,dht_humidity_x10;
volatile uint8_t dht_raw[5];
volatile uint16_t dht_period_us[40];
volatile uint32_t dht_error_phase,dht_error_us,dht_error_level,dht_error_bits;
enum { IDLE,HOST_LOW,WAIT_FALL,RESPONSE_LOW,RESPONSE_HIGH,BIT_LOW,BIT_HIGH,FRAME_DONE,FRAME_ERROR };
static volatile unsigned phase;
static volatile uint32_t edge_at, fall_at;
static uint32_t boot_at,attempt_at,released_at;
static int attempted;
DHT11_Status DHT11_Decode(const uint8_t b[5],uint16_t *temperature,uint16_t *humidity)
{
    uint16_t t,h;
    if(!b||!temperature||!humidity)return DHT11_ERR_RANGE;
    if((uint8_t)(b[0]+b[1]+b[2]+b[3])!=b[4])return DHT11_ERR_CHECKSUM;
    /* Classic DHT11: unsigned 0..50 C, decimal bytes are tenths.
     * Not DHT22's two-byte big-endian temperature/humidity format. */
    if(b[1]>9u||b[3]>9u)return DHT11_ERR_RANGE;
    h=(uint16_t)(10u*b[0]+b[1]);t=(uint16_t)(10u*b[2]+b[3]);
    if(t>500u||h>1000u)return DHT11_ERR_RANGE;
    *temperature=t;*humidity=h;return DHT11_OK;
}
void DHT11_Init(uint32_t now)
{
    unsigned i;
    phase=IDLE;dht_status=DHT11_NOT_READY;dht_valid=0;
    dht_success_count=dht_fail_count=dht_last_ok_ms=0;
    dht_edge_count=dht_bit_count=0;dht_temperature_x10=dht_humidity_x10=0;
    dht_error_phase=dht_error_us=dht_error_level=dht_error_bits=0;
    for(i=0;i<5;i++)dht_raw[i]=0;
    boot_at=attempt_at=now;attempted=0;DHT11_HWEnd();
}
int DHT11_IsBusy(void){return phase!=IDLE;}
int DHT11_IsFresh(uint32_t now)
{
    return dht_valid&&(uint32_t)(now-dht_last_ok_ms)<=DHT11_STALE_MS;
}
static void timing_snapshot(uint32_t elapsed_us,uint32_t level)
{
    dht_error_us=elapsed_us;dht_error_level=level;dht_error_bits=dht_bit_count;
    dht_error_phase=phase;
}
static void fail_edge(int high,uint32_t elapsed_us)
{
    timing_snapshot(elapsed_us,(uint32_t)(high!=0));
    dht_status=DHT11_ERR_TIMING;phase=FRAME_ERROR;
}
void DHT11_OnEdgeISR(int level,uint32_t now)
{
    uint32_t elapsed=(uint32_t)(now-edge_at);unsigned p=phase;int high=(level!=0);
    if(p<WAIT_FALL||p>BIT_HIGH)return;
    ++dht_edge_count;
    switch(p){
    case WAIT_FALL:
        if(!high){phase=RESPONSE_LOW;edge_at=now;}
        break;
    case RESPONSE_LOW:
        if(!high||elapsed<30u||elapsed>160u){fail_edge(high,elapsed);break;}
        edge_at=now;phase=RESPONSE_HIGH;break;
    case RESPONSE_HIGH:
        if(high||elapsed<30u||elapsed>160u){fail_edge(high,elapsed);break;}
        edge_at=fall_at=now;phase=BIT_LOW;break;
    case BIT_LOW:
        if(!high||elapsed<20u||elapsed>120u){fail_edge(high,elapsed);break;}
        edge_at=now;phase=BIT_HIGH;break;
    case BIT_HIGH:
		{		uint32_t period=(uint32_t)(now-fall_at);
				unsigned index;
        if(high||period<60u||period>170u){
            fail_edge(high,period);break;
        }
            index=(unsigned)dht_bit_count/8u;
            dht_raw[index]=(uint8_t)((dht_raw[index]<<1)|(period>=105u?1u:0u));
            dht_period_us[dht_bit_count]=(uint16_t)period;
						++dht_bit_count;edge_at=fall_at=now;
            phase=dht_bit_count==40u?FRAME_DONE:BIT_LOW;
        }
        break;
    default:break;
    }
}
static void finish_error(DHT11_Status status)
{
    DHT11_HWEnd();dht_status=status;dht_valid=0;++dht_fail_count;phase=IDLE;
}
void DHT11_Task(uint32_t now)
{
    unsigned p=phase,i;uint8_t b[5];uint16_t t,h;DHT11_Status result;
    if(dht_valid&&!DHT11_IsFresh(now))dht_valid=0;
    if(p==FRAME_DONE){
        DHT11_HWEnd();
        for(i=0;i<5;i++)b[i]=dht_raw[i];
        result=DHT11_Decode(b,&t,&h);
        if(result!=DHT11_OK){finish_error(result);return;}
        dht_temperature_x10=t;dht_humidity_x10=h;dht_last_ok_ms=now;
        ++dht_success_count;dht_status=DHT11_OK;dht_valid=1;phase=IDLE;return;
    }
    if(p==FRAME_ERROR){finish_error(dht_status);return;}
    if(p==HOST_LOW){
        uint32_t elapsed=(uint32_t)(now-attempt_at);
        if(elapsed>30u){
            timing_snapshot(elapsed*1000u,2u);
            finish_error(DHT11_ERR_TIMING);return;
        }
        if(elapsed>=20u){
            edge_at=fall_at=DHT11_HWNowUs();released_at=now;phase=WAIT_FALL;
            DHT11_HWArmRelease();
        }
        return;
    }
    if(p!=IDLE){
        if((uint32_t)(now-released_at)>=10u){
            timing_snapshot((uint32_t)(DHT11_HWNowUs()-edge_at),(uint32_t)(DHT11_HWRead()!=0));
            finish_error(DHT11_ERR_TIMEOUT);
        }
        return;
    }
    if((uint32_t)(now-boot_at)<DHT11_WARMUP_MS)return;
    if(attempted&&(uint32_t)(now-attempt_at)<DHT11_READ_INTERVAL_MS)return;
    attempted=1;attempt_at=now;dht_bit_count=dht_edge_count=0;
    for(i=0;i<5;i++)dht_raw[i]=0;
    for(i=0;i<40;i++)dht_period_us[i]=0;
    if(!DHT11_HWRead()){finish_error(DHT11_ERR_BUS);return;}
    dht_status=DHT11_BUSY;phase=HOST_LOW;DHT11_HWBeginLow();
}
