#ifndef RS485_SN32F407_H
#define RS485_SN32F407_H
#include "rs485.h"
/* N=none, E=even, O=odd. Set exactly as the sensor manual specifies. */
RS485_Status RS485_SN32F407_Init(uint32_t hclk_hz, uint32_t baud,
    char parity, uint8_t stop_bits);
/* This implementation owns SysTick at 1 kHz. Call from SysTick_Handler. */
void RS485_SN32F407_Tick1ms(void);
void RS485_SN32F407_DelayMs(uint32_t milliseconds);
uint32_t RS485_SN32F407_ActualBaud(void);
#endif
