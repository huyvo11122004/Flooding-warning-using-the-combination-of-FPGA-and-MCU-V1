#include "fpga_spi.h"
#include <string.h>

volatile uint32_t fpga_diag_tag,fpga_diag_step,fpga_diag_ready;
volatile uint32_t fpga_diag_id[5];
volatile uint32_t fpga_id0,fpga_id1,fpga_id2,fpga_id3,fpga_id4;
volatile uint32_t fpga_echo_expected[6],fpga_echo_rx[6];
volatile uint32_t fpga_echo_error_mask,fpga_echo_saved;

static int bus_error(const FPGA_Bus *b){return b->error&&b->error(b->context);}
static int valid_bus(const FPGA_Bus *b){return b&&b->select&&b->transfer;}
static uint16_t le16(const uint8_t *p){return (uint16_t)((uint16_t)p[0]|((uint16_t)p[1]<<8));}
static uint32_t le32(const uint8_t *p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}

FPGA_Status FPGA_Read(const FPGA_Bus *b,uint16_t address,uint8_t *data,size_t n)
{
    size_t i;
    if(!valid_bus(b)||!data||!n||n>65536u-(uint32_t)address)return FPGA_ERR_ARGUMENT;
    b->select(b->context,1);
    (void)b->transfer(b->context,3);
    (void)b->transfer(b->context,(uint8_t)(address>>8));
    (void)b->transfer(b->context,(uint8_t)address);
    (void)b->transfer(b->context,0); /* mandatory dummy byte */
    for(i=0;i<n&&!bus_error(b);i++)data[i]=b->transfer(b->context,0);
    b->select(b->context,0);
    return bus_error(b)?FPGA_ERR_BACKEND:FPGA_OK;
}

FPGA_Status FPGA_WriteByte(const FPGA_Bus *b,uint16_t address,uint8_t value)
{
    if(!valid_bus(b))return FPGA_ERR_ARGUMENT;
    b->select(b->context,1);
    (void)b->transfer(b->context,2);
    (void)b->transfer(b->context,(uint8_t)(address>>8));
    (void)b->transfer(b->context,(uint8_t)address);
    (void)b->transfer(b->context,value);
    b->select(b->context,0);
    return bus_error(b)?FPGA_ERR_BACKEND:FPGA_OK;
}

FPGA_Status FPGA_TestLink(const FPGA_Bus *b)
{
    static const uint8_t id[]={0xAC,0x52,0x54,0x07,5};
    static const uint8_t patterns[]={0x00,0xFF,0x55,0xAA,0x5A,0xA5};
    uint8_t received[5],saved,value;size_t i;
    FPGA_Status s;
    fpga_diag_tag=0x53504433u; /* SPD3, assigned at runtime to survive linker removal */
    fpga_diag_ready=0;fpga_diag_step=1;fpga_echo_error_mask=0;fpga_echo_saved=0xFFFFFFFFu;
    for(i=0;i<5;i++)fpga_diag_id[i]=0xFFFFFFFFu;
    fpga_id0=fpga_id1=fpga_id2=fpga_id3=fpga_id4=0xFFFFFFFFu;
    for(i=0;i<sizeof patterns;i++){fpga_echo_expected[i]=patterns[i];fpga_echo_rx[i]=0xFFFFFFFFu;}
    s=FPGA_Read(b,0,received,sizeof received);
    if(s!=FPGA_OK)return s;
    for(i=0;i<5;i++)fpga_diag_id[i]=received[i];
    fpga_id0=received[0];fpga_id1=received[1];fpga_id2=received[2];
    fpga_id3=received[3];fpga_id4=received[4];
    if(memcmp(received,id,sizeof id)!=0)return FPGA_ERR_ID;
    fpga_diag_step=2;
    s=FPGA_Read(b,0x10,&saved,1);if(s!=FPGA_OK)return s;
    fpga_echo_saved=saved;
    for(i=0;i<sizeof patterns;i++){
        fpga_diag_step=3;
        s=FPGA_WriteByte(b,0x10,patterns[i]);if(s!=FPGA_OK)return s;
        fpga_diag_step=4;
        s=FPGA_Read(b,0x10,&value,1);if(s!=FPGA_OK)return s;
        fpga_echo_rx[i]=value;
        if(value!=patterns[i])fpga_echo_error_mask|=(uint32_t)1u<<i;
    }
    fpga_diag_step=5;
    s=FPGA_WriteByte(b,0x10,saved);if(s!=FPGA_OK)return s;
    fpga_diag_ready=1;
    if(fpga_echo_error_mask){fpga_diag_step=7;return FPGA_ERR_ECHO;}
    fpga_diag_step=6;return FPGA_OK;
}

FPGA_Status FPGA_Command(const FPGA_Bus *b,uint8_t command)
{
    if(command<1||command>3)return FPGA_ERR_ARGUMENT;
    { uint8_t status;FPGA_Status result=FPGA_WriteByte(b,8,command);
      if(result!=FPGA_OK)return result;
      result=FPGA_Read(b,7,&status,1);
      return result!=FPGA_OK?result:(status?FPGA_ERR_STATE:FPGA_OK); }
}

unsigned FPGA_Level(uint32_t water,uint32_t roi)
{
    if(!roi||roi>65536u||water>roi)return FPGA_LEVEL_UNKNOWN;
    if(water*100u>=roi*25u)return FPGA_LEVEL_CRITICAL;
    if(water*100u>=roi*5u)return FPGA_LEVEL_WARNING;
    return FPGA_LEVEL_NORMAL;
}
FPGA_Status FPGA_ReadStatus(const FPGA_Bus *b,uint8_t *status,uint8_t *command_status)
{
    uint8_t p[8];FPGA_Status s;
    if(!status||!command_status)return FPGA_ERR_ARGUMENT;
    *status=0;*command_status=0;
    s=FPGA_Read(b,0,p,sizeof p);if(s!=FPGA_OK)return s;
    /* Preserve raw bytes even on a bad header for Keil diagnostics. */
    *status=p[6];*command_status=p[7];
    if(p[0]!=0xAC||p[1]!=0x52||p[2]!=0x54||p[3]!=7||p[4]!=5)return FPGA_ERR_ID;
    if(p[5]!=0x7A || !(p[6]&FPGA_STATUS_INITIALIZED))return FPGA_ERR_STATE;
    return FPGA_OK;
}
FPGA_Status FPGA_GetResult(const FPGA_Bus *b,FPGA_Result *r)
{
    uint8_t p[60];FPGA_Status s;
    if(!r)return FPGA_ERR_ARGUMENT;
    memset(r,0,sizeof *r);
    s=FPGA_Read(b,0,p,sizeof p);if(s!=FPGA_OK)return s;
    if(p[0]!=0xAC||p[1]!=0x52||p[2]!=0x54||p[3]!=7||p[4]!=5)return FPGA_ERR_ID;
    r->capabilities=p[5];r->status=p[6];r->command_status=p[7];
    if(!(r->status&FPGA_STATUS_READY))return FPGA_ERR_NOT_READY;
    r->result_crc=le16(p+58);
    if(FPGA_Crc16(0xFFFFu,p+32,26)!=r->result_crc)return FPGA_ERR_CRC;
    r->frame_id=le32(p+32);r->water_pixels=le32(p+36);r->roi_pixels=le32(p+40);
    r->whole_water=le32(p+44);r->width=le16(p+48);r->height=le16(p+50);
    r->warning_percent=p[52];r->critical_percent=p[53];r->decision=p[54];r->source_schema=p[55];
    r->coverage_basis_points=le16(p+56);
    if((r->status&(FPGA_STATUS_BUSY|FPGA_STATUS_ERROR))||r->width!=256||r->height!=256||
       r->capabilities!=0x7A||r->source_schema!=0x43||r->whole_water>65536u||
       r->roi_pixels>65536u||r->water_pixels>r->roi_pixels||
       r->whole_water<r->water_pixels||r->warning_percent!=5||r->critical_percent!=25||
       r->decision>FPGA_LEVEL_CRITICAL)return FPGA_ERR_STATE;
    if(r->whole_water==0){
        /* Schema 43 explicitly permits ROI not run. No 0/0 percentage. */
        if(r->roi_pixels||r->water_pixels||r->decision!=FPGA_LEVEL_NORMAL||r->coverage_basis_points)
            return FPGA_ERR_STATE;
        r->roi_skipped=1;
    }else{
        if(r->roi_pixels<328u||r->decision!=FPGA_Level(r->water_pixels,r->roi_pixels))
            return FPGA_ERR_STATE;
        /* Cross-check only; publish the FPGA percentage itself. */
        if(r->coverage_basis_points>10000u ||
           r->coverage_basis_points!=r->water_pixels*10000u/r->roi_pixels)return FPGA_ERR_STATE;
    }
    return FPGA_OK;
}

uint16_t FPGA_Crc16(uint16_t crc,const uint8_t *p,size_t n)
{
    size_t i;unsigned bit;
    for(i=0;i<n;i++){
        crc^=(uint16_t)((uint16_t)p[i]<<8);
        for(bit=0;bit<8;bit++)crc=(uint16_t)((crc&0x8000u)?((uint32_t)crc<<1)^0x1021u:(uint32_t)crc<<1);
    }
    return crc;
}

