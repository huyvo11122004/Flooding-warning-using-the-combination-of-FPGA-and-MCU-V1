#ifndef TXS_SPI_P21_H
#define TXS_SPI_P21_H
#include <stdint.h>
#include "rs485_sn32f407_config.h"
/* P21 means MCU P2.1, not package pin 21. Output HIGH is a control
 * signal (OE/EN), not a regulated power rail for TXS VCCA/VCCB. */
#if RS485_MANUAL_DE && RS485_DE_PORT == 2u && RS485_DE_PIN == 1u
#error P2_1_is_reserved_for_TXS_control_select_another_RS485_DE_pin
#endif
#ifdef SN32_P21_HOST_TEST
extern uint32_t SN32_P21_TestRead(uint32_t address);
extern void SN32_P21_TestWrite(uint32_t address,uint32_t value);
#define P21_RD(a) SN32_P21_TestRead(a)
#define P21_WR(a,v) SN32_P21_TestWrite((a),(v))
#else
#define P21_RD(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define P21_WR(a,v) (*(volatile uint32_t *)(uintptr_t)(a)=(v))
#endif
static inline void TXS_P21_InitHigh(void)
{
    /* Set latch before enabling output; touch only GPIO2 bit 1 / CFG[3:2]. */
    P21_WR(0x40048024u,1u<<1);
    P21_WR(0x40048008u,(P21_RD(0x40048008u)&~(3u<<2))|(2u<<2));
    P21_WR(0x40048004u,P21_RD(0x40048004u)|(1u<<1));
}
static inline uint32_t TXS_P21_ReadLevel(void)
{
    return (P21_RD(0x40048000u)>>1)&1u;
}
#undef P21_RD
#undef P21_WR
#endif
