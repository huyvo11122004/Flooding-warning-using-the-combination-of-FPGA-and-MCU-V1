#ifndef SN32_TIME_MATH_H
#define SN32_TIME_MATH_H
#include <stdint.h>
/* cycles_per_us is 1..60; ticks is a 1-ms SysTick fraction (<60000).
 * reciprocal=ceil(65536/cycles_per_us), computed once during port init.
 * Ceiling reciprocal can overestimate floor(ticks/cycles) by at most 1;
 * one multiplication/comparison corrects it. No division in the IRQ path. */
static inline uint32_t SN32_CyclesToUs(uint32_t ticks,uint32_t cycles,uint32_t reciprocal)
{
    uint32_t q=(ticks*reciprocal)>>16;
    return q-(q*cycles>ticks?1u:0u);
}
#endif
