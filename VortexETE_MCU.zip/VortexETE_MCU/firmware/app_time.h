#ifndef APP_TIME_H
#define APP_TIME_H
#include <stdint.h>
extern volatile uint32_t app_ms;
#endif
