#include "rs485.h"
#include "app_config.h"

volatile uint32_t wind_diag_ready,wind_diag_attempts,wind_diag_phase;
volatile uint32_t wind_diag_status,wind_diag_tx_status;
volatile uint32_t wind_diag_tx_len,wind_diag_rx_count,wind_diag_uart_error;
volatile uint32_t wind_diag_exception;
volatile uint32_t wind_diag_tx[8],wind_diag_rx[16];

static uint32_t character_us;
static uint32_t gap15_us;
static uint32_t gap35_us;

RS485_Status RS485_ConfigureTiming(uint32_t baud, uint8_t bits)
{
    if (baud < 1200u || baud > 1000000u || bits < 10u || bits > 12u)
        return RS485_ERR_ARGUMENT;
    character_us = ((uint32_t)bits * 1000000u + baud - 1u) / baud;
    if (baud > 19200u) {
        gap15_us = 750u;
        gap35_us = 1750u;
    } else {
        gap15_us = ((uint32_t)bits * 1500000u + baud - 1u) / baud;
        gap35_us = ((uint32_t)bits * 3500000u + baud - 1u) / baud;
    }
    return RS485_OK;
}

uint16_t RS485_CRC16(const uint8_t *data, size_t length)
{
    uint16_t crc = 0xFFFFu;
    size_t i;
    unsigned bit;
    for (i = 0; i < length; ++i) {
        crc ^= data[i];
        for (bit = 0; bit < 8u; ++bit)
            crc = (uint16_t)((crc >> 1) ^ ((crc & 1u) ? 0xA001u : 0u));
    }
    return crc;
}

/* Flush old bytes and require silence. The global deadline also bounds noise. */
static RS485_Status wait_quiet(uint32_t start, uint32_t budget)
{
    uint32_t last = RS485_PortNowUs();
    uint8_t byte;
    for (;;) {
        int received = RS485_PortReceiveByte(&byte);
        uint32_t now = RS485_PortNowUs();
        if ((uint32_t)(now - start) >= budget)
            return RS485_ERR_BUS_BUSY;
        if (received != 0)
            last = now;
        else if ((uint32_t)(now - last) >= gap35_us)
            return RS485_OK;
    }
}

static RS485_Status read_registers_impl(uint8_t address, uint8_t function,
    uint16_t first, uint16_t count, uint16_t *values,
    uint8_t *exception_code, uint32_t timeout_ms,
    uint32_t reply_timeout_ms,int complete_on_length,int trace)
{
    uint8_t request[8];
    uint8_t response[5u + 2u * RS485_MAX_REGISTERS];
    size_t received = 0u;
    size_t expected = 5u + 2u * count;
    uint32_t start, last = 0u, now, budget, elapsed;
    uint16_t crc;
    uint16_t i;
    RS485_Status status;

    if (exception_code != NULL) *exception_code = 0u;
    if (address == 0u || address > 247u || (function != 3u && function != 4u)
        || count == 0u || count > RS485_MAX_REGISTERS || values == NULL
        || (uint32_t)first + count > 65536u
        || timeout_ms == 0u || timeout_ms > 60000u || reply_timeout_ms > 60000u)
        return RS485_ERR_ARGUMENT;
    if (gap35_us == 0u || !RS485_PortIsReady())
        return RS485_ERR_NOT_READY;

    budget = timeout_ms * 1000u;
    start = RS485_PortNowUs();
    if(trace)wind_diag_phase=WIND_DIAG_QUIET;
    status = wait_quiet(start, budget);
    if (status != RS485_OK) return status;

    request[0] = address;
    request[1] = function;
    request[2] = (uint8_t)(first >> 8);
    request[3] = (uint8_t)first;
    request[4] = (uint8_t)(count >> 8);
    request[5] = (uint8_t)count;
    crc = RS485_CRC16(request, 6u);
    request[6] = (uint8_t)crc;
    request[7] = (uint8_t)(crc >> 8);
    elapsed = (uint32_t)(RS485_PortNowUs() - start);
    if (elapsed >= budget) return RS485_ERR_TIMEOUT;
    if(trace){
        wind_diag_phase=WIND_DIAG_TX;wind_diag_tx_len=8;
        for(i=0;i<8;i++)wind_diag_tx[i]=request[i];
    }
    status = RS485_PortTransmit(request, sizeof(request), budget - elapsed);
    if(trace)wind_diag_tx_status=(uint32_t)status;
    if (status != RS485_OK) return status;
    if(reply_timeout_ms!=0u){
        /* Give this device the configured response window AFTER TX has
         * finished. Other callers keep the original shared transaction budget. */
        start=RS485_PortNowUs();budget=reply_timeout_ms*1000u;
    }
    if(trace)wind_diag_phase=WIND_DIAG_RX;

    for (;;) {
        uint8_t byte;
        int result = RS485_PortReceiveByte(&byte);
        now = RS485_PortNowUs();
        if(trace && result>0){
            if(wind_diag_rx_count<16)wind_diag_rx[wind_diag_rx_count]=byte;
            ++wind_diag_rx_count;
        }
        if(trace && result<0)wind_diag_uart_error=1;
        if ((uint32_t)(now - start) >= budget) return RS485_ERR_TIMEOUT;
        if (result < 0) return RS485_ERR_UART;
        if (result > 0) {
            /* Completion-to-completion gap includes the next character time. */
            if (received > 0u && (uint32_t)(now - last) > gap15_us + character_us)
                return RS485_ERR_GAP;
            if (received >= sizeof(response)) return RS485_ERR_LENGTH;
            response[received++] = byte;
            last = now;
            if (received == 2u && response[1] == (uint8_t)(function | 0x80u))
                expected = 5u;
            /* YJ-FS path: one requested frame, then mandatory validation below.
             * Do not wait for unrelated trailing traffic after its CRC bytes. */
            if(complete_on_length && received==expected)break;
        } else if (received > 0u) {
            elapsed = (uint32_t)(now - last);
            if (received < expected && elapsed > gap15_us + character_us)
                return RS485_ERR_GAP;
            if (elapsed >= gap35_us) break;
        }
    }

    if(trace)wind_diag_phase=WIND_DIAG_VALIDATE;
    if (received < 5u) return RS485_ERR_LENGTH;
    crc = RS485_CRC16(response, received - 2u);
    if (response[received - 2u] != (uint8_t)crc
        || response[received - 1u] != (uint8_t)(crc >> 8))
        return RS485_ERR_CRC;
    if (response[0] != address) return RS485_ERR_ADDRESS;
    if (response[1] == (uint8_t)(function | 0x80u)) {
        if (received != 5u) return RS485_ERR_LENGTH;
        if(trace)wind_diag_exception=response[2];
        if (exception_code != NULL) *exception_code = response[2];
        return RS485_ERR_EXCEPTION;
    }
    if (response[1] != function) return RS485_ERR_FUNCTION;
    if (received != 5u + 2u * count || response[2] != 2u * count)
        return RS485_ERR_LENGTH;
    for (i = 0u; i < count; ++i)
        values[i] = (uint16_t)(((uint16_t)response[3u + 2u * i] << 8)
            | response[4u + 2u * i]);
    return RS485_OK;
}

static RS485_Status read_transaction(uint8_t address,uint8_t function,
    uint16_t first,uint16_t count,uint16_t *values,
    uint8_t *exception_code,uint32_t timeout_ms,
    uint32_t reply_timeout_ms,int complete_on_length)
{
    RS485_Status result;
    unsigned i;
    int trace=address==WIND_MODBUS_ID;
    if(trace){
        wind_diag_ready=0;++wind_diag_attempts;wind_diag_phase=WIND_DIAG_CHECK;
        wind_diag_status=wind_diag_tx_status=0xFFFFFFFFu;
        wind_diag_tx_len=wind_diag_rx_count=wind_diag_uart_error=wind_diag_exception=0;
        for(i=0;i<8;i++)wind_diag_tx[i]=0;
        for(i=0;i<16;i++)wind_diag_rx[i]=0;
    }
    result=read_registers_impl(address,function,first,count,values,exception_code,
                               timeout_ms,reply_timeout_ms,complete_on_length,trace);
    if(trace){
        wind_diag_status=(uint32_t)result;
        if(result==RS485_OK)wind_diag_phase=WIND_DIAG_DONE;
        wind_diag_ready=1;
    }
    return result;
}

RS485_Status RS485_ReadRegisters(uint8_t address,uint8_t function,
    uint16_t first,uint16_t count,uint16_t *values,
    uint8_t *exception_code,uint32_t timeout_ms)
{
    return read_transaction(address,function,first,count,values,
                             exception_code,timeout_ms,0u,0);
}

RS485_Status getRS485(uint16_t values[2])
{
    return RS485_ReadRegisters(1u, 3u, 4u, 2u, values, NULL, 500u);
}
RS485_Status getWind(uint16_t *value)
{
    return read_transaction(WIND_MODBUS_ID,WIND_MODBUS_FUNCTION,WIND_MODBUS_REGISTER,
                             1u,value,NULL,WIND_TX_TIMEOUT_MS,WIND_REPLY_TIMEOUT_MS,
                             WIND_COMPLETE_ON_LENGTH!=0u);
}
RS485_Status getWind_huong(uint16_t *value)
{
    return RS485_ReadRegisters(DIRECTION_MODBUS_ID, 3u, 0u, 1u, value, NULL, 500u);
}
RS485_Status getWater_level(uint16_t *value)
{
    return RS485_ReadRegisters(WATER_MODBUS_ID, 3u, 0u, 1u, value, NULL, 500u);
}
const char *RS485_StatusText(RS485_Status status)
{
    switch (status) {
    case RS485_OK: return "OK";
    case RS485_ERR_ARGUMENT: return "ARGUMENT";
    case RS485_ERR_NOT_READY: return "NOT_READY";
    case RS485_ERR_TIMEOUT: return "TIMEOUT";
    case RS485_ERR_BUS_BUSY: return "BUS_BUSY";
    case RS485_ERR_UART: return "UART_ERROR";
    case RS485_ERR_LENGTH: return "LENGTH";
    case RS485_ERR_CRC: return "CRC";
    case RS485_ERR_ADDRESS: return "ADDRESS";
    case RS485_ERR_FUNCTION: return "FUNCTION";
    case RS485_ERR_GAP: return "INTERBYTE_GAP";
    case RS485_ERR_EXCEPTION: return "MODBUS_EXCEPTION";
    default: return "UNKNOWN";
    }
}
