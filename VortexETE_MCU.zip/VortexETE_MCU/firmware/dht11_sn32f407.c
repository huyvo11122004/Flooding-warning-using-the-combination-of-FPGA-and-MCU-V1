#include "dht11.h"
#include "app_config.h"
#include "rs485.h"
#ifndef SN32_GPIO_REG
#define SN32_GPIO_REG(a) (*(volatile uint32_t *)(uintptr_t)(a))
#endif
#define REG(a) SN32_GPIO_REG(a)
#define G2(off) REG(0x40048000u+(off))
#define MASK (1u<<DHT11_PIN)
#if DHT11_PIN != 9u
#error "DHT11 hardware adapter is P2.9; change adapter and wiring together"
#endif
void DHT11_HWInit(void)
{
    G2(0x18u)&=~MASK; /* disable just DHT interrupt during setup */
    G2(0x04u)&=~MASK; /* input releases the line */
    G2(0x08u)&=~(3u<<(2u*DHT11_PIN)); /* internal pullup; external 4.7k recommended */
    G2(0x0Cu)&=~MASK; /* edge sense */
    G2(0x10u)|=MASK;  /* both rising and falling edges */
    G2(0x20u)=MASK;
    /* P2 IRQ is shared with rain. Rain_HWInit already enables IRQ29.
     * Do not clear the shared NVIC pending bit here or replace its handler. */
}
void DHT11_HWBeginLow(void)
{
    G2(0x18u)&=~MASK;G2(0x28u)=MASK;G2(0x04u)|=MASK;
}
void DHT11_HWArmRelease(void)
{
    /* Arm BEFORE releasing GPIO so an early sensor reply cannot be missed. */
    G2(0x20u)=MASK;G2(0x18u)|=MASK;G2(0x04u)&=~MASK;
}
void DHT11_HWEnd(void)
{
    G2(0x18u)&=~MASK;G2(0x04u)&=~MASK;G2(0x20u)=MASK;
}
int DHT11_HWRead(void){return (G2(0)&MASK)!=0u;}
uint32_t DHT11_HWNowUs(void){return RS485_PortNowUs();}
