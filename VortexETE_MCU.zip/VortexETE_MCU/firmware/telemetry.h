#ifndef TELEMETRY_H
#define TELEMETRY_H
#include <stddef.h>
#include <stdint.h>
#include "rs485.h"
typedef struct {
    uint32_t uptime_ms,rain_pulses;
    uint16_t water,wind,direction;
    RS485_Status water_status,wind_status,direction_status;
    uint16_t temperature_x10,humidity_x10;
    int dht_valid;
    unsigned dht_status;
    uint32_t sim_voltage_mv;
    unsigned sim_signal_percent;
    int sim_voltage_valid,sim_signal_valid;
    uint32_t rain_hour_pulses,rain_day_pulses,rain_hour_elapsed_s,rain_day_elapsed_s;
    int rain_hour_valid,rain_day_valid;
} TelemetrySample;
int Telemetry_Build(char *out,size_t capacity,const TelemetrySample *sample);
#endif
