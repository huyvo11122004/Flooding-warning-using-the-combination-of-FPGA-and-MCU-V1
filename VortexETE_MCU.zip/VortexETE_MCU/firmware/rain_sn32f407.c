/* Offsets, IRQ numbers verified against official SONiX SN32F4_DFP 1.1.1. */
#include "rain.h"
#include "dht11.h"
#include "app_config.h"
#include "app_time.h"
#ifndef SN32_GPIO_REG
#define SN32_GPIO_REG(a) (*(volatile uint32_t *)(uintptr_t)(a))
#endif
#define REG(a) SN32_GPIO_REG(a)
#define G2(off) REG(0x40048000u+(off))
#define MASK (1u<<RAIN_PIN)
#if RAIN_PIN != 8u
#error "Rain hardware adapter is wired to P2.8; revise adapter and wiring together"
#endif
int Rain_HWInit(void)
{
    /* GPIO has no separate clock enable bit in this device SYS1 register. */
    G2(0x18u)&=~MASK;
    G2(0x04u)&=~MASK; /* input */
    G2(0x08u)&=~(3u<<(2u*RAIN_PIN)); /* internal pull-up */
    G2(0x0Cu)&=~MASK; /* edge sense */
    G2(0x10u)&=~MASK; /* single edge */
    G2(0x14u)|=MASK; /* falling */
    G2(0x20u)=MASK; /* W1C only our pin */
    ((volatile uint8_t *)(uintptr_t)0xE000E400u)[29]=0x00u; /* GPIO2/DHT preempts SIM UART0 (0x40); no global IRQ masking. */
    REG(0xE000E280u)=1u<<29; /* NVIC clear stale pending */
    G2(0x18u)|=MASK;
    REG(0xE000E100u)=1u<<29;
    return 1;
}
void P2_IRQHandler(void)
{
    uint32_t pending=G2(0x1Cu)&G2(0x18u);
    /* Capture DHT timing first; clear each pin's W1C flag independently. */
    if(pending&(1u<<DHT11_PIN)) {
        uint32_t at=DHT11_HWNowUs();
        int high=DHT11_HWRead();
        G2(0x20u)=1u<<DHT11_PIN;
        DHT11_OnEdgeISR(high,at);
    }
    if(pending&MASK) {
        G2(0x20u)=MASK;
        Rain_OnFallingEdgeISR(app_ms);
    }
}
