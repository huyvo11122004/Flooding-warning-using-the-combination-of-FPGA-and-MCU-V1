#ifndef APP_CONFIG_H
#define APP_CONFIG_H
/* Bring-up only: capture real camera frames without attached rain/water sensors.
 * Set 0 and rebuild to restore the original POST_RAIN sensor gate. */
#ifndef CAMERA_TEST_WITHOUT_SENSORS
#define CAMERA_TEST_WITHOUT_SENSORS 0
#endif
#ifndef CAMERA_TEST_INTERVAL_MS
#define CAMERA_TEST_INTERVAL_MS 1000u
#endif
/* Automatic fallback is enabled even with manual test mode disabled.
 * A failed or stale water sensor triggers real camera inference, independent
 * of rain. On valid sensor recovery, the original POST_RAIN gate resumes. */
#ifndef CAMERA_WATER_FAILOVER_ENABLE
#define CAMERA_WATER_FAILOVER_ENABLE 1
#endif
#ifndef CAMERA_FALLBACK_INTERVAL_MS
#define CAMERA_FALLBACK_INTERVAL_MS 10000u
#endif
/* Camera gate: no accepted rain tip for this long AND water > threshold.
 * Observe a full quiet interval after boot, too. Demo default: 5 minutes.
 * Hour/day rainfall accounting and web telemetry remain independent. */
#ifndef CAMERA_RAIN_QUIET_MS
#define CAMERA_RAIN_QUIET_MS 300000u
#endif
#ifndef CAMERA_WATER_HIGH_THRESHOLD_MILLI_MM
#define CAMERA_WATER_HIGH_THRESHOLD_MILLI_MM 100000u /* water > 100.000 mm */
#endif
#ifndef CAMERA_SENSOR_STALE_MS
#define CAMERA_SENSOR_STALE_MS 15000u
#endif
/* CAMERA FIX: source VGA is resized in FPGA; SPI still reports 256x256.
 * Preserve V9 post-rain policy and image-based repeat intervals.
 * Set Normal interval to zero for event-only mode if desired. */
#ifndef FPGA_NORMAL_DEMO_INTERVAL_MS
#define FPGA_NORMAL_DEMO_INTERVAL_MS 10000u
#endif
#ifndef FPGA_WARNING_INTERVAL_MS
#define FPGA_WARNING_INTERVAL_MS 60000u
#endif
#ifndef FPGA_CRITICAL_INTERVAL_MS
#define FPGA_CRITICAL_INTERVAL_MS 1000u
#endif
#ifndef FPGA_SCAN_TIMEOUT_MS
#define FPGA_SCAN_TIMEOUT_MS 45000u
#endif
#ifndef FPGA_RESULT_STALE_MS
#define FPGA_RESULT_STALE_MS 90000u
#endif
#ifndef FPGA_RESULT_POLL_MS
#define FPGA_RESULT_POLL_MS 100u
#endif
#ifndef FPGA_RETRY_BACKOFF_MS
#define FPGA_RETRY_BACKOFF_MS 30000u
#endif
#define SENSOR_BAUD 9600u
#define SENSOR_PARITY 'N'
#define SENSOR_STOP_BITS 1u
/* Preserve IDs actually present in this uploaded project. */
#define WATER_MODBUS_ID 1u
#define WIND_MODBUS_ID 5u /* user-confirmed YJ-FS address */
/* YJ-FS: parameters match the user's known request frame.
 * TX/quiet budget and full post-TX reply budget are independent. */
#ifndef WIND_MODBUS_FUNCTION
#define WIND_MODBUS_FUNCTION 3u
#endif
#ifndef WIND_MODBUS_REGISTER
#define WIND_MODBUS_REGISTER 0u
#endif
#ifndef WIND_TX_TIMEOUT_MS
#define WIND_TX_TIMEOUT_MS 500u
#endif
#ifndef WIND_REPLY_TIMEOUT_MS
#define WIND_REPLY_TIMEOUT_MS 1000u
#endif
/* 1: validate as soon as the complete requested response is received.
 * CRC/address/function/byte count remain mandatory; 0 restores quiet-end wait. */
#ifndef WIND_COMPLETE_ON_LENGTH
#define WIND_COMPLETE_ON_LENGTH 1u
#endif
#define DIRECTION_MODBUS_ID 6u /* set 3 ONLY if the physical sensor is ID3 */
/* SIM UART0: P3.1 TX / P3.2 RX, EVK J10 pins 1/2.
 * RS485 UART1: P2.2 TX / P2.3 RX, EVK J7 pins 2/3. */
#define SIM_UART_BAUD 115200u /* match actual A7680C configuration */
#define SIM_COMMAND_TIMEOUT_MS 3000u
#define SIM_POLL_MS 30000u
#define SIM_HEALTH_POLL_MS 30000u
#define SIM_HEALTH_STALE_MS 120000u
#define SIM_HEALTH_TIMEOUT_MS 9000u
/* Empty APN keeps the modem's current carrier profile. Set your actual APN
 * if data cannot connect; AT registration alone does not prove Internet access. */
#define SIM_APN ""
#define MQTT_BROKER "broker.emqx.io"
#define MQTT_PORT 1883u
#define MQTT_DEVICE_ID 1u /* station/database ID, unrelated to Modbus IDs */
#define MQTT_CLIENT_ID "vortexete-sn32-station1-long01" /* unique per board */
#define MQTT_PUBLISH_INTERVAL_MS 10000u
/* Unknown conversion -> NULL on web, raw register remains in MQTT/Watch.
 * Units: milli-mm per raw water unit; milli-m/s per raw speed unit;
 * milli-degree per raw direction unit. Set only after checking sensor manuals.
 * Examples ONLY: raw water in mm -> 1000; raw speed in 0.1 m/s -> 100;
 * direction code 0..7 at 45 degrees/step -> 45000. */
#ifndef WATER_MILLI_MM_PER_RAW
#define WATER_MILLI_MM_PER_RAW 1000u
#endif
#ifndef WIND_MILLI_MPS_PER_RAW
#define WIND_MILLI_MPS_PER_RAW 100u
#endif
#ifndef DIRECTION_MILLI_DEG_PER_RAW
#define DIRECTION_MILLI_DEG_PER_RAW 45000u
#endif
/* Proposed wiring: P2.8 / J7 pin 4, passive reed/open-drain to GND.
 * This driver implements exactly GPIO2 pin 8; update hardware adapter if changed. */
#define RAIN_PIN 8u
#define RAIN_DEBOUNCE_MS 1000u /* provisional minimum accepted edge spacing */
/* USER-ASSUMED calibration: 200 um = 0.2 mm per accepted tip.
 * Change this one value after checking/calibrating the actual rain gauge. */
#ifndef RAIN_UM_PER_TIP
#define RAIN_UM_PER_TIP 200u
#endif
/* DHT11 DATA P2.9, next to rain P2.8 on J7. */
#define DHT11_PIN 9u
#define DHT11_WARMUP_MS 2000u
#define DHT11_READ_INTERVAL_MS 5000u
#define DHT11_STALE_MS 15000u
#endif
