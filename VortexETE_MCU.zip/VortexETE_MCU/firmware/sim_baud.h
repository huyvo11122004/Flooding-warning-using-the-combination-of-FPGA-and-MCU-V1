#ifndef SIM_BAUD_H
#define SIM_BAUD_H
#include <stdint.h>
typedef struct {
    uint32_t divisor,oversampling,actual_baud,fd;
} SIM_BaudConfig;
/* Prefer 16x for receiver tolerance; fall back to 8x if integer error >2%.
 * FD MULVAL=1, DIVADDVAL=0, OVER8 selects 8x. No invalid MULVAL=0. */
static int SIM_BaudPlan(uint32_t hclk,uint32_t baud,SIM_BaudConfig *out)
{
    uint32_t over;
    if(!out||baud<1200u||baud>1000000u||hclk<1000000u||hclk>60000000u)return 0;
    for(over=16u;over>=8u;over/=2u) {
        uint32_t div=(hclk+(over/2u)*baud)/(over*baud);
        uint32_t actual,error;
        if(!div||div>65535u)continue;
        actual=hclk/(over*div);
        error=actual>baud?actual-baud:baud-actual;
        if((uint64_t)error*100u>(uint64_t)baud*2u)continue;
        out->divisor=div;out->oversampling=over;out->actual_baud=actual;
        out->fd=0x10u|((over==8u)?0x100u:0u);
        return 1;
    }
    return 0;
}
#endif
