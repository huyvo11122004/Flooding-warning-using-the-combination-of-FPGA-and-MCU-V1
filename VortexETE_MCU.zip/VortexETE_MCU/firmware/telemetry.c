#include "telemetry.h"
#include "dht11.h"
#include "app_config.h"
#include <stdio.h>
#include <string.h>
static void number(char out[32],uint64_t milli,int valid)
{
    if(!valid){strcpy(out,"null");return;}
    if(milli/1000u>0xffffffffu){strcpy(out,"null");return;}
    (void)snprintf(out,32,"%lu.%03lu",(unsigned long)(milli/1000u),
                  (unsigned long)(milli%1000u));
}
int Telemetry_Build(char *out,size_t capacity,const TelemetrySample *s)
{
    char water[32],wind[32],direction[32],rain[32],temperature[32],humidity[32],voltage[32],signal[32],rain_hour[32],rain_day[32];int n;
    if(!out||!capacity||!s)return 0;
    number(water,(uint64_t)s->water*WATER_MILLI_MM_PER_RAW,
           s->water_status==RS485_OK&&WATER_MILLI_MM_PER_RAW!=0u);
    number(wind,(uint64_t)s->wind*WIND_MILLI_MPS_PER_RAW,
           s->wind_status==RS485_OK&&WIND_MILLI_MPS_PER_RAW!=0u);
    number(direction,(uint64_t)s->direction*DIRECTION_MILLI_DEG_PER_RAW,
           s->direction_status==RS485_OK&&DIRECTION_MILLI_DEG_PER_RAW!=0u&&
           (uint64_t)s->direction*DIRECTION_MILLI_DEG_PER_RAW<360000u);
    /* One um equals one milli-mm. Period totals are separate from since-boot. */
    number(rain,(uint64_t)s->rain_pulses*RAIN_UM_PER_TIP,RAIN_UM_PER_TIP!=0u);
    number(rain_hour,(uint64_t)s->rain_hour_pulses*RAIN_UM_PER_TIP,s->rain_hour_valid&&RAIN_UM_PER_TIP!=0u);
    number(rain_day,(uint64_t)s->rain_day_pulses*RAIN_UM_PER_TIP,s->rain_day_valid&&RAIN_UM_PER_TIP!=0u);
    number(temperature,(uint32_t)s->temperature_x10*100u,s->dht_valid);
    number(humidity,(uint32_t)s->humidity_x10*100u,s->dht_valid);
    number(voltage,s->sim_voltage_mv,s->sim_voltage_valid&&s->sim_voltage_mv>0&&s->sim_voltage_mv<=20000u);
    number(signal,(uint32_t)s->sim_signal_percent*1000u,s->sim_signal_valid&&s->sim_signal_percent<=100u);
    n=snprintf(out,capacity,
        "{\"device_id\":%lu,\"uptime_ms\":%lu,"
        "\"water_level\":%s,\"wind_direction\":%s,\"wind_speed\":%s,"
        "\"temperature\":%s,\"humidity\":%s,\"hourly_rainfall\":%s,"
        "\"daily_rainfall\":%s,\"voltage\":%s,\"wave_level\":%s,"
        "\"dht_status\":%u,\"device_status\":%u,\"rain_pulses\":%lu,\"rain_total_since_boot_mm\":%s,"
        "\"rain_period\":\"uptime\",\"rain_hour_elapsed_s\":%lu,\"rain_day_elapsed_s\":%lu,"
        "\"raw\":{\"water\":%u,\"wind\":%u,\"direction\":%u},"
        "\"modbus_status\":{\"water\":%u,\"wind\":%u,\"direction\":%u}}",
        (unsigned long)MQTT_DEVICE_ID,(unsigned long)s->uptime_ms,water,direction,wind,
        temperature,humidity,rain_hour,rain_day,voltage,signal,s->dht_status,
        (unsigned)(s->water_status!=RS485_OK||s->wind_status!=RS485_OK||
                   s->direction_status!=RS485_OK||
                   (!s->dht_valid&&s->dht_status>=DHT11_ERR_TIMEOUT)?2:1),
        (unsigned long)s->rain_pulses,rain,(unsigned long)s->rain_hour_elapsed_s,
        (unsigned long)s->rain_day_elapsed_s,(unsigned)s->water,(unsigned)s->wind,
        (unsigned)s->direction,(unsigned)s->water_status,(unsigned)s->wind_status,
        (unsigned)s->direction_status);
    if(n<=0||(size_t)n>=capacity){out[0]=0;return 0;}
    return 1;
}
