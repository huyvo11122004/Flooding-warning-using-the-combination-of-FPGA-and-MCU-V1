#include "sim_uart.h"
#include "sim_baud.h"
#include "rs485.h"
#include "rs485_sn32f407_config.h"
#if RS485_UART_INDEX != 1u
#error "This adapter reserves UART0 for SIM; RS485 must use UART1"
#endif
#include <stddef.h>
#define REG(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define U(off) REG(0x40016000u+(off))
#define QMASK 511u
static volatile uint8_t queue[512];
static volatile uint32_t head,tail,fault;
volatile uint32_t sim_uart_overflows,sim_uart_line_errors;
volatile uint32_t sim_actual_baud,sim_oversampling,sim_init_error;
static int ready;
int SIM_UART_Init(uint32_t hclk,uint32_t baud)
{
    uint32_t div,budget=100000u;
    SIM_BaudConfig plan;
    ready=0;sim_actual_baud=sim_oversampling=0;sim_init_error=1;
    if(baud<1200u||baud>1000000u||hclk<1000000u||hclk>60000000u)return 0;
    sim_init_error=2;
    if(!SIM_BaudPlan(hclk,baud,&plan))return 0;
    div=plan.divisor;
    sim_init_error=3;
    REG(0xE000E180u)=1u<<13;
    REG(0x4005E000u)|=1u<<16;
    REG(0x4005E010u)=1u<<16;
    while(REG(0x4005E010u)&(1u<<16))if(--budget==0u)return 0;
    U(0x30u)=0;
    REG(0x40042020u)=(REG(0x40042020u)&~15u)|2u|(2u<<2);
    U(0x0Cu)=3u|(1u<<7);
    U(0)=div&255u;U(4)=(div>>8)&255u;
    U(0x28u)=plan.fd;U(0x0Cu)=3u;U(4)=0;
    U(8)=1u;U(0x34u)=0;U(0x50u)=0;
    head=tail=fault=sim_uart_overflows=sim_uart_line_errors=0;
    U(0x30u)=(1u<<7)|(1u<<6)|1u;
    ((volatile uint8_t *)(uintptr_t)0xE000E400u)[13]=0x40u;
    REG(0xE000E280u)=1u<<13;
    U(4)=5u; /* RDA and line-status interrupts */
    sim_actual_baud=plan.actual_baud;sim_oversampling=plan.oversampling;
    sim_init_error=0;ready=1;REG(0xE000E100u)=1u<<13;
    return 1;
}
void UART0_IRQHandler(void)
{
    unsigned budget=32u;
    while(budget--) {
        uint32_t ls=U(0x14u);
        if(ls&0x9Eu) {++sim_uart_line_errors;fault=1;}
        if(!(ls&1u))break;
        {
            uint8_t c=(uint8_t)U(0);
            uint32_t next=(head+1u)&QMASK;
            if(next==tail){++sim_uart_overflows;fault=1;}
            else {queue[head]=c;head=next;}
        }
    }
}
int SIM_UART_Read(uint8_t *byte)
{
    if(!ready||!byte)return -1;
    if(fault) {fault=0;tail=head;return -1;}
    if(head==tail)return 0;
    *byte=queue[tail];tail=(tail+1u)&QMASK;return 1;
}
int SIM_UART_Send(const char *cmd)
{
    uint32_t start=RS485_PortNowUs();
    if(!ready||!cmd)return 0;
    while(*cmd) {
        while(!(U(0x14u)&(1u<<5)))
            if((uint32_t)(RS485_PortNowUs()-start)>100000u)return 0;
        if((uint32_t)(RS485_PortNowUs()-start)>100000u)return 0;
        U(0)=(uint8_t)*cmd++;
    }
    while(!(U(0x14u)&(1u<<6)))
        if((uint32_t)(RS485_PortNowUs()-start)>100000u)return 0;
    return 1;
}
