#ifndef SPI0_MASTER_H
#define SPI0_MASTER_H
#include <stdint.h>
#include <stddef.h>
/* One shared selection prevents duplicate symbols even if Keil compiles
 * both source files. This application uses GPIO SPI (1), matching the verified wire timing. */
#ifndef SN32_SPI_USE_GPIO
#define SN32_SPI_USE_GPIO 1
#endif
#ifndef SN32_SPI_SCK_DIAG
#define SN32_SPI_SCK_DIAG 0
#endif
#if SN32_SPI_SCK_DIAG && !SN32_SPI_USE_GPIO
#error SCK_diagnostic_requires_GPIO_backend
#endif
#if SN32_SPI_USE_GPIO != 0 && SN32_SPI_USE_GPIO != 1
#error SN32_SPI_USE_GPIO_must_be_0_or_1
#endif
typedef struct {
 void *context;
 void (*select)(void *,int);
 uint8_t (*transfer)(void *,uint8_t);
 int (*error)(void *);
} SPI_Bus;
/* SPI0 hardware master, standalone application. */
enum {
    SN32_SPI_ERR_CLOCK=1,SN32_SPI_ERR_CONFIG=2,SN32_SPI_ERR_RESET=3,
    SN32_SPI_ERR_TX=4,SN32_SPI_ERR_RX=5,SN32_SPI_ERR_BUSY=6,
    SN32_SPI_ERR_OVERFLOW=7,SN32_SPI_ERR_LOOPBACK=8,
    SN32_SPI_ERR_NOT_READY=9,SN32_SPI_ERR_NOT_SELECTED=10,SN32_SPI_ERR_OWNER=11
};
void SN32_SPI_Init(uint32_t hclk_hz);
const SPI_Bus *SN32_SPI_Bus(void);
void SN32_SPI_Pause(void);
extern volatile uint32_t spi0_hw_ready,spi0_loopback_ok,spi0_last_error;
extern volatile uint32_t spi0_error_count,spi0_transferred_bytes,spi0_transactions;
extern volatile uint32_t spi0_sck_hz,spi0_stat_at_error,spi0_ris_at_error;
extern volatile uint32_t spi0_backend; /* 0=hardware SPI0, 1=GPIO SPI */
uint32_t SN32_SPI_ReadPins(void); /* GPIO1 levels, diagnostic only */
#if SN32_SPI_USE_GPIO
/* Requires SPI_SCK_DIAG FPGA image. mode=0 raw, mode=1 filtered. */
int SN32_SPI_ProbeSCK(uint8_t mode,uint8_t samples[2]);
#endif
#endif
