#include "rain.h"
#include "app_config.h"
#include <limits.h>
#include <stddef.h>
/* Single producer (GPIO ISR), single consumer (foreground). Each accepted
 * edge carries its MCU timestamp; period accounting never runs in the DHT IRQ.
 * 15 queued events fit in 64 bytes; overrun invalidates affected periods. */
#define RAIN_QUEUE_MASK 15u
#define HOUR_MS 3600000u
#define DAY_MS 86400000u
static volatile uint32_t pulses,queue[16],head,tail,overflow_at;
volatile uint32_t rain_rejected_edges,rain_saturated,rain_queue_overflows;
static volatile uint32_t last_edge,activity_sequence;
static uint32_t hour_at,day_at,hour_count,day_count,overflows_seen;
static uint32_t activity_seen,quiet_updated_at,quiet_elapsed;
static int seen_edge,hour_good,day_good;
void Rain_ResetAt(uint32_t now)
{
    pulses=rain_rejected_edges=rain_saturated=rain_queue_overflows=0;
    head=tail=overflow_at=0;last_edge=now;seen_edge=0;
    activity_sequence=activity_seen=quiet_elapsed=0;quiet_updated_at=now;
    hour_at=day_at=now;hour_count=day_count=overflows_seen=0;
    hour_good=day_good=1;
}
void Rain_Reset(void){Rain_ResetAt(0);}
void Rain_OnFallingEdgeISR(uint32_t now)
{
    uint32_t next;
    if(seen_edge&&(uint32_t)(now-last_edge)<RAIN_DEBOUNCE_MS){
        ++rain_rejected_edges;return;
    }
    seen_edge=1;last_edge=now;++activity_sequence;
    if(pulses==UINT32_MAX)rain_saturated=1;else ++pulses;
    next=(head+1u)&RAIN_QUEUE_MASK;
    if(next==tail){overflow_at=now;++rain_queue_overflows;return;}
    queue[head]=now;head=next;
}
static void advance(uint32_t now)
{
    uint32_t elapsed=(uint32_t)(now-hour_at);
    if(elapsed>=HOUR_MS){
        hour_at+=(elapsed/HOUR_MS)*HOUR_MS;hour_count=0;hour_good=1;
    }
    elapsed=(uint32_t)(now-day_at);
    if(elapsed>=DAY_MS){
        day_at+=(elapsed/DAY_MS)*DAY_MS;day_count=0;day_good=1;
    }
}
void Rain_Process(uint32_t now)
{
    uint32_t at,limit=head,missed;
    while(tail!=limit){
        at=queue[tail];
        /* ISR may have enqueued an event after the caller sampled now.
         * Leave that future event for the next call, including ms rollover. */
        if((int32_t)(at-now)>0)break;
        advance(at);
        if(hour_count==UINT32_MAX)hour_good=0;else ++hour_count;
        if(day_count==UINT32_MAX)day_good=0;else ++day_count;
        tail=(tail+1u)&RAIN_QUEUE_MASK;
    }
    advance(now);
    missed=rain_queue_overflows;
    if(missed!=overflows_seen){
        hour_good=day_good=0;
        /* If the overrun happened after the caller sampled now, do not
         * consume its notification before advancing to its actual period. */
        if((int32_t)(overflow_at-now)<=0)overflows_seen=missed;
    }
}
void Rain_GetSnapshot(uint32_t now,RainSnapshot *s)
{
    if(!s)return;
    Rain_Process(now);
    s->hour_pulses=hour_count;s->day_pulses=day_count;
    s->hour_elapsed_ms=(uint32_t)(now-hour_at);s->day_elapsed_ms=(uint32_t)(now-day_at);
    s->hour_valid=hour_good&&Rain_Calibrated();s->day_valid=day_good&&Rain_Calibrated();
}
uint32_t Rain_Pulses(void){return pulses;}
uint32_t Rain_QuietMs(uint32_t now)
{
    uint32_t before,sequence,at,delta;
    /* Aligned volatile 32-bit reads; retry if an IRQ changes the timestamp.
     * No IRQ masking, and no dependency on the bounded period-event queue. */
    do {
        before=activity_sequence;at=last_edge;sequence=activity_sequence;
    } while(before!=sequence);
    if(sequence!=activity_seen){
        /* IRQ may have happened after the caller sampled now. Do not consume
         * its notification until now reaches that edge, including ms wrap. */
        if((int32_t)(at-now)>0){
            quiet_elapsed=0;quiet_updated_at=now;return 0;
        }
        quiet_elapsed=(uint32_t)(now-at);activity_seen=sequence;
    }else{
        delta=(uint32_t)(now-quiet_updated_at);
        quiet_elapsed=delta>UINT32_MAX-quiet_elapsed?UINT32_MAX:quiet_elapsed+delta;
    }
    quiet_updated_at=now;return quiet_elapsed;
}
uint64_t Rain_TotalUm(void){return (uint64_t)Rain_Pulses()*RAIN_UM_PER_TIP;}
int Rain_Calibrated(void){return RAIN_UM_PER_TIP!=0u;}
