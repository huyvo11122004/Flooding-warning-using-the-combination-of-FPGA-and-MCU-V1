/* Alternative diagnostic backend: actual SPI Mode 0 on the SAME pins.
 * No SPI peripheral loopback; MISO always comes from the external pin.
 * Conservative delay loop is intentionally slow, not frequency-calibrated.
 */
#include "spi0_master.h"
#if SN32_SPI_USE_GPIO
#ifdef SN32_SPI_HOST_TEST
extern uint32_t SN32_TestRead(uint32_t address);
extern void SN32_TestWrite(uint32_t address,uint32_t value);
#define RD(a) SN32_TestRead(a)
#define WR(a,v) SN32_TestWrite((a),(v))
#else
#define RD(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define WR(a,v) (*(volatile uint32_t *)(uintptr_t)(a)=(v))
#endif
#define GPIO_DATA 0x40046000u
#define GPIO_MODE 0x40046004u
#define GPIO_CFG 0x40046008u
#define GPIO_SET 0x40046024u
#define GPIO_CLR 0x40046028u
#define CLK_EN 0x4005E000u
#define CTRL0 0x4001C000u
#define CS 256u
#define SCK 1u
#define MISO 2u
#define MOSI 4u
volatile uint32_t spi0_hw_ready,spi0_loopback_ok,spi0_last_error;
volatile uint32_t spi0_error_count,spi0_transferred_bytes,spi0_transactions;
volatile uint32_t spi0_sck_hz,spi0_stat_at_error,spi0_ris_at_error;
volatile uint32_t spi0_backend=1;
static uint32_t delay_iterations;
static int selected;
static void delay_half(void){volatile uint32_t i;for(i=0;i<delay_iterations;i++){}}
static void fault(uint32_t code){if(!spi0_last_error){spi0_last_error=code;++spi0_error_count;}}
static void select_bus(void *context,int active)
{
    (void)context;
    if(!active){delay_half();WR(GPIO_CLR,SCK);WR(GPIO_SET,CS);delay_half();selected=0;return;}
    if(selected){fault(SN32_SPI_ERR_OWNER);return;}
    if(!spi0_hw_ready){fault(SN32_SPI_ERR_NOT_READY);return;}
    spi0_last_error=0;WR(GPIO_CLR,SCK);WR(GPIO_SET,CS);delay_half();
    WR(GPIO_CLR,CS);selected=1;++spi0_transactions;delay_half();
}
static uint8_t transfer(void *context,uint8_t value)
{
    unsigned i;uint8_t rx=0;(void)context;
    if(!selected){fault(SN32_SPI_ERR_NOT_SELECTED);return 0;}
    if(spi0_last_error)return 0;
    for(i=0;i<8;i++){
        WR((value&0x80u)?GPIO_SET:GPIO_CLR,MOSI);value=(uint8_t)(value<<1);
        delay_half();WR(GPIO_SET,SCK);delay_half();
        rx=(uint8_t)((rx<<1)|((RD(GPIO_DATA)&MISO)?1u:0u));
        WR(GPIO_CLR,SCK);
    }
    delay_half();++spi0_transferred_bytes;return rx;
}
static int bus_error(void *context){(void)context;return (int)spi0_last_error;}
static const SPI_Bus bus={0,select_bus,transfer,bus_error};
void SN32_SPI_Init(uint32_t hclk_hz)
{
    spi0_hw_ready=spi0_loopback_ok=spi0_last_error=0;
    spi0_error_count=spi0_transferred_bytes=spi0_transactions=0;
    spi0_sck_hz=spi0_stat_at_error=spi0_ris_at_error=0;selected=0;
    if(hclk_hz<1000000u||hclk_hz>60000000u)hclk_hz=60000000u;
    delay_iterations=hclk_hz/100000u+2u;
    WR(CLK_EN,RD(CLK_EN)|(1u<<12));(void)RD(CLK_EN);
    WR(CTRL0,(1u<<18)|(7u<<8)); /* SPIEN=0 returns SPI pins to GPIO */
    WR(GPIO_SET,CS);WR(GPIO_CLR,SCK|MOSI);
    WR(GPIO_CFG,(RD(GPIO_CFG)&~0x0003003Fu)|0x0002002Au);
    WR(GPIO_MODE,(RD(GPIO_MODE)&~MISO)|CS|SCK|MOSI);
    delay_half();spi0_hw_ready=1;
}
const SPI_Bus *SN32_SPI_Bus(void){return &bus;}
uint32_t SN32_SPI_ReadPins(void){return RD(GPIO_DATA);}
void SN32_SPI_Pause(void){unsigned i;for(i=0;i<25000u;i++)delay_half();}

int SN32_SPI_ProbeSCK(uint8_t mode,uint8_t samples[2])
{
    if(selected || !spi0_hw_ready)return 0;
    WR(mode?GPIO_SET:GPIO_CLR,MOSI);delay_half();
    select_bus(0,1);
    if(spi0_last_error)return 0;
    WR(GPIO_CLR,SCK);delay_half();samples[0]=(RD(GPIO_DATA)&MISO)?1u:0u;
    WR(GPIO_SET,SCK);delay_half();samples[1]=(RD(GPIO_DATA)&MISO)?1u:0u;
    WR(GPIO_CLR,SCK);delay_half();select_bus(0,0);
    return !spi0_last_error && samples[0]==0 && samples[1]==1;
}
#endif /* selected SPI backend */
