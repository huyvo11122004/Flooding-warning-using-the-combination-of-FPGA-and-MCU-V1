#include <stdint.h>
#include <assert.h>
#include <stdio.h>
static uint32_t data=0,mode=0x00000300u,cfg=0xA5A5A5A5u;
static unsigned calls;static uint32_t addresses[3];
uint32_t SN32_P21_TestRead(uint32_t a)
{
    switch(a){case 0x40048000u:return data;case 0x40048004u:return mode;case 0x40048008u:return cfg;default:assert(0);return 0;}
}
void SN32_P21_TestWrite(uint32_t a,uint32_t v)
{
    assert(calls<3);addresses[calls++]=a;
    switch(a){case 0x40048024u:assert(v==2);data|=v;break;
    case 0x40048004u:assert(data&2);mode=v;break;case 0x40048008u:cfg=v;break;default:assert(0);}
}
#define SN32_P21_HOST_TEST
#include "txs_spi_p21.h"
int main(void)
{
    const uint32_t old_cfg=cfg,old_mode=mode;
    assert(TXS_P21_ReadLevel()==0);TXS_P21_InitHigh();
    assert(calls==3&&addresses[0]==0x40048024u&&addresses[1]==0x40048008u&&addresses[2]==0x40048004u);
    assert(mode==(old_mode|2u));assert(cfg==((old_cfg&~12u)|8u));assert(TXS_P21_ReadLevel()==1);
    puts("PASS P2.1 HIGH: latch before output, preserve other GPIO2 pins/config, physical readback");
}
