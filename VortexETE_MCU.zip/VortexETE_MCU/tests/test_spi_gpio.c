#include "fpga_spi.h"
#include "spi0_master.h"
#include <assert.h>
#include <stdio.h>
static uint32_t pins=256,mode,cfg,ctrl,clk;
static unsigned selected,bits,byte,transaction,rxbyte,received;
static const unsigned replies[]={0,0,0,0,0,0xAC,0x52,0x54,7,5};
uint32_t SN32_TestRead(uint32_t address)
{
    switch(address){case 0x40046000:return pins;case 0x40046004:return mode;case 0x40046008:return cfg;case 0x4005E000:return clk;default:assert(0);return 0;}
}
void SN32_TestWrite(uint32_t address,uint32_t value)
{
    if(address==0x40046004){mode=value;return;}
    if(address==0x40046008){cfg=value;return;}
    if(address==0x4001C000){ctrl=value;return;}
    if(address==0x4005E000){clk=value;return;}
    assert(address==0x40046024||address==0x40046028);
    if(address==0x40046028){
        pins&=~value;
        if(value&256){assert(!selected);selected=1;bits=byte=0;++transaction;}
        return;
    }
    pins|=value;
    if(value&256){
        if(selected){assert(bits==0);assert(byte==(transaction==1?1u:9u));}
        selected=0;
    }
    if(value&1){
        assert(selected&&rxbyte<sizeof replies/sizeof replies[0]);
        received=(received<<1)|((pins&4)?1u:0u);
        if(replies[rxbyte]&(128u>>bits))pins|=2;else pins&=~2u;
        if(++bits==8){
            if(transaction==1)assert((received&255)==0xB9);
            else if(byte==0)assert((received&255)==3);
            else assert((received&255)==0);
            bits=0;++byte;++rxbyte;
        }
    }
}
int main(void)
{
    uint8_t id[5];const FPGA_Bus *bus;
    SN32_SPI_Init(12000000);assert(spi0_hw_ready&&spi0_backend==1);
    assert((mode&263)==261&&(mode&2)==0);assert(ctrl==((1u<<18)|(7u<<8)));
    bus=SN32_SPI_Bus();bus->select(0,1);bus->transfer(0,0xB9);bus->select(0,0);
    assert(FPGA_Read(bus,0,id,5)==FPGA_OK);
    assert(id[0]==0xAC&&id[1]==0x52&&id[2]==0x54&&id[3]==7&&id[4]==5);
    assert(!selected&&rxbyte==10&&spi0_transferred_bytes==10&&spi0_transactions==2);
    puts("PASS uploaded GPIO backend P1 pins, software SPI selection, B9 frame, SPI dummy/alignment and new ID");
}
