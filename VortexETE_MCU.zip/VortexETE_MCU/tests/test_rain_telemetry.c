#include "rain.h"
#include "telemetry.h"
#include "app_config.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void)
{
    RainSnapshot r;TelemetrySample s={0};char json[640];unsigned i;
    Rain_Reset();
    for(i=0;i<5;i++){
        Rain_OnFallingEdgeISR(i*1000u);Rain_Process(i*1000u);
    }
    Rain_GetSnapshot(5000,&r);assert(r.hour_pulses==5&&r.day_pulses==5);
    s.rain_pulses=Rain_Pulses();s.rain_hour_pulses=r.hour_pulses;s.rain_day_pulses=r.day_pulses;
    s.rain_hour_valid=r.hour_valid;s.rain_day_valid=r.day_valid;
    s.rain_hour_elapsed_s=r.hour_elapsed_ms/1000;s.rain_day_elapsed_s=r.day_elapsed_ms/1000;
    assert(Telemetry_Build(json,sizeof json,&s));
    assert(strstr(json,"\"hourly_rainfall\":1.000")&&strstr(json,"\"daily_rainfall\":1.000"));puts(json);
    Rain_GetSnapshot(3600000,&r);assert(r.hour_pulses==0&&r.day_pulses==5);
    Rain_GetSnapshot(86400000,&r);assert(r.hour_pulses==0&&r.day_pulses==0);
    assert(Rain_TotalUm()==1000u);
    puts("PASS real rain IRQ handler core -> snapshot -> actual telemetry JSON: 5 tips=1mm, hour/day expiry, since-boot retained");
}
