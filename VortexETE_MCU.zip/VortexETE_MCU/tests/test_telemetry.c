#include "telemetry.h"
#include "app_config.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
int main(void)
{
    char json[768],small[8];
    TelemetrySample s={1000,2,1234,25,2,RS485_OK,RS485_OK,RS485_OK,265,630,1,0,0,0,0,0,0,0,0,0,0,0};
    assert(Telemetry_Build(json,sizeof json,&s));
#if WATER_MILLI_MM_PER_RAW == 0u
    assert(strstr(json,"\"water_level\":null"));
    assert(strstr(json,"\"wind_speed\":null"));
#else
    assert(strstr(json,"\"water_level\":1234.000"));
    assert(strstr(json,"\"wind_speed\":2.500"));
    assert(strstr(json,"\"wind_direction\":90.000"));
#endif
    assert(strstr(json,"\"temperature\":26.500"));
    assert(strstr(json,"\"humidity\":63.000"));
    assert(strstr(json,"\"dht_status\":0"));
    assert(strstr(json,"\"hourly_rainfall\":null"));
    assert(strstr(json,"\"daily_rainfall\":null"));
    assert(strstr(json,"\"raw\":{\"water\":1234,\"wind\":25,\"direction\":2}"));
    assert(strstr(json,"\"voltage\":null")&&strstr(json,"\"wave_level\":null"));
    s.sim_voltage_mv=3749;s.sim_voltage_valid=1;s.sim_signal_percent=58;s.sim_signal_valid=1;
    assert(Telemetry_Build(json,sizeof json,&s));
    assert(strstr(json,"\"voltage\":3.749")&&strstr(json,"\"wave_level\":58.000"));
    puts(json);
    s.sim_signal_percent=101;
    assert(Telemetry_Build(json,sizeof json,&s)&&strstr(json,"\"wave_level\":null"));
    s.sim_signal_percent=0;
    assert(Telemetry_Build(json,sizeof json,&s)&&strstr(json,"\"wave_level\":0.000"));
    s.sim_voltage_valid=s.sim_signal_valid=0;
    s.rain_pulses=10;s.rain_hour_pulses=5;s.rain_day_pulses=10;s.rain_hour_valid=s.rain_day_valid=1;
    s.rain_hour_elapsed_s=100;s.rain_day_elapsed_s=3700;
    assert(Telemetry_Build(json,sizeof json,&s));
#if RAIN_UM_PER_TIP == 200u
    assert(strstr(json,"\"hourly_rainfall\":1.000"));
    assert(strstr(json,"\"daily_rainfall\":2.000"));
    assert(strstr(json,"\"rain_total_since_boot_mm\":2.000"));
#endif
    assert(strstr(json,"\"rain_period\":\"uptime\""));
    puts(json);
    s.dht_valid=0;s.dht_status=3;
    assert(Telemetry_Build(json,sizeof json,&s));
    assert(strstr(json,"\"temperature\":null"));
    assert(strstr(json,"\"humidity\":null"));
    s.water_status=RS485_ERR_TIMEOUT;
    assert(Telemetry_Build(json,sizeof json,&s));assert(strstr(json,"\"water_level\":null"));
    assert(strstr(json,"\"device_status\":2"));
    assert(!Telemetry_Build(small,sizeof small,&s)&&small[0]==0);
    assert(!Telemetry_Build(NULL,0,&s));
    /* Worst-size sensor values must fit the actual modem telemetry slot. */
    s.uptime_ms=UINT32_MAX;s.rain_pulses=UINT32_MAX;s.water=s.wind=s.direction=UINT16_MAX;
    s.rain_hour_pulses=s.rain_day_pulses=UINT32_MAX;
    s.rain_hour_elapsed_s=3599;s.rain_day_elapsed_s=86399;
    s.sim_voltage_mv=20000;s.sim_signal_percent=100;s.sim_voltage_valid=s.sim_signal_valid=1;
    assert(Telemetry_Build(json,640,&s)&&strlen(json)<640);
    puts("PASS telemetry: calibrated units, missing sensors, errors, raw diagnostics, bounds");
}
