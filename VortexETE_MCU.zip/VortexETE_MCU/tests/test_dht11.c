#include "dht11.h"
#include "app_config.h"
#include <stdint.h>
#include <assert.h>
#include <stdio.h>
static uint32_t now_us;
static int line_high=1,low_count,release_count,end_count;
void DHT11_HWInit(void){}
void DHT11_HWBeginLow(void){++low_count;}
void DHT11_HWArmRelease(void){++release_count;}
void DHT11_HWEnd(void){++end_count;}
int DHT11_HWRead(void){return line_high;}
uint32_t DHT11_HWNowUs(void){return now_us;}
static void edge(int high,uint32_t delta){now_us+=delta;DHT11_OnEdgeISR(high,now_us);}
static void bits(const uint8_t b[5])
{
    unsigned i,bit;
    edge(1,1); /* optional rising edge when host releases the bus */
    edge(0,25);edge(1,80);edge(0,80);
    for(i=0;i<5;i++)for(bit=0;bit<8;bit++){
        edge(1,50);edge(0,(b[i]&(0x80u>>bit))?70:27);
    }
}
static void begin(uint32_t start)
{
    DHT11_Task(start);assert(DHT11_IsBusy()&&dht_status==DHT11_BUSY);
    DHT11_Task(start+19u);assert(release_count==0);
    DHT11_Task(start+20u);assert(release_count==1);
}
static void init(uint32_t now)
{
    line_high=1;now_us=100;low_count=release_count=end_count=0;DHT11_Init(now);
}
int main(void)
{
    uint8_t good[5]={63,0,26,5,94},bad[5]={63,0,26,5,95};
    uint8_t zero[5]={0,0,0,0,0},range[5]={63,11,26,0,100};
    uint16_t t=999,h=999;
    assert(DHT11_Decode(good,&t,&h)==DHT11_OK&&t==265&&h==630);
    assert(DHT11_Decode(bad,&t,&h)==DHT11_ERR_CHECKSUM&&t==265&&h==630);
    assert(DHT11_Decode(range,&t,&h)==DHT11_ERR_RANGE);
    assert(DHT11_Decode(zero,&t,&h)==DHT11_OK&&t==0&&h==0);
    init(0);DHT11_Task(1999);assert(!DHT11_IsBusy());
    begin(2000);bits(good);DHT11_Task(2026);
    assert(dht_status==DHT11_OK&&dht_valid&&dht_success_count==1);
    assert(dht_temperature_x10==265&&dht_humidity_x10==630&&dht_bit_count==40);
    assert(!DHT11_IsBusy()&&DHT11_IsFresh(2026));
    assert(!DHT11_IsFresh(2026+DHT11_STALE_MS+1));
    DHT11_Task(6999);assert(low_count==1); // interval measured from start
    DHT11_Task(7000);assert(low_count==2);DHT11_Task(7020);bits(bad);DHT11_Task(7026);
    assert(dht_status==DHT11_ERR_CHECKSUM&&!dht_valid&&dht_fail_count==1);
    assert(dht_temperature_x10==265); // failure never overwrites the last good number
    init(0);begin(2000);DHT11_Task(2030);
    assert(dht_status==DHT11_ERR_TIMEOUT&&!DHT11_IsBusy()&&dht_fail_count==1);
    init(0);DHT11_Task(2000);DHT11_Task(2031);
    assert(dht_status==DHT11_ERR_TIMING&&!DHT11_IsBusy()); // foreground delayed too long
    assert(dht_error_phase==1&&dht_error_us==31000&&dht_error_level==2&&dht_error_bits==0);
    DHT11_Task(7000); // retries must not erase the evidence of the previous fault
    assert(dht_error_phase==1&&dht_error_us==31000);
    init(0);line_high=0;DHT11_Task(2000);
    assert(dht_status==DHT11_ERR_BUS&&low_count==0&&!DHT11_IsBusy());
    init(0);begin(2000);edge(1,1);edge(0,25);edge(1,2);DHT11_Task(2021);
    assert(dht_status==DHT11_ERR_TIMING&&!dht_valid); // malformed handshake
    assert(dht_error_phase==3&&dht_error_us==2&&dht_error_level==1&&dht_error_bits==0);
    init(0);begin(2000);edge(1,1);edge(0,25);edge(1,80);edge(0,80);edge(1,50);edge(0,9);DHT11_Task(2021);
    assert(dht_status==DHT11_ERR_TIMING); // full bit period 59us is below the uploaded driver's 60us limit
    assert(dht_error_phase==6&&dht_error_us==59&&dht_error_level==0&&dht_error_bits==0);
    init(0);begin(2000);bits(good);DHT11_Task(2026);
    assert(dht_error_phase==0&&dht_success_count==1); // init clears diagnostics; valid frame unchanged
    /* Regression: host release rising edge is optional, first sensor fall is not. */
    init(0);begin(2000);
    edge(0,25);edge(1,80);edge(0,80);
    {
        unsigned i,bit;
        for(i=0;i<5;i++)for(bit=0;bit<8;bit++){
            edge(1,50);edge(0,(good[i]&(0x80u>>bit))?70:27);
        }
    }
    DHT11_Task(2026);
    assert(dht_status==DHT11_OK&&dht_bit_count==40&&dht_raw[4]==94);
    /* Missing final falling edge: keep partial bits and explicit timeout phase. */
    init(0);begin(2000);edge(0,25);edge(1,80);edge(0,80);
    {
        unsigned n;
        for(n=0;n<39;n++){
            edge(1,50);edge(0,(good[n/8]&(0x80u>>(n%8)))?70:27);
        }
    }
    edge(1,50);now_us+=10000;DHT11_Task(2030);
    assert(dht_status==DHT11_ERR_TIMEOUT&&dht_bit_count==39);
    assert(dht_error_phase==6&&dht_error_bits==39&&dht_error_level==1&&dht_error_us==10000);
    /* Real pin polarity catches a lost falling edge instead of inventing one. */
    init(0);begin(2000);edge(0,25);edge(1,80);edge(0,80);edge(1,50);edge(1,120);
    DHT11_Task(2021);assert(dht_status==DHT11_ERR_TIMING&&dht_error_phase==6);
    init(UINT32_MAX-1000u);DHT11_Task(998);assert(!DHT11_IsBusy());
    now_us=UINT32_MAX-100u;begin(999);bits(good);DHT11_Task(1025);
    assert(dht_status==DHT11_OK&&dht_valid); // ms and us wraparound
    puts("PASS DHT11: physical edges, missing release edge regression, partial-frame timeout diagnostics, lost data edge rejection, checksum, timing, retry, wrap");
}
