#include "sim_a7680c.h"
#include "sim_uart.h"
#include "app_config.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
static char rx[2048],last_tx[1024];
static unsigned pos,tx_count;
static uint32_t now;
static int send_ok=1,read_error;
static void response(const char *text){strcpy(rx,text);pos=0;}
int SIM_UART_Read(uint8_t *b){if(read_error){read_error=0;return -1;}if(!rx[pos])return 0;*b=(uint8_t)rx[pos++];return 1;}
int SIM_UART_Send(const char *s){assert(strlen(s)<sizeof last_tx);strcpy(last_tx,s);++tx_count;return send_ok;}
static void feed(const char *s){response(s);SIM_Task(++now);}
static void expect(const char *s){if(strcmp(last_tx,s))fprintf(stderr,"TX expected %s got %s\n",s,last_tx);assert(!strcmp(last_tx,s));}
static void boot(void)
{
    now=0;send_ok=1;read_error=0;tx_count=0;response("");SIM_Init();SIM_Task(now);expect("AT\r\n");
    feed("AT\r\nOK\r\n");assert(sim_at_ok==1);expect("ATE0\r\n");
    feed("OK\r\n");expect("AT+CPIN?\r\n");
    feed("+CPIN: READY\r\nOK\r\n");expect("AT+CSQ\r\n");
    feed("+CSQ: 18,99\r\nOK\r\n");assert(sim_rssi==18);expect("AT+CBC\r\n");
    feed("+CBC: 3.749V\r\nOK\r\n");assert(sim_voltage_mv==3749);expect("AT+CEREG?\r\n");
    feed("+CEREG: 0,5\r\nOK\r\n");assert(sim_registration==5);expect("AT+CGATT?\r\n");
    feed("+CGATT: 1\r\nOK\r\n");assert(sim_attached==1);
    /* Empty APN preserves modem profile. */
    feed("");expect("AT+CMQTTDISC=0,60\r\n");
    feed("ERROR\r\n");expect("AT+CMQTTREL=0\r\n");
    feed("ERROR\r\n");expect("AT+CMQTTSTOP\r\n");
    feed("ERROR\r\n");expect("AT+CMQTTSTART\r\n");
    {unsigned before=tx_count;feed("+CMQTTSTART: 0\r\n");assert(tx_count==before);}
    feed("OK\r\n");assert(strstr(last_tx,"AT+CMQTTACCQ=0,")==last_tx);
    feed("OK\r\n");expect("AT+CMQTTCONNECT=0,\"tcp://broker.emqx.io:1883\",60,1\r\n");
    feed("OK\r\n");assert(!sim_mqtt_connected);
    feed("+CMQTTCONNECT: 0,0\r\n");assert(sim_mqtt_connected==1);
}
int main(void)
{
    unsigned before;char huge[SIM_PAYLOAD_CAPACITY+1];
    boot();assert(!strcmp(sim_mqtt_topic,"vortexete/station/1/telemetry"));
    assert(SIM_SetTelemetry("{\"water_level\":12.5}"));feed("");
    assert(strstr(last_tx,"AT+CMQTTTOPIC=0,")==last_tx);
    feed("\r\n> ");expect("vortexete/station/1/telemetry");
    feed("\r\nOK\r\n");expect("AT+CMQTTPAYLOAD=0,20\r\n");
    assert(SIM_SetTelemetry("{\"water_level\":99}")); /* must not replace in-flight bytes */
    feed(">");expect("{\"water_level\":12.5}");
    feed("OK\r\n");expect("AT+CMQTTPUB=0,1,60\r\n");
    feed("OK\r\n");assert(sim_publish_count==0);
    feed("+CMQTTPUB: 1,0\r\n");assert(sim_publish_count==0);
    feed("+CMQTTPUB: 0,0\r\n");assert(sim_publish_count==1);
    assert(strstr(last_tx,"AT+CMQTTTOPIC=")==last_tx); /* pending latest starts next */
    now+=SIM_COMMAND_TIMEOUT_MS;SIM_Task(now);assert(sim_requires_reset==1);
    before=tx_count;now+=SIM_POLL_MS;SIM_Task(now);assert(tx_count==before);
    feed("RDY\r\n");assert(!sim_requires_reset&&!sim_mqtt_connected);
    now+=SIM_POLL_MS;SIM_Task(now);expect("AT\r\n");
    boot();feed("+CEREG: 1,\"0001\",\"ABCD\",7\r\n");assert(sim_registration==1);
    feed("+CMQTTCONNLOST: 0,1\r\n");assert(!sim_mqtt_connected);
    now+=SIM_POLL_MS;SIM_Task(now);assert(sim_reconnects==1);expect("AT\r\n");
    boot();assert(SIM_SetTelemetry("{}"));feed("");send_ok=0;feed(">");assert(sim_requires_reset==1);
    boot();read_error=1;feed("");assert(sim_requires_reset==1&&sim_parse_errors==1);
    SIM_Init();response("");now=0xfffffff0u;SIM_Task(now);now=3000;SIM_Task(now);assert(sim_timeouts==1);
    SIM_Init();response("");now=0;SIM_Task(now);feed("ERROR\r\n");assert(sim_command_errors==1);
    SIM_Init();response("");SIM_Task(0);feed("OK\r\n");feed("OK\r\n");
    before=tx_count;feed("+CPIN: SIM PIN\r\nOK\r\n");assert(tx_count==before&&sim_pin_ready==0);
    boot();assert(SIM_SetTelemetry("{}"));feed("");feed(">");feed("OK\r\n");feed(">");feed("OK\r\n");
    feed("OK\r\n+CMQTTPUB: 0,3\r\n");assert(!sim_mqtt_connected&&sim_publish_count==0&&sim_last_mqtt_error==3);
    memset(huge,'x',sizeof huge-1);huge[sizeof huge-1]=0;
    assert(!SIM_SetTelemetry(huge)&&!SIM_SetTelemetry(NULL));
    puts("PASS SIM MQTT: connect, async results, prompts, exact payload, snapshot, URCs, errors, recovery, PIN, wrap");
}
