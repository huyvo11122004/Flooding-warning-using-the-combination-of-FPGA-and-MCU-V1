#include "rs485.h"
#include "app_config.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

static uint64_t clock_us;
static uint64_t next_byte;
static uint8_t frame[256];
static size_t frame_length, frame_index;
static uint8_t sent[8];
static unsigned tx_calls;
static int port_ready = 1, busy_noise, rx_error;
static RS485_Status tx_status;
static uint32_t byte_spacing = 1100u, extra_gap, first_delay = 3000u;
static size_t gap_index;
static unsigned tests;

uint32_t RS485_PortNowUs(void) { clock_us += 25u; return (uint32_t)clock_us; }
int RS485_PortIsReady(void) { return port_ready; }
int RS485_PortReceiveByte(uint8_t *byte)
{
    if (busy_noise && tx_calls == 0u) { *byte = 0x55; return 1; }
    if (tx_calls == 0u || clock_us < next_byte) return 0;
    if (rx_error) { rx_error = 0; return -1; }
    if (frame_index >= frame_length) return 0;
    *byte = frame[frame_index++];
    next_byte += byte_spacing;
    if (frame_index == gap_index) next_byte += extra_gap;
    return 1;
}
RS485_Status RS485_PortTransmit(const uint8_t *data, size_t length, uint32_t budget)
{
    assert(length == 8u && budget > 0u);
    memcpy(sent, data, length);
    ++tx_calls;
    clock_us += 8500u;
    next_byte = clock_us + first_delay;
    return tx_status;
}
static void reset_mock(void)
{
    clock_us = 0;
    next_byte = 0;
    frame_length = frame_index = 0;
    tx_calls = 0;
    port_ready = 1;
    busy_noise = rx_error = 0;
    byte_spacing = 1100u;
    extra_gap = 0;
    gap_index = 0;
    first_delay = 3000u;
    tx_status = RS485_OK;
    assert(RS485_ConfigureTiming(9600u, 10u) == RS485_OK);
}
/* Independent bit-at-a-time check with explicit branch. */
static uint16_t reference_crc(const uint8_t *bytes, size_t length)
{
    uint16_t result = 0xFFFFu;
    size_t i;
    unsigned j;
    for (i = 0; i < length; ++i) {
        result = (uint16_t)(result ^ bytes[i]);
        for (j = 0; j < 8u; ++j) {
            unsigned carry = result & 1u;
            result >>= 1;
            if (carry) result ^= 0xA001u;
        }
    }
    return result;
}
static void finish_frame(size_t payload)
{
    uint16_t crc = reference_crc(frame, payload);
    frame[payload] = (uint8_t)crc;
    frame[payload + 1u] = (uint8_t)(crc >> 8);
    frame_length = payload + 2u;
}
static void normal_frame(uint8_t address, uint8_t function, uint16_t count)
{
    uint16_t i;
    frame[0] = address;
    frame[1] = function;
    frame[2] = (uint8_t)(2u * count);
    for (i = 0; i < count; ++i) {
        frame[3u + i * 2u] = (uint8_t)(0x12u + i);
        frame[4u + i * 2u] = (uint8_t)(0x34u + i);
    }
    finish_frame(3u + 2u * count);
}
static void expect_error(RS485_Status expected)
{
    uint16_t output[2] = {0xA55Au, 0x5AA5u};
    uint8_t exception = 0xFF;
    RS485_Status result = RS485_ReadRegisters(1u, 3u, 4u, 2u,
        output, &exception, 500u);
    if (result != expected) {
        fprintf(stderr, "Expected %s, got %s\n", RS485_StatusText(expected),
            RS485_StatusText(result));
    }
    assert(result == expected);
    assert(output[0] == 0xA55Au && output[1] == 0x5AA5u);
    ++tests;
}
int main(void)
{
    uint16_t output[RS485_MAX_REGISTERS], value;
    uint8_t exception;
    static const uint8_t original1[] = {1,3,0,4,0,2,0x85,0xCA};
    static const uint8_t original5[] = {5,3,0,0,0,1,0x85,0x8E};

    assert(RS485_CRC16((const uint8_t *)"123456789", 9u) == 0x4B37u);
    ++tests;
    reset_mock(); normal_frame(1,3,2);
    assert(getRS485(output) == RS485_OK);
    assert(output[0] == 0x1234 && output[1] == 0x1335);
    assert(memcmp(sent, original1, 8) == 0); ++tests;
    reset_mock(); normal_frame(WIND_MODBUS_ID,3,1);
    assert(getWind(&value) == RS485_OK && value == 0x1234);
    assert(memcmp(sent, original5, 8) == 0); ++tests;
    reset_mock(); normal_frame(DIRECTION_MODBUS_ID,3,1);
    assert(getWind_huong(&value) == RS485_OK && value == 0x1234);
    assert(sent[0]==DIRECTION_MODBUS_ID && sent[1]==3 && sent[5]==1);
    assert(RS485_CRC16(sent,8)==0); ++tests;
    reset_mock(); normal_frame(WATER_MODBUS_ID,3,1);
    assert(getWater_level(&value)==RS485_OK && value==0x1234);
    assert(sent[0]==WATER_MODBUS_ID && sent[2]==0 && sent[3]==0); ++tests;

    reset_mock(); normal_frame(1,3,2); frame[frame_length-1] ^= 1;
    expect_error(RS485_ERR_CRC);
    reset_mock(); expect_error(RS485_ERR_TIMEOUT);
    reset_mock(); normal_frame(1,3,2); frame_length = 4;
    expect_error(RS485_ERR_GAP);
    reset_mock(); normal_frame(1,3,2); extra_gap = 4000; gap_index = 4;
    expect_error(RS485_ERR_GAP);
    reset_mock(); normal_frame(1,3,2); frame[2] = 3; finish_frame(7);
    expect_error(RS485_ERR_LENGTH);
    reset_mock(); normal_frame(2,3,2); expect_error(RS485_ERR_ADDRESS);
    reset_mock(); normal_frame(1,4,2); expect_error(RS485_ERR_FUNCTION);
    reset_mock(); normal_frame(1,3,2); frame[frame_length++] = 0xAA;
    expect_error(RS485_ERR_CRC);
    reset_mock(); normal_frame(1,3,2); rx_error = 1;
    expect_error(RS485_ERR_UART);
    reset_mock(); tx_status = RS485_ERR_TIMEOUT; expect_error(RS485_ERR_TIMEOUT);
    reset_mock(); busy_noise = 1; expect_error(RS485_ERR_BUS_BUSY);
    reset_mock(); port_ready = 0; expect_error(RS485_ERR_NOT_READY);

    reset_mock(); frame[0]=1; frame[1]=0x83; frame[2]=2; finish_frame(3);
    output[0] = 0xCAFE;
    assert(RS485_ReadRegisters(1,3,4,2,output,&exception,500)==RS485_ERR_EXCEPTION);
    assert(exception == 2 && output[0] == 0xCAFE); ++tests;

    reset_mock(); normal_frame(1,4,16);
    assert(RS485_ReadRegisters(1,4,0,16,output,0,500) == RS485_OK);
    assert(output[15] == 0x2143); ++tests;
    reset_mock(); memset(frame,0x55,sizeof(frame)); frame_length = sizeof(frame);
    expect_error(RS485_ERR_LENGTH);
    reset_mock(); normal_frame(1,3,2); clock_us = UINT32_MAX - 10000u;
    assert(getRS485(output) == RS485_OK); ++tests;
    reset_mock(); normal_frame(1,3,2); first_delay = 600000u;
    expect_error(RS485_ERR_TIMEOUT);
    reset_mock(); normal_frame(1,3,2); frame[3]=frame[4]=frame[5]=frame[6]=0;
    finish_frame(7);
    assert(getRS485(output)==RS485_OK && output[0]==0 && output[1]==0); ++tests;

    reset_mock();
    assert(RS485_ReadRegisters(0,3,0,1,output,0,500)==RS485_ERR_ARGUMENT);
    assert(RS485_ReadRegisters(248,3,0,1,output,0,500)==RS485_ERR_ARGUMENT);
    assert(RS485_ReadRegisters(1,3,0,0,output,0,500)==RS485_ERR_ARGUMENT);
    assert(RS485_ReadRegisters(1,3,0,17,output,0,500)==RS485_ERR_ARGUMENT);
    assert(RS485_ReadRegisters(1,3,65535,2,output,0,500)==RS485_ERR_ARGUMENT);
    assert(RS485_ReadRegisters(1,3,0,1,0,0,500)==RS485_ERR_ARGUMENT);
    assert(RS485_ReadRegisters(1,3,0,1,output,0,0)==RS485_ERR_ARGUMENT);
    assert(RS485_ReadRegisters(1,3,0,1,output,0,60001)==RS485_ERR_ARGUMENT);
    assert(RS485_ReadRegisters(1,5,0,1,output,0,500)==RS485_ERR_ARGUMENT);
    assert(tx_calls==0); tests += 9u;

    reset_mock(); normal_frame(1,3,2); byte_spacing=100u;
    assert(RS485_ConfigureTiming(115200,11)==RS485_OK);
    assert(getRS485(output)==RS485_OK); ++tests;
    assert(RS485_ConfigureTiming(0,11)==RS485_ERR_ARGUMENT); ++tests;
    assert(RS485_ConfigureTiming(9600,9)==RS485_ERR_ARGUMENT); ++tests;
    /* Fault-injected diagnostics must identify the actual failing phase. */
    reset_mock(); normal_frame(WIND_MODBUS_ID,3,1);
    assert(getWind(&value)==RS485_OK);
    assert(wind_diag_ready && wind_diag_phase==WIND_DIAG_DONE && wind_diag_status==RS485_OK);
    assert(wind_diag_tx_status==RS485_OK && wind_diag_tx_len==8 && wind_diag_rx_count==7);
    {unsigned j;for(j=0;j<8;j++)assert(wind_diag_tx[j]==original5[j]);}
    assert(wind_diag_rx[0]==5 && wind_diag_rx[1]==3 && wind_diag_rx[2]==2);
    {uint32_t saved=wind_diag_attempts;
     reset_mock();normal_frame(WATER_MODBUS_ID,3,1);
     assert(getWater_level(&value)==RS485_OK && wind_diag_attempts==saved && wind_diag_rx[0]==5);}
    reset_mock();assert(getWind(&value)==RS485_ERR_TIMEOUT);
    assert(wind_diag_phase==WIND_DIAG_RX && wind_diag_tx_status==RS485_OK && wind_diag_rx_count==0);
    reset_mock();tx_status=RS485_ERR_TIMEOUT;assert(getWind(&value)==RS485_ERR_TIMEOUT);
    assert(wind_diag_phase==WIND_DIAG_TX && wind_diag_tx_status==RS485_ERR_TIMEOUT);
    reset_mock();busy_noise=1;assert(getWind(&value)==RS485_ERR_BUS_BUSY);
    assert(wind_diag_phase==WIND_DIAG_QUIET && wind_diag_tx_len==0);
    reset_mock();normal_frame(WIND_MODBUS_ID,3,1);rx_error=1;
    assert(getWind(&value)==RS485_ERR_UART && wind_diag_uart_error==1);
    reset_mock();normal_frame(WIND_MODBUS_ID,3,1);frame[frame_length-1]^=1;
    assert(getWind(&value)==RS485_ERR_CRC && wind_diag_phase==WIND_DIAG_VALIDATE && wind_diag_rx_count==7);
    reset_mock();frame[0]=WIND_MODBUS_ID;frame[1]=0x83;frame[2]=2;finish_frame(3);
    assert(getWind(&value)==RS485_ERR_EXCEPTION && wind_diag_exception==2 && wind_diag_rx_count==5);
    reset_mock();normal_frame(WIND_MODBUS_ID,3,16);
    assert(RS485_ReadRegisters(WIND_MODBUS_ID,3,0,16,output,0,500)==RS485_OK && wind_diag_rx_count==37);
    reset_mock();port_ready=0;
    assert(getWind(&value)==RS485_ERR_NOT_READY && wind_diag_phase==WIND_DIAG_CHECK && wind_diag_tx_len==0);
    /* Delayed device: prior 500ms shared deadline would fail this reply. */
    reset_mock();normal_frame(WIND_MODBUS_ID,3,1);first_delay=750000u;
    assert(getWind(&value)==RS485_OK && value==0x1234);
    /* A complete CRC-checked wind frame is accepted before subsequent traffic. */
    reset_mock();normal_frame(WIND_MODBUS_ID,3,1);frame[frame_length++]=0xAA;
    assert(getWind(&value)==RS485_OK && wind_diag_rx_count==7 && frame_index==7);
    /* Stationary cup, genuine zero measurement, is a valid success. */
    reset_mock();normal_frame(WIND_MODBUS_ID,3,1);frame[3]=frame[4]=0;finish_frame(5);
    value=0xFFFF;assert(getWind(&value)==RS485_OK && value==0 && wind_diag_rx_count==7);
    /* The longer reply window is still bounded; stale output is never replaced. */
    reset_mock();normal_frame(WIND_MODBUS_ID,3,1);first_delay=1200000u;value=0xA55A;
    assert(getWind(&value)==RS485_ERR_TIMEOUT && value==0xA55A && wind_diag_rx_count==0);
    puts("PASS wind reply changes: 750ms response accepted, complete-frame mode, zero wind OK, >1s response times out without changing output");
    puts("PASS YJ-FS ID5 diagnostics: exact TX CRC, RX prefix, no reply vs TX timeout, busy bus, UART/CRC/exception, bounded capture, preserved across other sensors");
    printf("PASS: %u protocol checks; valid frames, faults, bounds and rollover.\n", tests);
    return 0;
}
