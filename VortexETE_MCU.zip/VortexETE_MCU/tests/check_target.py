"""Compile exactly the uploaded Keil target sources, without running MMIO."""
import os
from pathlib import Path
import subprocess
import tempfile
import xml.etree.ElementTree as E
ROOT=Path(__file__).resolve().parents[1]
r=E.parse(ROOT/'VortexETE_MCU.uvprojx')
sources=[ROOT/str(x.text).replace('\\','/').removeprefix('./') for x in r.findall('.//Groups//FilePath') if str(x.text).endswith('.c')]
assert len(sources)==len(set(sources))==13
assert sum(x.name=='main.c' for x in sources)==1
assert sum(x.name=='spi_gpio_master.c' for x in sources)==1
assert all(x.name not in ('spi0_master.c','sn32_spi_gpio.c','spi_protocol.c','main_example.c') for x in sources)
assert r.findtext('.//Cads/VariousControls/Define')=='SN32_SPI_USE_GPIO=1'
assert r.findtext('.//useUlib')=='1'
with tempfile.TemporaryDirectory() as d:
    stub=Path(d)/'clock.c';stub.write_text('#include <stdint.h>\nuint32_t SystemCoreClock=12000000;void SystemCoreClockUpdate(void){}\n')
    exe=Path(d)/'target'
    subprocess.run([os.environ.get('CC','cc'),'-std=c99','-Os','-Wall','-Wextra','-Werror','-pedantic','-DSN32_SPI_USE_GPIO=1','-I',str(ROOT/'firmware'),*map(str,sources),str(stub),'-o',str(exe)],check=True)
    subprocess.run(['size',str(exe)],check=True)
print('PASS host link of 13 uploaded Keil C sources; one main, one P1 GPIO SPI backend; microlib selected')
