#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
build_dir=$(mktemp -d)
trap 'rm -rf "$build_dir"' EXIT HUP INT TERM
for suite in rs485 rain sim sim_health baud telemetry dht11; do
 case "$suite" in baud) src="";; sim|sim_health) src=firmware/sim_a7680c.c;; *) src=firmware/$suite.c;; esac
 cc -std=c99 -Wall -Wextra -Werror -pedantic -I firmware ${src:+"$src"} "tests/test_$suite.c" -o "$build_dir/$suite"
 "$build_dir/$suite"
done
cc -std=c99 -Wall -Wextra -Werror -pedantic -I firmware -DRAIN_UM_PER_TIP=0 firmware/rain.c tests/test_rain.c -o "$build_dir/rain_unconfigured"
"$build_dir/rain_unconfigured"
cc -std=c99 -Wall -Wextra -Werror -pedantic -I firmware -DRAIN_UM_PER_TIP=500 firmware/rain.c tests/test_rain.c -o "$build_dir/rain_custom"
"$build_dir/rain_custom"
cc -std=c99 -Wall -Wextra -Werror -pedantic -I firmware -fsyntax-only firmware/*.c

cc -std=c99 -Wall -Wextra -Werror -pedantic -I firmware -DWATER_MILLI_MM_PER_RAW=1000 -DWIND_MILLI_MPS_PER_RAW=100 -DDIRECTION_MILLI_DEG_PER_RAW=45000 firmware/telemetry.c tests/test_telemetry.c -o "$build_dir/scaled"
"$build_dir/scaled"

cc -std=c99 -Wall -Wextra -Werror -pedantic -I firmware tests/test_gpio2_dispatch.c -o "$build_dir/gpio2"
"$build_dir/gpio2"
