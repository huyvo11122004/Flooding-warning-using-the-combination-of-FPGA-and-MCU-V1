#include "sim_a7680c.h"
#include "app_config.h"
#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
static char rx[2048],last_tx[1024];static unsigned pos,count;
static uint32_t now;
int SIM_UART_Read(uint8_t *b){if(!rx[pos])return 0;*b=(uint8_t)rx[pos++];return 1;}
int SIM_UART_Send(const char *s){assert(strlen(s)<sizeof last_tx);strcpy(last_tx,s);++count;return 1;}
static void feed(const char *s){strcpy(rx,s);pos=0;SIM_Task(++now);}
static void expect(const char *s){if(strcmp(last_tx,s))fprintf(stderr,"expected %s got %s\n",s,last_tx);assert(!strcmp(last_tx,s));}
static void boot(const char *csq,const char *cbc,uint32_t start)
{
    now=start;count=0;rx[0]=0;pos=0;SIM_Init();SIM_Task(now);expect("AT\r\n");
    feed("OK\r\n");expect("ATE0\r\n");feed("OK\r\n");expect("AT+CPIN?\r\n");
    feed("+CPIN: READY\r\nOK\r\n");expect("AT+CSQ\r\n");feed(csq);expect("AT+CBC\r\n");
    feed(cbc);expect("AT+CEREG?\r\n");feed("+CEREG: 0,1\r\nOK\r\n");
    feed("+CGATT: 1\r\nOK\r\n");feed("");expect("AT+CMQTTDISC=0,60\r\n");
    feed("ERROR\r\n");feed("ERROR\r\n");feed("ERROR\r\n");expect("AT+CMQTTSTART\r\n");
    feed("OK\r\n+CMQTTSTART: 0\r\n");feed("OK\r\n");
    feed("OK\r\n+CMQTTCONNECT: 0,0\r\n");assert(sim_mqtt_connected);
}
int main(void)
{
    SIM_Health h;unsigned before;
    boot("+CSQ: 18,99\r\nOK\r\n","+CBC: 3.749V\r\nOK\r\n",0);
    SIM_ReadHealth(now,&h);assert(h.voltage_valid&&h.voltage_mv==3749&&h.signal_valid&&h.signal_percent==58);
    assert(sim_signal_dbm==-77&&sim_cbc_supported==1);
    now=sim_voltage_at_ms+SIM_HEALTH_POLL_MS;feed("");expect("AT+CSQ\r\n");
    feed("+CSQ: 31,0\r\nOK\r\n");expect("AT+CBC\r\n");feed("+CBC: 4.12 V\r\nOK\r\n");
    SIM_ReadHealth(now,&h);assert(h.signal_percent==100&&h.voltage_mv==4120&&sim_health_poll_count==1);
    now=sim_voltage_at_ms+SIM_HEALTH_POLL_MS;feed("");feed("+CSQ: 0,99\r\nOK\r\n");feed("+CBC: 4V\r\nOK\r\n");
    SIM_ReadHealth(now,&h);assert(h.signal_valid&&h.signal_percent==0&&h.voltage_mv==4000);
    now=sim_voltage_at_ms+SIM_HEALTH_STALE_MS;SIM_ReadHealth(now,&h);assert(!h.voltage_valid&&!h.signal_valid);
    feed("+CMQTTCONNLOST: 0,1\r\n");SIM_ReadHealth(now,&h);assert(!h.voltage_valid&&!h.signal_valid);
    /* Unsupported CBC is optional: signal still publishes, no reconnect loop. */
    boot("+CSQ: 20,99\r\nOK\r\n","ERROR\r\n",0);
    assert(sim_cbc_supported==0&&!sim_voltage_valid&&sim_signal_percent==65&&sim_command_errors==0);
    now+=SIM_HEALTH_POLL_MS;feed("");expect("AT+CSQ\r\n");before=count;
    feed("+CSQ: 10,99\r\nOK\r\n");assert(count==before&&sim_mqtt_connected); /* no periodic CBC */
    boot("+CSQ: 99,99\r\nOK\r\n","+CBC: 3.8\r\nOK\r\n",0);
    SIM_ReadHealth(now,&h);assert(!h.signal_valid&&h.voltage_valid&&h.voltage_mv==3800&&sim_rssi==99);
    boot("+CSQ: 32,0\r\nOK\r\n","+CBC: 3749\r\nOK\r\n",0);
    SIM_ReadHealth(now,&h);assert(!h.signal_valid&&!h.voltage_valid&&sim_parse_errors==2);
    boot("+CSQ: garbage\r\nOK\r\n","+CBC: 0,90,3749\r\nOK\r\n",0);
    SIM_ReadHealth(now,&h);assert(!h.signal_valid&&!h.voltage_valid);
    boot("+CSQ: 18,99 trailing\r\nOK\r\n","+CBC: 3.7xyz\r\nOK\r\n",0);
    SIM_ReadHealth(now,&h);assert(!h.signal_valid&&!h.voltage_valid);
    boot("ERROR\r\n","+CME ERROR: 4\r\n",0);assert(sim_mqtt_connected&&!sim_voltage_valid&&!sim_signal_valid);
    /* Periodic metrics must not interrupt length-prefixed MQTT topic/payload. */
    boot("+CSQ: 18,99\r\nOK\r\n","+CBC: 3.749V\r\nOK\r\n",0);
    assert(SIM_SetTelemetry("{}"));feed("");assert(strstr(last_tx,"AT+CMQTTTOPIC=")==last_tx);
    now+=SIM_HEALTH_POLL_MS;feed(">");expect("vortexete/station/1/telemetry");
    feed("OK\r\n");expect("AT+CMQTTPAYLOAD=0,2\r\n");feed(">");expect("{}");
    feed("OK\r\n");expect("AT+CMQTTPUB=0,1,60\r\n");feed("OK\r\n+CMQTTPUB: 0,0\r\n");expect("AT+CSQ\r\n");
    /* Query timeout invalidates measurements and safely reconnects the AT owner. */
    now+=SIM_HEALTH_TIMEOUT_MS;feed("");assert(!sim_mqtt_connected&&sim_timeouts==1&&!sim_signal_valid&&!sim_voltage_valid);
    boot("+CSQ: 18,99\r\nOK\r\n","+CBC: 3.749V\r\nOK\r\n",UINT32_MAX-500u);
    SIM_ReadHealth(1000,&h);assert(h.voltage_valid&&h.signal_valid);
    feed("RDY\r\n");assert(!sim_voltage_valid&&!sim_signal_valid&&sim_cbc_supported==-1);
    puts("PASS SIM health: CBC decimal volts, CSQ 0/31/99, unsupported/malformed responses, periodic refresh, payload exclusion, timeout/reset/staleness/wrap");
}
