/* Real MCU SPI + decision scheduler + real SIM parser against independent models. */
#include "fpga_decision.h"
#include "sim_a7680c.h"
#include "app_config.h"
#include "rain.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static uint8_t regs[60];
static unsigned phase,opcode,selected,asleep,ready,scratch,command_status;
static unsigned delayed,busy,model_error,header_reads,full_reads;
static unsigned output_width=256;
static unsigned old_schema;
static uint32_t whole=20000;
static unsigned force_water_fault;
static unsigned ignore_scratch,corrupt_crc,wrong_decision,freeze_frame,old_rom,wrong_coverage,zero_id;
static uint16_t address;static uint32_t frame_id,water=16879,roi=19415;
static FILE *messages;
static unsigned level(uint32_t w,uint32_t r){return !r?0:w*100>=r*25?2:w*100>=r*5?1:0;}
static void put16(unsigned at,uint16_t v){regs[at]=(uint8_t)v;regs[at+1]=(uint8_t)(v>>8);}
static void put32(unsigned at,uint32_t v){unsigned i;for(i=0;i<4;i++)regs[at+i]=(uint8_t)(v>>(8*i));}
static void snapshot(void)
{
    memset(regs,0,sizeof regs);regs[0]=0xAC;regs[1]=0x52;regs[2]=0x54;regs[3]=7;regs[4]=(uint8_t)(old_rom?2:5);
    if(zero_id)memset(regs,0,5);
    regs[5]=0x7A;regs[6]=(uint8_t)(8|ready|(busy?2u:0u)|(model_error?4u:0u));regs[7]=(uint8_t)command_status;regs[16]=(uint8_t)scratch;
    put32(32,frame_id);put32(36,water);put32(40,roi);put32(44,whole<water?water:whole);
    put16(48,(uint16_t)output_width);put16(50,256);regs[52]=5;regs[53]=25;
    regs[54]=(uint8_t)(wrong_decision?0:level(water,roi));regs[55]=(uint8_t)(old_schema?0x33:0x43);
    put16(56,(uint16_t)((roi?water*10000u/roi:0)+(wrong_coverage?1u:0u)));
    put16(58,FPGA_Crc16(0xFFFFu,regs+32,26));if(corrupt_crc)regs[36]^=1;
}
static void select_bus(void *c,int on)
{
    (void)c;
    if(on){assert(!selected);selected=1;phase=0;address=0;snapshot();}
    else{assert(selected);
        if(opcode==3&&phase==12)++header_reads;
        if(opcode==3&&phase==64)++full_reads;
        if(opcode==0xB9){assert(phase==1);asleep=1;}selected=0;}
}
static uint8_t transfer(void *c,uint8_t value)
{
    unsigned at=phase++;(void)c;assert(selected);
    if(!at){opcode=value;assert(value==2||value==3||value==0xB9);return 0;}
    assert(asleep);
    if(at==1){address=(uint16_t)((uint16_t)value<<8);return 0;}
    if(at==2){address|=value;return 0;}
    if(opcode==2&&at==3){
        if(address==16&&!ignore_scratch)scratch=value;
        if(address==8){
            command_status=0;
            if(value==1){if(ready||busy)command_status=1;else{
                if(!freeze_frame)++frame_id;
                if(delayed)busy=1;else ready=1;
            }}
            else if(value==2){if(busy)command_status=1;else ready=0;}
        }return 0;
    }
    if(at==3)return 0;
    assert(opcode==3&&address<sizeof regs);return regs[address++];
}
static int error(void *c){(void)c;return 0;}
static const FPGA_Bus bus={0,select_bus,transfer,error};
void SN32_SPI_Pause(void){}
static char rx[4096],topic[96],payload[SIM_PAYLOAD_CAPACITY];
static size_t rxhead,rxtail;static unsigned prompt_kind,drop_once,dropped;
static unsigned fpga_published,telemetry_published;
static void feed(const char *s)
{
    size_t n=strlen(s);assert(rxhead+n<sizeof rx);memcpy(rx+rxhead,s,n);rxhead+=n;
}
int SIM_UART_Read(uint8_t *byte)
{
    if(rxtail==rxhead){rxtail=rxhead=0;return 0;}
    *byte=(uint8_t)rx[rxtail++];return 1;
}
int SIM_UART_Send(const char *text)
{
    if(prompt_kind){
        if(prompt_kind==1){assert(strlen(text)<sizeof topic);strcpy(topic,text);}
        else{assert(strlen(text)<sizeof payload);strcpy(payload,text);}
        prompt_kind=0;feed("OK\r\n");return 1;
    }
    if(strstr(text,"AT+CMQTTTOPIC=")==text){prompt_kind=1;feed("> ");}
    else if(strstr(text,"AT+CMQTTPAYLOAD=")==text){prompt_kind=2;feed("> ");}
    else if(strstr(text,"AT+CMQTTPUB=")==text){
        if(drop_once&&!dropped&&strstr(topic,"/fpga")){dropped=1;feed("OK\r\n+CMQTTPUB: 0,3\r\n");return 1;}
        if(strstr(topic,"/fpga")){
            ++fpga_published;fprintf(messages,"{\"topic\":\"%s\",\"payload\":%s}\n",topic,payload);
        }else ++telemetry_published;
        feed("+CMQTTPUB: 0,0\r\nOK\r\n");
    }else if(strstr(text,"AT+CPIN?")==text)feed("+CPIN: READY\r\nOK\r\n");
    else if(strstr(text,"AT+CSQ")==text)feed("+CSQ: 20,99\r\nOK\r\n");
    else if(strstr(text,"AT+CEREG?")==text)feed("+CEREG: 0,1\r\nOK\r\n");
    else if(strstr(text,"AT+CGATT?")==text)feed("+CGATT: 1\r\nOK\r\n");
    else if(strstr(text,"AT+CMQTTDISC=")==text)feed("OK\r\n+CMQTTDISC: 0,0\r\n");
    else if(strstr(text,"AT+CMQTTSTOP")==text)feed("+CMQTTSTOP: 0\r\nOK\r\n");
    else if(strstr(text,"AT+CMQTTSTART")==text)feed("OK\r\n+CMQTTSTART: 0\r\n");
    else if(strstr(text,"AT+CMQTTCONNECT=")==text)feed("+CMQTTCONNECT: 0,0\r\nOK\r\n");
    else feed("OK\r\n");
    return 1;
}
/* Exercise the actual scheduler and SPI model with sensor permission changes. */
#if !CAMERA_TEST_WITHOUT_SENSORS && !CAMERA_WATER_FAILOVER_ENABLE
static void sensor_task(uint32_t now,uint16_t raw,int water_valid,int rain_valid)
{
    FPGA_UpdateSensorInputs(now,raw,water_valid,Rain_QuietMs(now),rain_valid);
    FPGA_DecisionTask(now);
}
static void test_sensor_gate(void)
{
    uint32_t before,t=CAMERA_RAIN_QUIET_MS;
    Rain_ResetAt(0);FPGA_DecisionInit(&bus,0);
    FPGA_DecisionTask(0); /* link check allowed, START still gated */
    FPGA_RequestScan();sensor_task(1,101,1,1);
    assert(!camera_enabled && frame_id==0 && fpga_stage==1);
    assert(camera_gate_reason==CAMERA_GATE_RAIN_RECENT);
    sensor_task(t-1,101,1,1);assert(!camera_enabled && frame_id==0);
    sensor_task(t,101,1,1);
    assert(camera_enabled && frame_id==1 && fpga_stage==2);
    /* New real rain IRQ disables new START; finish/ACK in-flight frame. */
    Rain_OnFallingEdgeISR(t+1);
    sensor_task(t+100,101,1,1);
    assert(!camera_enabled && fpga_results_received==1 && !ready);
    before=frame_id;
    FPGA_RequestScan();sensor_task(t+2000,101,1,1);
    assert(frame_id==before && camera_gate_reason==CAMERA_GATE_RAIN_RECENT);
    sensor_task(2*t,101,1,1);assert(!camera_enabled && frame_id==before);
    sensor_task(2*t+1,100,1,1);
    assert(!camera_enabled && camera_gate_reason==CAMERA_GATE_WATER_LOW);
    sensor_task(2*t+2,101,1,0);
    assert(!camera_enabled && camera_gate_reason==CAMERA_GATE_RAIN_INVALID);
    sensor_task(2*t+3,101,0,1);
    assert(!camera_enabled && camera_gate_reason==CAMERA_GATE_WATER_INVALID);
    sensor_task(2*t+4,101,1,1);
    assert(camera_enabled && camera_water_milli_mm==101000);
    assert(frame_id==before+1 && fpga_stage==2);
    sensor_task(2*t+104,101,1,1);assert(fpga_results_received==2 && !ready);
    FPGA_UpdateSensorInputs(2*t+104,101,1,Rain_QuietMs(2*t+104),1);
    FPGA_DecisionTask(2*t+104+CAMERA_SENSOR_STALE_MS);
    assert(!camera_enabled && camera_gate_reason==CAMERA_GATE_WATER_STALE);
    before=frame_id;
    FPGA_RequestScan();FPGA_DecisionTask(2*t+105+CAMERA_SENSOR_STALE_MS);
    assert(frame_id==before);
    /* No hourly-total test: 30 tips = 6mm, but quiet time should unlock after rain stops. */
    Rain_ResetAt(3*t);
    {
        unsigned i;RainSnapshot snap;
        for(i=0;i<30;i++){
            Rain_OnFallingEdgeISR(3*t+i*1000u);Rain_GetSnapshot(3*t+i*1000u,&snap);
        }
        Rain_GetSnapshot(29000+4*t,&snap);assert(snap.hour_pulses==30);
        sensor_task(29000+4*t,101,1,1);
        assert(camera_enabled && frame_id==before+1);
        sensor_task(29100+4*t,101,1,1);assert(!ready);
    }
    /* Fresh water timestamp and quiet timer work across ms counter wrap. */
    before=frame_id;
    sensor_task(29101+4*t,101,0,1);assert(!camera_enabled);
    Rain_ResetAt(0xfffffff0u-t);
    FPGA_UpdateSensorInputs(0xfffffff0u,101,1,Rain_QuietMs(0x20u),1);
    FPGA_DecisionTask(0x20u);
    assert(camera_enabled && frame_id==before+1);
    sensor_task(0x90u,101,1,1);assert(!ready);
    puts("PASS post-rain camera gate: boot wait, actual IRQ restart, AND, boundaries, drain/ACK, stale, manual guard, heavy past rain, wrap");
    frame_id=0;ready=0;
}
#endif
static void task_with_good_sensors(uint32_t now)
{
    FPGA_UpdateSensorInputs(now,101,!force_water_fault,force_water_fault ? 0u : CAMERA_RAIN_QUIET_MS,1);
    FPGA_DecisionTask(now);
}
#if !CAMERA_TEST_WITHOUT_SENSORS
static void test_camera_fix_wait(void)
{
    uint32_t at=0,deadline;unsigned reads;uint8_t status,command;
    FPGA_Result result;
    ready=busy=model_error=0;delayed=1;header_reads=full_reads=0;
    water=500;roi=10000;frame_id=0;
    FPGA_DecisionInit(&bus,0);
    task_with_good_sensors(0);task_with_good_sensors(10);
    assert(fpga_stage==FPGA_STAGE_WAIT_SCAN&&busy&&!ready&&fpga_scan_requests==1);
    for(at=110;at<=410;at+=100)task_with_good_sensors(at);
    assert(header_reads==4&&full_reads==0&&fpga_bytes_read==32);
    assert(fpga_status_polls==4&&fpga_status_register==10&&fpga_scan_elapsed_ms==400);
    assert(fpga_results_received==0&&fpga_scan_requests==1);
    busy=0;ready=1;task_with_good_sensors(510);
    assert(header_reads==5&&full_reads==1&&fpga_bytes_read==100);
    assert(fpga_results_received==1&&fpga_water_percent_x100==500&&fpga_level==1);
    assert(fpga_last_scan_ms==500&&!ready);
    task_with_good_sensors(511);assert(fpga_wait_remaining_ms==59999);
    task_with_good_sensors(60509);assert(fpga_wait_remaining_ms==1&&fpga_scan_requests==1);
    task_with_good_sensors(60510);assert(fpga_scan_requests==2&&busy);
    deadline=60510+FPGA_SCAN_TIMEOUT_MS;
    task_with_good_sensors(deadline);
    assert(fpga_stage==FPGA_STAGE_BACKOFF&&!fpga_result_valid&&fpga_last_error==FPGA_ERR_NOT_READY);
    assert(fpga_last_scan_ms==FPGA_SCAN_TIMEOUT_MS);
    task_with_good_sensors(deadline+1);
    assert(fpga_wait_remaining_ms==FPGA_RETRY_BACKOFF_MS-1);
    /* Late completion is ACK-cleared on recovery, then a fresh job is started. */
    busy=0;ready=1;
    task_with_good_sensors(deadline+FPGA_RETRY_BACKOFF_MS);
    task_with_good_sensors(deadline+FPGA_RETRY_BACKOFF_MS+1);assert(!ready);
    task_with_good_sensors(deadline+FPGA_RETRY_BACKOFF_MS+2);assert(busy&&fpga_scan_requests==3);
    busy=0;ready=1;model_error=1;
    task_with_good_sensors(deadline+FPGA_RETRY_BACKOFF_MS+102);
    assert(fpga_stage==FPGA_STAGE_BACKOFF&&fpga_error_status==13&&fpga_last_error==FPGA_ERR_STATE);
    model_error=0;ready=1;output_width=640;
    assert(FPGA_GetResult(&bus,&result)==FPGA_ERR_STATE);output_width=256;
    assert(FPGA_ReadStatus(0,&status,&command)==FPGA_ERR_ARGUMENT);
    assert(FPGA_ReadStatus(&bus,0,&command)==FPGA_ERR_ARGUMENT);
    reads=full_reads;zero_id=1;
    assert(FPGA_ReadStatus(&bus,&status,&command)==FPGA_ERR_ID);
    assert(full_reads==reads);zero_id=0;
    puts("PASS CAMERA FIX: BUSY uses 8-byte header only; READY CRC/60-byte payload; Warning repeats at 60s; 45s timeout, late ACK/restart, raw error diagnostics, 256x256 contract");
    ready=busy=delayed=model_error=0;frame_id=0;water=16879;roi=19415;
}
#endif
#if CAMERA_TEST_WITHOUT_SENSORS
static void test_no_sensor_mode(void)
{
    uint32_t before;
    ready=busy=model_error=0;delayed=1;frame_id=0;
    FPGA_DecisionInit(&bus,0);
    /* No sensor update call at all: both water/rain are invalid after init. */
    FPGA_DecisionTask(0);FPGA_DecisionTask(1);
    assert(camera_test_mode==1&&camera_enabled==1&&camera_gate_reason==CAMERA_GATE_TEST_MODE);
    assert(camera_water_milli_mm==0&&camera_rain_quiet_ms==0);
    assert(fpga_scan_requests==1&&fpga_stage==FPGA_STAGE_WAIT_SCAN&&busy);
    busy=0;ready=1;FPGA_DecisionTask(101);
    assert(fpga_results_received==1&&fpga_result_valid&&fpga_last_error==0);
    /* Invalid sensor samples and a rain quiet time of zero do not block test. */
    FPGA_UpdateSensorInputs(102,0,0,0,0);FPGA_DecisionTask(102);
    assert(camera_enabled&&fpga_wait_remaining_ms==CAMERA_TEST_INTERVAL_MS-1);
    before=fpga_scan_requests;
    FPGA_DecisionTask(101+CAMERA_TEST_INTERVAL_MS-1);assert(fpga_scan_requests==before);
    FPGA_DecisionTask(101+CAMERA_TEST_INTERVAL_MS);assert(fpga_scan_requests==before+1&&busy);
    water=roi=whole=0;busy=0;ready=1;
    FPGA_DecisionTask(201+CAMERA_TEST_INTERVAL_MS);
    assert(fpga_result_valid&&fpga_level==0&&fpga_roi_skipped&&fpga_whole_water_pixels==0);
    FPGA_DecisionTask(201+2*CAMERA_TEST_INTERVAL_MS);assert(busy);
    water=500;roi=10000;whole=500;busy=0;ready=1;
    FPGA_DecisionTask(301+2*CAMERA_TEST_INTERVAL_MS);assert(fpga_level==1);
    before=fpga_scan_requests;
    FPGA_DecisionTask(301+3*CAMERA_TEST_INTERVAL_MS);
    assert(fpga_scan_requests==before+1&&busy); /* no 60s Warning wait in test */
    ready=busy=0;ignore_scratch=1;FPGA_DecisionInit(&bus,0);
    FPGA_DecisionTask(0);
    assert(camera_enabled&&fpga_stage==FPGA_STAGE_BACKOFF&&fpga_scan_requests==0);
    assert(fpga_last_error==FPGA_ERR_ECHO); /* test never bypasses SPI faults */
    ignore_scratch=0;ready=busy=delayed=model_error=0;
    frame_id=0;water=16879;roi=19415;whole=20000;
    puts("PASS no-sensor mode: actual SPI START before 5min, no fake water/rain, 1s repeats at every level, dry ROI skip, invalid sensors ignored for capture only, real SPI faults still block");
}
#endif
#if !CAMERA_TEST_WITHOUT_SENSORS && CAMERA_WATER_FAILOVER_ENABLE
static void test_water_failover(void)
{
    uint32_t t,before;
    ready=busy=model_error=0;delayed=1;frame_id=0;
    water=roi=whole=0;
    FPGA_DecisionInit(&bus,0);
    FPGA_DecisionTask(0);FPGA_DecisionTask(1);
    assert(!camera_test_mode&&camera_enabled&&camera_fallback_active);
    assert(camera_gate_reason==CAMERA_GATE_WATER_FAILOVER&&busy&&fpga_scan_requests==1);
    assert(camera_water_milli_mm==0&&camera_rain_quiet_ms==0);
    busy=0;ready=1;FPGA_DecisionTask(101);
    assert(fpga_result_valid&&fpga_result_from_fallback&&fpga_roi_skipped&&fpga_level==0);
    before=fpga_scan_requests;
    FPGA_DecisionTask(100+CAMERA_FALLBACK_INTERVAL_MS);assert(fpga_scan_requests==before);
    t=101+CAMERA_FALLBACK_INTERVAL_MS;FPGA_DecisionTask(t);assert(busy&&fpga_scan_requests==before+1);
    /* Sensor recovers low while a fallback frame is in flight: complete it,
     * retain its fallback origin, and stop accepting new frames. */
    FPGA_UpdateSensorInputs(t+100,100,1,CAMERA_RAIN_QUIET_MS,1);
    busy=0;ready=1;FPGA_DecisionTask(t+100);
    assert(!camera_enabled&&!camera_fallback_active&&camera_gate_reason==CAMERA_GATE_WATER_LOW);
    assert(fpga_result_valid&&fpga_result_from_fallback&&!ready);
    FPGA_UpdateSensorInputs(t+101,101,1,0,1);FPGA_DecisionTask(t+101);
    assert(!camera_enabled&&camera_gate_reason==CAMERA_GATE_RAIN_RECENT);
    FPGA_UpdateSensorInputs(t+102,101,1,CAMERA_RAIN_QUIET_MS,1);FPGA_DecisionTask(t+102);
    assert(camera_enabled&&!camera_fallback_active&&busy);
    /* Invalid sensor during a normal scan: preserve that scan's origin, then
     * immediately request a new fallback frame even though enabled stayed 1. */
    FPGA_UpdateSensorInputs(t+202,0,0,0,0);busy=0;ready=1;FPGA_DecisionTask(t+202);
    assert(camera_fallback_active&&fpga_result_valid&&!fpga_result_from_fallback);
    before=fpga_scan_requests;FPGA_DecisionTask(t+203);
    assert(busy&&fpga_scan_requests==before+1);
    water=500;roi=10000;whole=500;busy=0;ready=1;FPGA_DecisionTask(t+303);
    assert(fpga_result_from_fallback&&fpga_level==1);
    before=fpga_scan_requests;
    FPGA_DecisionTask(t+302+CAMERA_FALLBACK_INTERVAL_MS);assert(fpga_scan_requests==before);
    FPGA_DecisionTask(t+303+CAMERA_FALLBACK_INTERVAL_MS);assert(busy&&fpga_scan_requests==before+1);
    /* A previously valid sample becomes stale: fallback must run regardless
     * of rain quiet time, without inventing a replacement depth measurement. */
    ready=busy=0;FPGA_DecisionInit(&bus,0);
    FPGA_UpdateSensorInputs(0,101,1,0,1);FPGA_DecisionTask(0);
    assert(!camera_enabled&&!camera_fallback_active);
    FPGA_DecisionTask(CAMERA_SENSOR_STALE_MS);
    assert(camera_enabled&&camera_fallback_active&&busy&&camera_gate_reason==CAMERA_GATE_STALE_FAILOVER);
    assert(camera_water_milli_mm==101000);
    ready=busy=0;ignore_scratch=1;FPGA_DecisionInit(&bus,0);FPGA_DecisionTask(0);
    assert(camera_fallback_active&&fpga_stage==FPGA_STAGE_BACKOFF&&!fpga_scan_requests);
    assert(fpga_last_error==FPGA_ERR_ECHO);
    ignore_scratch=0;ready=busy=delayed=model_error=0;
    frame_id=0;water=16879;roi=19415;whole=20000;
    puts("PASS water-sensor fallback: invalid/no sensor and stale -> camera without rain wait, 10s Normal/Warning cadence, real results only, recovery restores POST_RAIN, in-flight origin retained, SPI faults still block");
}
#endif
int main(int argc,char **argv)
{
    uint32_t now=0,before;unsigned i;FPGA_Result r;
    static const uint32_t waters[]={0,499,500,2499,2500,10000,3276,3277,16383,16384};
    static const uint32_t rois[]={10000,10000,10000,10000,10000,10000,65536,65536,65536,65536};
    static const unsigned expected[]={0,0,1,1,2,2,0,1,1,2};
    assert(argc==2);messages=fopen(argv[1],"w");assert(messages);
    assert(FPGA_Crc16(0xFFFFu,(const uint8_t *)"123456789",9)==0x29B1);
#if CAMERA_TEST_WITHOUT_SENSORS
    test_no_sensor_mode();
#else
#if CAMERA_WATER_FAILOVER_ENABLE
    test_water_failover();
#else
    test_sensor_gate();
#endif
    test_camera_fix_wait();
#endif
    SIM_Init();FPGA_DecisionInit(&bus,now);assert(asleep&&flash_sleep_request_sent);
    /* SPI and initial inference must work while the modem is never serviced. */
    for(now=0;now<1000;now+=10)task_with_good_sensors(now);
    assert(fpga_results_received==1&&fpga_level==2&&!sim_mqtt_connected);
    ignore_scratch=1;assert(FPGA_TestLink(&bus)==FPGA_ERR_ECHO);
    assert(fpga_diag_ready==1&&fpga_echo_error_mask==0x3Eu);
    ignore_scratch=0;assert(FPGA_TestLink(&bus)==FPGA_OK);
    assert(fpga_diag_id[4]==5&&fpga_echo_error_mask==0);
    for(i=0;i<sizeof waters/sizeof waters[0];i++){
        water=waters[i];roi=rois[i];ready=1;
        assert(FPGA_Level(water,roi)==expected[i]);assert(FPGA_GetResult(&bus,&r)==FPGA_OK);
        assert(r.decision==expected[i]);assert(r.coverage_basis_points==water*10000u/roi);
    }
    assert(FPGA_Level(0,0)==3&&FPGA_Level(11,10)==3);
    water=0;roi=0;whole=0;ready=1;
    assert(FPGA_GetResult(&bus,&r)==FPGA_OK&&r.roi_skipped&&r.decision==0&&r.coverage_basis_points==0);
    whole=1;assert(FPGA_GetResult(&bus,&r)==FPGA_ERR_STATE);whole=0;
    old_schema=1;assert(FPGA_GetResult(&bus,&r)==FPGA_ERR_STATE);old_schema=0;
    water=499;roi=10000;whole=20000;

    zero_id=1;assert(FPGA_TestLink(&bus)==FPGA_ERR_ID);
    assert(fpga_diag_step==1&&fpga_diag_ready==0&&fpga_echo_rx[0]==0xFFFFFFFFu);
    assert(fpga_id0==0&&fpga_id1==0&&fpga_id2==0&&fpga_id3==0&&fpga_id4==0);
    zero_id=0;assert(FPGA_TestLink(&bus)==FPGA_OK);
    assert(fpga_id0==0xAC&&fpga_id1==0x52&&fpga_id2==0x54&&fpga_id3==7&&fpga_id4==5);
    old_rom=1;assert(FPGA_TestLink(&bus)==FPGA_ERR_ID);
    assert(FPGA_GetResult(&bus,&r)==FPGA_ERR_ID);old_rom=0;
    water=16879;roi=19415;corrupt_crc=1;assert(FPGA_GetResult(&bus,&r)==FPGA_ERR_CRC);
    corrupt_crc=0;wrong_coverage=1;assert(FPGA_GetResult(&bus,&r)==FPGA_ERR_STATE);wrong_coverage=0;
    wrong_decision=1;assert(FPGA_GetResult(&bus,&r)==FPGA_ERR_STATE);wrong_decision=0;
    (void)FPGA_Command(&bus,FPGA_CMD_ACK);
    drop_once=1;
    for(;now<50000;now+=10){
        if(now==30000){water=0;roi=0;whole=0;
#if CAMERA_WATER_FAILOVER_ENABLE && !CAMERA_TEST_WITHOUT_SENSORS
            force_water_fault=1;
#endif
            FPGA_RequestScan();}
        if(now==35000){force_water_fault=0;whole=20000;water=499;roi=10000;FPGA_RequestScan();}
        if(now==40000){water=500;FPGA_RequestScan();}
        if(now==45000){water=2500;FPGA_RequestScan();}
        SIM_Task(now);task_with_good_sensors(now);
        if(now%1000==0)assert(SIM_SetTelemetry("{\"device_id\":1,\"water_level\":null}"));
    }
    assert(dropped&&fpga_published&&telemetry_published&&fpga_decisions_sent);
    water=16879;roi=19415;before=fpga_frames_failed;corrupt_crc=1;FPGA_RequestScan();
    for(;now<55000;now+=10){SIM_Task(now);task_with_good_sensors(now);}
    assert(fpga_frames_failed>before&&fpga_result_valid==0&&fpga_level==3&&fpga_last_error==FPGA_ERR_CRC);
    corrupt_crc=0;
    for(;now<90000;now+=10){SIM_Task(now);task_with_good_sensors(now);}
    assert(fpga_result_valid&&fpga_level==2&&fpga_last_error==0);
    /* Force physical network loss: invalidate the queued slot, reconnect, latest wins. */
    feed("+CMQTTCONNLOST: 0,1\r\n");
    for(;now<125000;now+=10){SIM_Task(now);task_with_good_sensors(now);}
    assert(sim_mqtt_connected&&fpga_results_received>10&&!sim_requires_reset);
    freeze_frame=1;FPGA_RequestScan();
    for(;now<129000;now+=10){SIM_Task(now);task_with_good_sensors(now);}
    assert(!fpga_result_valid&&fpga_last_error==FPGA_ERR_CHANGED);
    freeze_frame=0;
    for(;now<165000;now+=10){SIM_Task(now);task_with_good_sensors(now);}
    assert(fpga_result_valid&&fpga_last_error==0);
    fclose(messages);
    printf("PASS MCU direct FPGA percentage/level, thresholds, offline SPI, scratch diagnostics, CRC + wrong level/percentage rejection\n");
    printf("PASS real SIM parser reconnect, publish retry/latest state, telemetry; %u FPGA records\n",fpga_published);
    return 0;
}
