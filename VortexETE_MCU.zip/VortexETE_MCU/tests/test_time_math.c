#include "sn32_time_math.h"
#include <stdint.h>
#include <assert.h>
#include <stdio.h>
int main(void)
{
    uint32_t cycles,ticks,inv,before=UINT32_MAX-500u;
    for(cycles=1;cycles<=60;cycles++){
        inv=(65536u+cycles-1u)/cycles;
        for(ticks=0;ticks<cycles*1000u;ticks++){
            assert(SN32_CyclesToUs(ticks,cycles,inv)==ticks/cycles);
            assert(before+SN32_CyclesToUs(ticks,cycles,inv)==before+ticks/cycles);
        }
    }
    puts("PASS fast IRQ timestamp: exact division for every SysTick fraction at 1..60MHz, including microsecond counter wrap");
}
