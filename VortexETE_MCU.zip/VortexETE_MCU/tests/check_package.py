"""Verify packaged source integrity and IDE relative paths after cleanup."""
from pathlib import Path
import hashlib,json,xml.etree.ElementTree as E
R=Path(__file__).resolve().parents[1]
m=json.loads((R/'tests/source_manifest.json').read_text())
for rel,digest in m['copied_files_sha256'].items():
    p=R/rel
    assert p.is_file(),rel
    assert hashlib.sha256(p.read_bytes()).hexdigest()==digest, 'Source changed: '+rel
assert sorted(str(p.relative_to(R)) for p in R.rglob('*.md'))==['README.md']
assert not any(p.name in ('web_patch','reference_web_v12','legacy_spi_tests') for p in R.rglob('*'))
if m['package']=='VortexETE_MCU':
    project=E.parse(R/'VortexETE_MCU.uvprojx')
    paths=[n.text for n in project.findall('.//Groups//FilePath')]
    paths += [n.text for n in project.findall('.//RTE//instance')]
    for rel in paths:
        if rel: assert (R/rel.replace('\\','/')).is_file(),rel
else:
    project=E.parse(R/'ACG525_VORTEX_CAMERA_AI_COMPACT.gprj')
    sources=[R/n.attrib['path'] for n in project.findall('.//File')]
    assert len(sources)==22
    assert all(p.is_file() for p in sources)
    assert project.find('Device').attrib['pn']=='GW5A-LV25UG324ES'
    process=json.loads((R/'impl/ACG525_VORTEX_CAMERA_AI_COMPACT_process_config.json').read_text())
    assert process['TopModule']=='vortex_camera_ai_compact'
    for p in sources:
        if p.suffix=='.v': assert '$readmemh' not in p.read_text()
print('PASS',m['package'],': original copied source hashes, project paths, one README, no web')
