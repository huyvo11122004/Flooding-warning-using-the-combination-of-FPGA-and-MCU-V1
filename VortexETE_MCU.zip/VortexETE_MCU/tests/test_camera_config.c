/* Compile with alternate app_config values to verify units and timing. */
#include "fpga_decision.h"
#include "app_config.h"
#include <assert.h>
#include <stdio.h>
int SIM_UART_Read(uint8_t *byte){(void)byte;return 0;}
int SIM_UART_Send(const char *text){(void)text;return 1;}
void SN32_SPI_Pause(void){}
int main(void)
{
    FPGA_DecisionInit(0,0);
    FPGA_UpdateSensorInputs(0,2001,1,CAMERA_RAIN_QUIET_MS-1,1);
    FPGA_DecisionTask(0);
    assert(camera_water_milli_mm==200100u);
    assert(!camera_enabled && camera_gate_reason==CAMERA_GATE_RAIN_RECENT);
    FPGA_UpdateSensorInputs(1,2000,1,CAMERA_RAIN_QUIET_MS,1);
    FPGA_DecisionTask(1);
    assert(!camera_enabled && camera_gate_reason==CAMERA_GATE_WATER_LOW);
    FPGA_UpdateSensorInputs(2,2001,1,CAMERA_RAIN_QUIET_MS,1);
    FPGA_DecisionTask(2);assert(camera_enabled);
    FPGA_DecisionTask(2+CAMERA_SENSOR_STALE_MS);
    assert(!camera_enabled && camera_gate_reason==CAMERA_GATE_WATER_STALE);
    puts("PASS alternate quiet period 60s / water 200mm, raw scale 0.1mm, configured freshness");
    return 0;
}
