#include <stdint.h>
#include <assert.h>
#include <stdio.h>
static volatile uint32_t regs[24];
static uint32_t addresses[24];static unsigned count;
static volatile uint32_t *reg_at(uint32_t a)
{
    unsigned i;for(i=0;i<count;i++)if(addresses[i]==a)return regs+i;
    assert(count<24);addresses[count]=a;return regs+count++;
}
#define SN32_GPIO_REG(a) (*reg_at((uint32_t)(a)))
#include "../firmware/dht11_sn32f407.c"
#undef MASK
#include "../firmware/rain_sn32f407.c"
volatile uint32_t app_ms=77;
static unsigned dht_calls,rain_calls,call_order;
uint32_t RS485_PortNowUs(void){return 1234;}
void DHT11_OnEdgeISR(int high,uint32_t now)
{
    assert(now==1234);assert(call_order==0);
    assert(high==(dht_calls==0?1:0));call_order=1;++dht_calls;
}
void Rain_OnFallingEdgeISR(uint32_t now){assert(now==77);++rain_calls;}
int main(void)
{
    const uint32_t rain=1u<<8,dht=1u<<9;
    *reg_at(0x40048018u)=rain;
    *reg_at(0x40048004u)=0xFFFFFFFFu;
    DHT11_HWInit();assert(*reg_at(0x40048018u)==rain);
    assert((*reg_at(0x40048004u)&dht)==0);
    DHT11_HWBeginLow();assert(*reg_at(0x40048004u)&dht);
    DHT11_HWArmRelease();assert(*reg_at(0x40048018u)==(rain|dht));
    assert((*reg_at(0x40048004u)&dht)==0);
    *reg_at(0x40048000u)=dht;
    *reg_at(0x4004801Cu)=rain|dht;
    P2_IRQHandler();assert(dht_calls==1&&rain_calls==1);
    assert(*reg_at(0x40048020u)==rain); // final W1C write is rain's bit, no combined bank clear
    *reg_at(0x40048000u)=0;call_order=0;
    *reg_at(0x4004801Cu)=dht;
    P2_IRQHandler();assert(dht_calls==2&&rain_calls==1);
    DHT11_HWEnd();assert(*reg_at(0x40048018u)==rain);
    *reg_at(0x4004801Cu)=rain|dht;P2_IRQHandler();assert(dht_calls==2&&rain_calls==2); // disabled DHT flag ignored
    puts("PASS GPIO2: DHT setup preserves rain, both-edge setup, simultaneous IRQ dispatch, independent masking/W1C");
}
