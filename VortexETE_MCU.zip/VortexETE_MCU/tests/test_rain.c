#include "rain.h"
#include "app_config.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#define HOUR 3600000u
#define DAY 86400000u
static void get(uint32_t now,RainSnapshot *s){Rain_GetSnapshot(now,s);}
int main(void)
{
    RainSnapshot s;uint32_t i,base;
    Rain_Reset();Rain_OnFallingEdgeISR(0);assert(Rain_Pulses()==1);
    Rain_OnFallingEdgeISR(1);Rain_OnFallingEdgeISR(RAIN_DEBOUNCE_MS-1u);
    assert(Rain_Pulses()==1&&rain_rejected_edges==2);
    Rain_OnFallingEdgeISR(RAIN_DEBOUNCE_MS);assert(Rain_Pulses()==2);
    get(RAIN_DEBOUNCE_MS,&s);assert(s.hour_pulses==2&&s.day_pulses==2);
    assert(Rain_Calibrated()==(RAIN_UM_PER_TIP!=0u));
    assert(Rain_TotalUm()==2u*(uint64_t)RAIN_UM_PER_TIP);
    assert(s.hour_valid==(RAIN_UM_PER_TIP!=0u));
    /* Windows align to monitoring start; boundary tip belongs to new period. */
    Rain_ResetAt(1000);Rain_OnFallingEdgeISR(1000);Rain_OnFallingEdgeISR(2000);
    get(1000+HOUR-1,&s);assert(s.hour_pulses==2&&s.day_pulses==2);
    Rain_OnFallingEdgeISR(1000+HOUR);get(1000+HOUR,&s);
    assert(s.hour_pulses==1&&s.day_pulses==3&&s.hour_elapsed_ms==0);
    get(1000+2u*HOUR+123,&s);assert(s.hour_pulses==0&&s.day_pulses==3&&s.hour_elapsed_ms==123);
    Rain_OnFallingEdgeISR(1000+DAY);get(1000+DAY,&s);
    assert(s.hour_pulses==1&&s.day_pulses==1&&s.day_elapsed_ms==0);
    /* Caller sampled time before a newly queued IRQ; do not consume future tip. */
    Rain_Reset();Rain_OnFallingEdgeISR(1000);get(999,&s);assert(s.hour_pulses==0);
    get(1000,&s);assert(s.hour_pulses==1);
    /* Timestamp queue overrun retains since-boot count, invalidates period data. */
    Rain_Reset();for(i=0;i<20;i++)Rain_OnFallingEdgeISR(i*1000u);
    get(20000,&s);assert(Rain_Pulses()==20&&rain_queue_overflows==5&&!s.hour_valid&&!s.day_valid);
    get(HOUR,&s);assert(s.hour_pulses==0&&s.hour_valid==(RAIN_UM_PER_TIP!=0u)&&!s.day_valid);
    get(DAY,&s);assert(s.day_pulses==0&&s.day_valid==(RAIN_UM_PER_TIP!=0u));
    /* Overrun after sampled now must invalidate the correct later period too. */
    Rain_Reset();for(i=0;i<15;i++)Rain_OnFallingEdgeISR(i*1000u);
    Rain_OnFallingEdgeISR(HOUR+1);get(HOUR-1,&s);assert(!s.hour_valid);
    get(HOUR+1,&s);assert(!s.hour_valid);
    get(2u*HOUR,&s);assert(s.hour_valid==(RAIN_UM_PER_TIP!=0u));
    /* Debounce and all period accounting survive 32-bit millisecond wrap. */
    base=UINT32_MAX-2000u;Rain_ResetAt(base);Rain_OnFallingEdgeISR(base);
    Rain_OnFallingEdgeISR(base+1000u);Rain_OnFallingEdgeISR(base+3000u);
    get(base+3000u,&s);assert(s.hour_pulses==3&&s.hour_elapsed_ms==3000u);
    Rain_OnFallingEdgeISR(base+HOUR);get(base+HOUR,&s);
    assert(s.hour_pulses==1&&s.day_pulses==4);
    get(base+DAY,&s);assert(s.day_pulses==0&&s.day_elapsed_ms==0);
    /* Activity timing is independent of calibration and the hour queue. */
    Rain_ResetAt(1000);assert(Rain_QuietMs(1000)==0);
    assert(Rain_QuietMs(301000)==300000);
    Rain_OnFallingEdgeISR(301001);assert(Rain_QuietMs(301001)==0);
    Rain_OnFallingEdgeISR(301002); /* debounce rejects this, cannot restart timer */
    assert(Rain_QuietMs(302001)==1000);
    Rain_Reset();for(i=0;i<20;i++)Rain_OnFallingEdgeISR(i*1000u);
    assert(rain_queue_overflows==5 && Rain_QuietMs(19000)==0);
    assert(Rain_QuietMs(319000)==300000); /* even with lost period events */
    Rain_Reset();Rain_OnFallingEdgeISR(1000);
    assert(Rain_QuietMs(999)==0); /* caller sampled before IRQ */
    assert(Rain_QuietMs(1000)==0 && Rain_QuietMs(1500)==500);
    base=UINT32_MAX-2000u;Rain_ResetAt(base);
    assert(Rain_QuietMs(base+3000u)==3000);
    Rain_OnFallingEdgeISR(base+4000u);assert(Rain_QuietMs(base+4500u)==500);
    /* Accumulate across repeated time wraps, saturating at UINT32_MAX. */
    Rain_Reset();assert(Rain_QuietMs(0x70000000u)==0x70000000u);
    assert(Rain_QuietMs(0xe0000000u)==0xe0000000u);
    assert(Rain_QuietMs(0x50000000u)==UINT32_MAX);
    assert(Rain_QuietMs(0x60000000u)==UINT32_MAX);
    Rain_OnFallingEdgeISR(0x60000001u);assert(Rain_QuietMs(0x60000001u)==0);
    puts("PASS rain activity: boot quiet interval, accepted edge/debounce, future IRQ, queue overrun, wrap and saturation");
    puts("PASS rain: configurable tip scale, debounce, IRQ timestamp queue, exact uptime period boundaries, future events, overrun invalidation/recovery, clock wrap");
}
