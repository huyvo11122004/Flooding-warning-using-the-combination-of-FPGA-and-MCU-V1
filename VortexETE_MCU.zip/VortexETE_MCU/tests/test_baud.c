#include "sim_baud.h"
#include <assert.h>
#include <stdio.h>
int main(void)
{
    SIM_BaudConfig b;
    assert(SIM_BaudPlan(12000000,115200,&b));
    assert(b.divisor==13&&b.oversampling==8&&b.fd==0x110&&b.actual_baud==115384);
    assert(SIM_BaudPlan(24000000,115200,&b));assert(b.oversampling==16&&b.divisor==13&&b.fd==0x10);
    assert(SIM_BaudPlan(48000000,115200,&b));assert(b.oversampling==16&&b.divisor==26);
    assert(SIM_BaudPlan(12000000,9600,&b));assert(b.oversampling==16&&b.divisor==78);
    assert(SIM_BaudPlan(12000000,4800,&b));
    assert(!SIM_BaudPlan(12000000,0,&b));
    assert(!SIM_BaudPlan(12000000,1000000,&b));
    assert(!SIM_BaudPlan(0,115200,&b));
    assert(!SIM_BaudPlan(12000000,115200,0));
    puts("PASS baud: 12 MHz/115200 fallback 8x; 24/48 MHz prefer 16x; invalid inputs");
}
