#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TASK_BUILD_DIR=$(mktemp -d)
trap 'rm -rf "$TASK_BUILD_DIR"' EXIT
CC=${CC:-cc}
sh tests/run_tests.sh | tee "$TASK_BUILD_DIR/sensor_payloads.log"
python3 tests/check_target.py
"$CC" -std=c99 -O2 -Wall -Wextra -Werror -pedantic -I firmware tests/test_p21.c -o "$TASK_BUILD_DIR/p21"
"$TASK_BUILD_DIR/p21"
"$CC" -std=c99 -O2 -Wall -Wextra -Werror -pedantic -I firmware firmware/rain.c firmware/telemetry.c tests/test_rain_telemetry.c -o "$TASK_BUILD_DIR/rain_telemetry"
"$TASK_BUILD_DIR/rain_telemetry" | tee -a "$TASK_BUILD_DIR/sensor_payloads.log"
"$CC" -std=c99 -O2 -Wall -Wextra -Werror -pedantic -I firmware tests/test_time_math.c -o "$TASK_BUILD_DIR/time_math"
"$TASK_BUILD_DIR/time_math"
"$CC" -std=c99 -O2 -Wall -Wextra -Werror -pedantic -DSN32_SPI_HOST_TEST -DSN32_SPI_USE_GPIO=1 -I firmware \
 firmware/spi_gpio_master.c firmware/fpga_spi.c tests/test_spi_gpio.c -o "$TASK_BUILD_DIR/gpio"
"$TASK_BUILD_DIR/gpio"
"$CC" -std=c99 -O2 -Wall -Wextra -Werror -pedantic -I firmware \
 -DCAMERA_TEST_WITHOUT_SENSORS=0 -DCAMERA_WATER_FAILOVER_ENABLE=0 firmware/fpga_spi.c firmware/fpga_decision.c firmware/rain.c firmware/sim_a7680c.c tests/test_decision.c -o "$TASK_BUILD_DIR/decision"
"$TASK_BUILD_DIR/decision" "$TASK_BUILD_DIR/decisions.jsonl"
"$CC" -std=c99 -O2 -Wall -Wextra -Werror -pedantic -I firmware \
 -DCAMERA_TEST_WITHOUT_SENSORS=0 -DCAMERA_WATER_FAILOVER_ENABLE=0 -DCAMERA_RAIN_QUIET_MS=60000u -DCAMERA_WATER_HIGH_THRESHOLD_MILLI_MM=200000u \
 -DWATER_MILLI_MM_PER_RAW=100u -DCAMERA_SENSOR_STALE_MS=7000u \
 firmware/fpga_spi.c firmware/fpga_decision.c firmware/sim_a7680c.c tests/test_camera_config.c \
 -o "$TASK_BUILD_DIR/camera_config"
"$TASK_BUILD_DIR/camera_config"
"$CC" -std=c99 -O2 -Wall -Wextra -Werror -pedantic -I firmware \
 -DCAMERA_TEST_WITHOUT_SENSORS=1 firmware/fpga_spi.c firmware/fpga_decision.c firmware/rain.c firmware/sim_a7680c.c tests/test_decision.c \
 -o "$TASK_BUILD_DIR/decision_no_sensor"
"$TASK_BUILD_DIR/decision_no_sensor" "$TASK_BUILD_DIR/decisions_no_sensor.jsonl"
"$CC" -std=c99 -O2 -Wall -Wextra -Werror -pedantic -I firmware \
 -DCAMERA_TEST_WITHOUT_SENSORS=0 -DCAMERA_WATER_FAILOVER_ENABLE=1 \
 firmware/fpga_spi.c firmware/fpga_decision.c firmware/rain.c firmware/sim_a7680c.c tests/test_decision.c \
 -o "$TASK_BUILD_DIR/decision_failover"
"$TASK_BUILD_DIR/decision_failover" "$TASK_BUILD_DIR/decisions_failover.jsonl"
