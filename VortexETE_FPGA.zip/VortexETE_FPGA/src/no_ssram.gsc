// v2: image/mask use explicit SDPB; tiny NN state uses packed registers.
GLOBAL syn_romstyle=logic;
GLOBAL syn_srlstyle=registers;
