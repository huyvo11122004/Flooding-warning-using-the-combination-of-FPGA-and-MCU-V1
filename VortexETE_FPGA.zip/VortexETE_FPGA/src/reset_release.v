module reset_release(input clk, input async_ready, output reset_n);
    reg [1:0] sync_ff;
    always @(posedge clk or negedge async_ready)
        if (!async_ready) sync_ff <= 2'b00;
        else sync_ff <= {sync_ff[0], 1'b1};
    assign reset_n = sync_ff[1];
endmodule
