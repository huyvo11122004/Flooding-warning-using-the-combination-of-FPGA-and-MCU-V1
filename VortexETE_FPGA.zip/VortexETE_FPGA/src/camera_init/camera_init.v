/////////////////////////////////////////////////////////////////////////////////
// Company       : 武汉芯路恒科技有限公司
//                 http://xiaomeige.taobao.com
// Web           : http://www.corecourse.cn
// 
// Create Date   : 2019/05/01 00:00:00
// Module Name   : camera_init
// Description   : 摄像头初始化驱动模块,支持ov5640和ov7725
// 
// Dependencies  : 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
/////////////////////////////////////////////////////////////////////////////////

module camera_init #(
  parameter SYS_CLOCK       = 50_000_000,//系统时钟采用50MHz
  parameter SCL_CLOCK       = 400_000,   //SCL总线时钟采用400kHz
  parameter CAMERA_TYPE     = "ov5640",  //"ov5640" or "ov7725"
  parameter IMAGE_TYPE      = 0,         //0:RGB 1:JPEG
  parameter IMAGE_WIDTH     = 640,       //仅ov5640有效
  parameter IMAGE_HEIGHT    = 480,       //仅ov5640有效
  parameter IMAGE_FLIP_EN   = 0,
  parameter IMAGE_MIRROR_EN = 0
)
(
  input      Clk,
  input      Rst_n,

  output reg Init_Done,
  output reg Ack_Seen,
  output reg Nack_Seen,
  output [7:0] Debug_Index,
  output reg [15:0] Debug_ChipId,
  output reg [15:0] Debug_ReadAddr,
  output reg [7:0] Debug_ReadValue,
  output reg [7:0] Debug_Expected,
  output reg Verify_Failed,
  output     camera_rst_n,
  output     camera_pwdn,

  output     i2c_sclk,
  inout      i2c_sdat
);
  localparam RGB = 0;
  localparam JPEG = 1;
  localparam DELAY_1ms_CNT  = 1_000_000/(1_000_000_000/SYS_CLOCK);
  localparam DELAY_21ms_CNT = 21_000_000/(1_000_000_000/SYS_CLOCK);
  localparam DELAY_5ms_CNT  = 5_000_000/(1_000_000_000/SYS_CLOCK);

  wire [15:0]addr;
  reg wrreg_req;
  reg rdreg_req;
  wire [7:0]wrdata;
  wire [7:0]rddata;
  wire RW_Done;
  wire ack;
  reg [31:0] i2c_dly_cnt_max;

  reg [7:0]cnt;
  wire [23:0]lut;

  wire [7:0]lut_size;
  wire [7:0]device_id;
  wire addr_mode;

  assign camera_pwdn = 0;

  generate
  ////////////////////////////ov5640///////////////////////////////
  if(CAMERA_TYPE == "ov5640")
  begin
    assign device_id = 8'h78;
    assign addr_mode = 1'b1;
    assign addr = verifying ? verify_word[23:8] : lut[23:8];
    assign wrdata = lut[7:0];

    if(IMAGE_TYPE == RGB) //------RGB------
    begin
      assign lut_size = 255;

      ov5640_init_table_rgb #(
        .IMAGE_WIDTH     (IMAGE_WIDTH     ),
        .IMAGE_HEIGHT    (IMAGE_HEIGHT    ),
        .IMAGE_FLIP_EN   (IMAGE_FLIP_EN   ),
        .IMAGE_MIRROR_EN (IMAGE_MIRROR_EN )
      )ov5640_init_table_rgb_inst
      (
        .addr (cnt ),
        .clk  (Clk ),
        .q    (lut )
      );
    end
    else  //------JPEG------
    begin
      assign lut_size = 250;

      ov5640_init_table_jpeg #(
        .IMAGE_WIDTH     (IMAGE_WIDTH     ),
        .IMAGE_HEIGHT    (IMAGE_HEIGHT    ),
        .IMAGE_FLIP_EN   (IMAGE_FLIP_EN   ),
        .IMAGE_MIRROR_EN (IMAGE_MIRROR_EN )
      )ov5640_init_table_jpeg_inst
      (
        .addr (cnt ),
        .clk  (Clk ),
        .q    (lut )
      );
    end
  end
  ////////////////////////////ov7725////////////////////////////////
  else if(CAMERA_TYPE == "ov7725")
  begin
    assign device_id = 8'h42;
    assign addr_mode = 1'b0;
    assign addr = lut[15:8];
    assign wrdata = lut[7:0];

    if(IMAGE_TYPE == RGB) //------RGB------
    begin
      assign lut_size  = 68;

      ov7725_init_table_rgb #(
        .IMAGE_FLIP_EN   (IMAGE_FLIP_EN   ),
        .IMAGE_MIRROR_EN (IMAGE_MIRROR_EN )
      )ov7725_init_table_rgb_inst
      (
        .addr (cnt ),
        .clk  (Clk ),
        .q    (lut )
      );
    end
  end
  endgenerate


  i2c_control #(
    .SYS_CLOCK (SYS_CLOCK ),
    .SCL_CLOCK (SCL_CLOCK )
  )i2c_control(
    .Clk         (Clk             ),
    .Rst_n       (Rst_n           ),
    .wrreg_req   (wrreg_req       ),
    .rdreg_req   (rdreg_req       ),
    .addr        (addr            ),
    .addr_mode   (addr_mode       ),
    .wrdata      (wrdata          ),
    .rddata      (rddata          ),
    .device_id   (device_id       ),
    .RW_Done     (RW_Done         ),
    .ack         (ack             ),
    .dly_cnt_max (i2c_dly_cnt_max ),
    .i2c_sclk    (i2c_sclk        ),
    .i2c_sdat    (i2c_sdat        )
  );

  // Readback is mandatory for OV5640 RGB. ACK alone cannot verify the data.
  localparam DO_VERIFY = (CAMERA_TYPE == "ov5640" && IMAGE_TYPE == RGB);
  localparam WAIT_START=0, ISSUE_WRITE=1, WAIT_WRITE=2,
             ISSUE_READ=3, WAIT_READ=4, RETRY_READ=5, FINISHED=6;
  reg [2:0] state;
  reg [4:0] verify_index;
  reg [31:0] retry_count;
  wire verifying = (state==ISSUE_READ || state==WAIT_READ || state==RETRY_READ);
  reg [23:0] verify_word;
  reg [7:0] verify_mask;
  always @* begin
    verify_mask=8'hff;
    case(verify_index)
      0: verify_word=24'h300a56;
      1: verify_word=24'h300b40;
      2: verify_word=24'h303581;
      3: verify_word=24'h303654;
      4: verify_word={16'h3808,IMAGE_WIDTH[15:8]};
      5: verify_word={16'h3809,IMAGE_WIDTH[7:0]};
      6: verify_word={16'h380a,IMAGE_HEIGHT[15:8]};
      7: verify_word={16'h380b,IMAGE_HEIGHT[7:0]};
      8: verify_word=24'h430061;
      9: verify_word=24'h501f01;
      10: verify_word=24'h474020;
      11: verify_word=24'h3017ff;
      12: verify_word=24'h3018ff;
      13: verify_word=24'h300e58;
      14: verify_word=24'h503d00;
      15: begin verify_word=24'h302c42;verify_mask=8'hc0;end
      16: begin verify_word=24'h300802;verify_mask=8'hc0;end
      default: verify_word=0;
    endcase
  end
  assign Debug_Index = verifying ? {3'b100,verify_index} : cnt;
  // Hold hardware reset low for 1 ms; allow 20 ms after release before SCCB.
  reg [31:0] delay_cnt;
  assign camera_rst_n = (delay_cnt > DELAY_1ms_CNT);
  always @(posedge Clk or negedge Rst_n)
    if(!Rst_n) delay_cnt<=0;
    else if(delay_cnt<DELAY_21ms_CNT) delay_cnt<=delay_cnt+1'b1;

  always @(posedge Clk or negedge Rst_n)
    if(!Rst_n) begin
      state<=WAIT_START;cnt<=0;verify_index<=0;retry_count<=0;
      wrreg_req<=0;rdreg_req<=0;i2c_dly_cnt_max<=0;
      Init_Done<=0;Ack_Seen<=0;Nack_Seen<=0;Verify_Failed<=0;
      Debug_ChipId<=0;Debug_ReadAddr<=0;Debug_ReadValue<=0;Debug_Expected<=0;
    end else begin
      wrreg_req<=0;rdreg_req<=0;
      if(RW_Done) begin
        if(ack) Nack_Seen<=1; else Ack_Seen<=1;
      end
      case(state)
        WAIT_START: if(delay_cnt==DELAY_21ms_CNT) state<=ISSUE_WRITE;
        ISSUE_WRITE: begin
          wrreg_req<=1;
          i2c_dly_cnt_max<=(cnt==1) ? DELAY_5ms_CNT : 0;
          state<=WAIT_WRITE;
        end
        WAIT_WRITE: if(RW_Done) begin
          if(ack) state<=ISSUE_WRITE; // Retry the exact same LUT entry.
          else if(cnt==lut_size-1'b1) begin
            if(DO_VERIFY) begin verify_index<=0;state<=ISSUE_READ;end
            else begin Init_Done<=1;state<=FINISHED;end
          end else begin cnt<=cnt+1'b1;state<=ISSUE_WRITE;end
        end
        ISSUE_READ: begin
          i2c_dly_cnt_max<=0;rdreg_req<=1;state<=WAIT_READ;
        end
        WAIT_READ: if(RW_Done) begin
          Debug_ReadAddr<=verify_word[23:8];Debug_ReadValue<=rddata;
          Debug_Expected<=verify_word[7:0];
          if(verify_index==0) Debug_ChipId[15:8]<=rddata;
          if(verify_index==1) Debug_ChipId[7:0]<=rddata;
          if(ack || ((rddata & verify_mask)!=(verify_word[7:0] & verify_mask))) begin
            Verify_Failed<=1;retry_count<=0;state<=RETRY_READ;
          end else if(verify_index==16) begin Init_Done<=1;state<=FINISHED;end
          else begin verify_index<=verify_index+1'b1;state<=ISSUE_READ;end
        end
        RETRY_READ: if(retry_count>=DELAY_21ms_CNT) state<=ISSUE_READ;
                    else retry_count<=retry_count+1'b1;
        FINISHED: begin end
        default: state<=WAIT_START;
      endcase
    end
endmodule
