# No DDR PLL/controller/FIFOs in the compact build.
create_clock -name sys_50m -period 20.000 [get_ports {clk50M}]
# Provisional analysis budget; not a measured PCLK or source-synchronous input delay.
create_clock -name cam_pclk -period 10.000 [get_ports {camera_pclk}]
create_generated_clock -name logic_50m -source [get_ports {clk50M}] -divide_by 1 [get_pins {Gowin_PLL/PLLA_inst/CLKOUT1}]
create_generated_clock -name camera_mclk_25m -source [get_ports {clk50M}] -divide_by 2 [get_pins {Gowin_PLL/PLLA_inst/CLKOUT2}]
# Camera crossings: explicit dual-clock RAM and request/response synchronizers.
set_clock_groups -asynchronous -group [get_clocks {sys_50m logic_50m camera_mclk_25m}] -group [get_clocks {cam_pclk}]
