`timescale 1ns/1ps
`default_nettype none
// Standalone v7: OV5640 full VGA -> gray resize -> automatic ROI/water -> MCU SPI.
module vortex_camera_ai_compact #(
    parameter integer IMAGE_WIDTH=256,IMAGE_HEIGHT=256,CAMERA_SLEEP_ENABLE=1,
    parameter integer CAMERA_WIDTH=640,CAMERA_HEIGHT=480
)(
    input wire clk50M,reset_n,
    output wire camera_sclk,inout wire camera_sdat,
    input wire camera_vsync,camera_href,camera_pclk,
    output wire camera_xclk,input wire [7:0]camera_data,
    output wire camera_rst_n,camera_pwdn,
    input wire spi_cs_n,spi_sck,spi_mosi,output wire spi_miso,
    output wire [3:0]led,output wire O_ddr_reset_n
);
    wire pll_lock,loc_clk50m,loc_clk25m;
    wire system_ready,config_reset_n,pclk_reset_n,vision_reset_n;
    wire camera_init_done,vision_busy,vision_ready,vision_camera_awake;
    wire [7:0]vision_status;
    // Heartbeat in the PCLK domain, synchronized before driving an LED.
    reg [23:0]pclk_count;
    (* syn_preserve=1 *) reg [1:0]pclk_heartbeat_sync;
    assign system_ready=reset_n && pll_lock;
    assign O_ddr_reset_n=1'b0;
    assign camera_xclk=loc_clk25m;
    assign camera_pwdn=CAMERA_SLEEP_ENABLE ? ~vision_camera_awake : 1'b0;
    Gowin_PLL Gowin_PLL(.lock(pll_lock),.clkout0(),.clkout1(loc_clk50m),
        .clkout2(loc_clk25m),.clkin(clk50M),.reset(~reset_n));
    reset_release config_reset(.clk(loc_clk50m),
        .async_ready(system_ready && (!CAMERA_SLEEP_ENABLE || vision_camera_awake)),.reset_n(config_reset_n));
    // Do NOT reset capture handshake on camera sleep: PCLK may stop and its
    // toggle state must survive the next wake/reconfiguration.
    reset_release pclk_reset(.clk(camera_pclk),.async_ready(system_ready),.reset_n(pclk_reset_n));
    reset_release vision_reset(.clk(clk50M),.async_ready(system_ready),.reset_n(vision_reset_n));
    camera_init #(.SYS_CLOCK(50_000_000),.SCL_CLOCK(100_000),.CAMERA_TYPE("ov5640"),
        .IMAGE_TYPE(0),.IMAGE_WIDTH(CAMERA_WIDTH),.IMAGE_HEIGHT(CAMERA_HEIGHT),
        .IMAGE_FLIP_EN(0),.IMAGE_MIRROR_EN(0)) camera_init(
        .Clk(loc_clk50m),.Rst_n(config_reset_n),.Init_Done(camera_init_done),
        .camera_rst_n(camera_rst_n),.camera_pwdn(),.i2c_sclk(camera_sclk),.i2c_sdat(camera_sdat),
        .Debug_ChipId(),.Debug_ReadAddr(),.Debug_ReadValue(),.Debug_Expected(),
        .Verify_Failed(),.Ack_Seen(),.Nack_Seen(),.Debug_Index());
    vision_system #(.WIDTH(IMAGE_WIDTH),.HEIGHT(IMAGE_HEIGHT),
        .CAMERA_WIDTH(CAMERA_WIDTH),.CAMERA_HEIGHT(CAMERA_HEIGHT)) vision(
        .clk(clk50M),.reset_n(vision_reset_n),.camera_clk(camera_pclk),.camera_reset_n(pclk_reset_n),
        .camera_ready(camera_init_done),.camera_vsync(camera_vsync),.camera_href(camera_href),.camera_data(camera_data),
        .spi_cs_n(spi_cs_n),.spi_sck(spi_sck),.spi_mosi(spi_mosi),.spi_miso(spi_miso),
        .busy(vision_busy),.ready(vision_ready),.camera_awake(vision_camera_awake),
        .led_level(),.led_written(),.status_out(vision_status));
    always @(posedge camera_pclk or negedge pclk_reset_n)
        if(!pclk_reset_n)pclk_count<=0;else pclk_count<=pclk_count+1'b1;
    always @(posedge clk50M or negedge vision_reset_n)
        if(!vision_reset_n)pclk_heartbeat_sync<=0;
        else pclk_heartbeat_sync<={pclk_heartbeat_sync[0],pclk_count[23]};
    assign led={pclk_heartbeat_sync[1],vision_ready,vision_busy,pll_lock};
endmodule
`default_nettype wire
