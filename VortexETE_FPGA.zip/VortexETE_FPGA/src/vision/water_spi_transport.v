`timescale 1ns/1ps
// Same filtered Mode-0 pin timing as the SPI link validated on the user's kits.
// clk=50 MHz, SCK<=100 kHz, >=2 us CS setup/hold and MOSI setup.
// 03: opcode, address MSB, address LSB, dummy, read data...
// 02: opcode, address MSB, address LSB, one write byte.
module water_spi_transport(
 input wire clk,reset_n,spi_cs_n,spi_sck,spi_mosi,
 output wire spi_miso,
 input wire [479:0] registers,
 output reg write_valid,output reg [15:0] write_address,
 output reg [7:0] write_data,
 output reg cs_seen,command_seen
);
 (* syn_preserve=1 *) reg [2:0] cs_sync,mosi_sync;
 wire rise,fall,sck_level;
 spi_sck_filter filter(.clk(clk),.reset_n(reset_n),.spi_sck(spi_sck),
  .level(sck_level),.rise(rise),.fall(fall));
 reg [2:0] bits;
 reg [7:0] rx,tx,opcode;
 reg [3:0] phase;
 reg [15:0] address;
 reg [479:0] snapshot;
 wire [7:0] received={rx[6:0],mosi_sync[2]};
 wire reading=(opcode==8'h03);
 wire [7:0] register_data=(address<60)?snapshot[address*8+:8]:8'hFF;
 wire [7:0] read_data=register_data;
 assign spi_miso=(spi_cs_n||!reset_n)?1'bz:tx[7];
 always @(posedge clk or negedge reset_n)begin
  if(!reset_n)begin cs_sync<=7;mosi_sync<=0;end
  else begin cs_sync<={cs_sync[1:0],spi_cs_n};mosi_sync<={mosi_sync[1:0],spi_mosi};end
 end
 always @(posedge clk or negedge reset_n)begin
  if(!reset_n)begin
   bits<=0;rx<=0;tx<=0;opcode<=0;phase<=0;address<=0;snapshot<=0;
   write_valid<=0;write_address<=0;write_data<=0;cs_seen<=0;command_seen<=0;
  end else begin
   write_valid<=0;
   if(cs_sync[2])begin
    bits<=0;rx<=0;tx<=0;opcode<=0;phase<=0;address<=0;
    snapshot<=registers;
   end else begin
    cs_seen<=1;
    if(rise)begin
     rx<=received;bits<=bits+1'b1;
     if(bits==7)begin
      if(phase==0)begin opcode<=received;phase<=1;command_seen<=1;end
      else if(reading||opcode==8'h02)begin
       case(phase)
        1:begin address[15:8]<=received;phase<=2;end
        2:begin address[7:0]<=received;phase<=3;end
        3:begin
         if(opcode==8'h02)begin write_valid<=1;write_address<=address;write_data<=received;end
         phase<=4;
        end
        default:if(reading)address<=address+1'b1;
       endcase
      end else if(phase<8)phase<=phase+1'b1;
     end
    end
    if(fall)begin
     if(bits!=0)tx<={tx[6:0],1'b0};
     else if(reading && phase>=4)tx<=read_data;
     else if(opcode==8'h9F)begin
      case(phase)1:tx<=8'hA5;2:tx<=8'h5A;3:tx<=8'h12;4:tx<=8'h34;default:tx<=0;endcase
     end else tx<=0; // includes Flash sleep command B9: ignored by FPGA
    end
   end
  end
 end
endmodule
