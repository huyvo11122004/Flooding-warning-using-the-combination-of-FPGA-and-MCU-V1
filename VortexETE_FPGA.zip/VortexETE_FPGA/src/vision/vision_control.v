`timescale 1ns/1ps
module vision_control #(
    parameter integer WIDTH=256,HEIGHT=256,CLK_HZ=50_000_000,
    parameter integer CONFIG_TIMEOUT=CLK_HZ*12,CAPTURE_TIMEOUT=CLK_HZ*12,
    parameter integer WARNING_PERCENT=5,CRITICAL_PERCENT=25,MIN_CONTRAST=8,MIN_ROI_PIXELS=(WIDTH*HEIGHT+199)/200
)(
    input wire clk,reset_n,camera_ready,transport_lock,
    input wire start_command,input wire [7:0] sensor_level,
    input wire ack_command,input wire [31:0] ack_frame_id,
    input wire roi_command,
    input wire [15:0] new_x0,new_y0,new_x1,new_y1,
    output reg [15:0] roi_x0,roi_y0,roi_x1,roi_y1,
    output wire can_start,ready,busy,camera_awake,
    output wire [7:0] status,
    output reg snapshot_request,
    output reg [31:0] frame_id,
    input wire snapshot_done_toggle,
    input wire [31:0] snapshot_id,
    input wire snapshot_ok,
    input wire [15:0] snapshot_lines,
    input wire [31:0] snapshot_pixels,
    output reg engine_start,
    input wire engine_done,
    input wire [31:0] engine_water_roi,engine_roi_pixels,engine_water_total,engine_cycles,
    input wire [15:0] engine_image_crc,engine_mask_crc,engine_roi_crc,
    input wire [7:0] engine_min,engine_max,
    output reg [383:0] result_packet
);
    localparam [3:0] IDLE=0,WAKE=1,SNAPSHOT=2,INFERENCE=3,DIVIDE=4,BUILD=5,TRAILER=6,HOLD=7;
    reg [3:0] state;
    (* syn_preserve=1 *) reg [1:0] camera_sync,done_sync;
    reg done_seen,critical_keep_awake;
    reg [31:0] wait_cycles,elapsed,elapsed_latched;
    reg [7:0] error_code,vision_level,requested_sensor,minimum,maximum;
    reg [31:0] water_roi,roi_area,water_total,infer_cycles,pixels;
    reg [15:0] image_crc,mask_crc,roi_crc,lines,coverage;
    reg [31:0] dividend,quotient;
    reg [32:0] remainder;
    reg [5:0] divide_count,packet_index;
    reg [15:0] packet_crc;
    wire [32:0] trial_remainder={remainder[31:0],dividend[31]};
    wire quotient_bit=trial_remainder>={1'b0,roi_area};
    wire [31:0] next_quotient={quotient[30:0],quotient_bit};
    wire roi_valid=new_x0<new_x1 && new_y0<new_y1 && new_x1<=WIDTH[15:0] && new_y1<=HEIGHT[15:0];
    wire low_contrast=maximum-minimum<8;
    assign ready=state==HOLD;
    assign busy=state!=IDLE && state!=HOLD;
    assign can_start=state==IDLE && !transport_lock;
    assign camera_awake=state==WAKE || state==SNAPSHOT || critical_keep_awake;
    assign status={3'b0,camera_awake,(ready && error_code!=0),camera_sync[1],ready,(busy || transport_lock)};
    function [15:0] crc_byte;
        input [15:0] initial_crc;input [7:0] value;integer j;reg [15:0] c;
        begin
            c=initial_crc^{value,8'b0};
            for(j=0;j<8;j=j+1)c=c[15] ? (c<<1)^16'h1021 : c<<1;
            crc_byte=c;
        end
    endfunction
    function [7:0] packet_byte;
        input [5:0] n;
        begin
            case(n)
                0:packet_byte=8'ha5;1:packet_byte=8'h56;2:packet_byte=2;
                // bit0 valid, bit1 models unvalidated, bit2 depth(always0),
                // bit3 rectangle(always0), bit4 low contrast, bit5 automatic ROI.
                3:packet_byte={2'b0,1'b1,low_contrast,1'b0,1'b0,1'b1,(error_code==0)};
                4:packet_byte=vision_level;5:packet_byte=error_code;
                6:packet_byte=requested_sensor;7:packet_byte=1; // automatic student ROI
                8,9,10,11:packet_byte=frame_id[(n-8)*8+:8];
                12,13,14,15:packet_byte=water_roi[(n-12)*8+:8];
                16,17,18,19:packet_byte=roi_area[(n-16)*8+:8];
                20,21,22,23:packet_byte=water_total[(n-20)*8+:8];
                24,25:packet_byte=coverage[(n-24)*8+:8];
                26,27:packet_byte=image_crc[(n-26)*8+:8];
                28,29:packet_byte=mask_crc[(n-28)*8+:8];
                30,31,32,33:packet_byte=elapsed_latched[(n-30)*8+:8];
                34,35,36,37:packet_byte=infer_cycles[(n-34)*8+:8];
                38,39:packet_byte=roi_crc[(n-38)*8+:8];
                40,41,42,43:packet_byte=pixels[(n-40)*8+:8];
                44:packet_byte=minimum;45:packet_byte=maximum;
                default:packet_byte=0;
            endcase
        end
    endfunction
    wire [7:0] building_byte=packet_byte(packet_index);
    always @(posedge clk or negedge reset_n)begin
        if(!reset_n)begin
            state<=IDLE;camera_sync<=0;done_sync<=0;done_seen<=0;critical_keep_awake<=0;
            snapshot_request<=0;frame_id<=0;engine_start<=0;
            roi_x0<=0;roi_y0<=0;roi_x1<=WIDTH;roi_y1<=HEIGHT;
            wait_cycles<=0;elapsed<=0;elapsed_latched<=0;
            error_code<=0;vision_level<=255;requested_sensor<=255;
            water_roi<=0;roi_area<=0;water_total<=0;infer_cycles<=0;
            image_crc<=0;mask_crc<=0;roi_crc<=0;lines<=0;pixels<=0;coverage<=0;
            minimum<=0;maximum<=0;dividend<=0;quotient<=0;remainder<=0;
            divide_count<=0;packet_index<=0;packet_crc<=16'hffff;result_packet<=0;
        end else begin
            camera_sync<={camera_sync[0],camera_ready};
            done_sync<={done_sync[0],snapshot_done_toggle};
            if(done_sync[1]!=done_seen)done_seen<=done_sync[1];
            engine_start<=0;
            if(busy && elapsed!=32'hffffffff)elapsed<=elapsed+1'b1;
            case(state)
                IDLE:begin
                    // Automatic ROI comes from the image model; no rectangle override.
                    if(start_command && can_start)begin
                        frame_id<=frame_id+1'b1;requested_sensor<=sensor_level;
                        critical_keep_awake<=sensor_level==2;
                        state<=WAKE;wait_cycles<=0;elapsed<=0;
                        error_code<=0;vision_level<=255;coverage<=0;
                        water_roi<=0;roi_area<=0;water_total<=0;infer_cycles<=0;
                        image_crc<=0;mask_crc<=0;roi_crc<=0;lines<=0;pixels<=0;minimum<=0;maximum<=0;
                    end
                end
                WAKE:begin
                    if(camera_sync[1])begin
                        snapshot_request<=~snapshot_request;
                        wait_cycles<=0;state<=SNAPSHOT;
                    end else if(wait_cycles>=CONFIG_TIMEOUT[31:0]-32'd1)begin
                        critical_keep_awake<=0;error_code<=1;elapsed_latched<=elapsed+32'd48;state<=BUILD;packet_index<=0;packet_crc<=16'hffff;
                    end else wait_cycles<=wait_cycles+1'b1;
                end
                SNAPSHOT:begin
                    if(done_sync[1]!=done_seen && snapshot_id==frame_id)begin
                        lines<=snapshot_lines;pixels<=snapshot_pixels;
                        if(snapshot_ok)begin engine_start<=1;state<=INFERENCE;end
                        else begin
                            critical_keep_awake<=0;error_code<=3;elapsed_latched<=elapsed+32'd48;state<=BUILD;packet_index<=0;packet_crc<=16'hffff;
                        end
                    end else if(wait_cycles>=CAPTURE_TIMEOUT[31:0]-32'd1)begin
                        critical_keep_awake<=0;error_code<=2;elapsed_latched<=elapsed+32'd48;state<=BUILD;packet_index<=0;packet_crc<=16'hffff;
                    end else wait_cycles<=wait_cycles+1'b1;
                end
                INFERENCE:if(engine_done)begin
                    water_roi<=engine_water_roi;roi_area<=engine_roi_pixels;water_total<=engine_water_total;
                    infer_cycles<=engine_cycles;image_crc<=engine_image_crc;mask_crc<=engine_mask_crc;roi_crc<=engine_roi_crc;
                    minimum<=engine_min;maximum<=engine_max;
                    if(engine_water_total==0 && engine_roi_pixels==0 && engine_water_roi==0)begin
                        // Explicit no-water result: ROI intentionally skipped;
                        // 0 percent is a protocol convention, never a 0/0 divide.
                        if(MIN_CONTRAST>0 && engine_max-engine_min<MIN_CONTRAST[7:0])begin
                            error_code<=5;critical_keep_awake<=0;
                        end else begin vision_level<=0;coverage<=0;end
                        elapsed_latched<=elapsed+32'd48;state<=BUILD;packet_index<=0;packet_crc<=16'hffff;
                    end else if(engine_roi_pixels<MIN_ROI_PIXELS ||
                       (MIN_CONTRAST>0 && engine_max-engine_min<MIN_CONTRAST[7:0]))begin
                        error_code<=engine_roi_pixels==0 ? 8'd4 : engine_roi_pixels<MIN_ROI_PIXELS ? 8'd6 : 8'd5;
                        critical_keep_awake<=0;
                        elapsed_latched<=elapsed+32'd48;state<=BUILD;packet_index<=0;packet_crc<=16'hffff;
                    end else begin
                        if(engine_water_roi*32'd100>=engine_roi_pixels*CRITICAL_PERCENT[31:0])vision_level<=2;
                        else if(engine_water_roi*32'd100>=engine_roi_pixels*WARNING_PERCENT[31:0])vision_level<=1;
                        else vision_level<=0;
                        dividend<=engine_water_roi*32'd10000;quotient<=0;remainder<=0;
                        divide_count<=0;state<=DIVIDE;
                    end
                end
                DIVIDE:begin
                    dividend<=dividend<<1;quotient<=next_quotient;
                    remainder<=quotient_bit ? trial_remainder-{1'b0,roi_area} : trial_remainder;
                    if(divide_count==31)begin
                        coverage<=next_quotient[15:0];elapsed_latched<=elapsed+32'd48;
                        state<=BUILD;packet_index<=0;packet_crc<=16'hffff;
                    end else divide_count<=divide_count+1'b1;
                end
                BUILD:begin
                    result_packet[packet_index*8+:8]<=building_byte;
                    packet_crc<=crc_byte(packet_crc,building_byte);
                    if(packet_index==45)state<=TRAILER;
                    else packet_index<=packet_index+1'b1;
                end
                TRAILER:begin result_packet[368+:16]<=packet_crc;state<=HOLD;end
                HOLD:if(ack_command && ack_frame_id==frame_id)state<=IDLE;
                default:state<=IDLE;
            endcase
        end
    end
endmodule
