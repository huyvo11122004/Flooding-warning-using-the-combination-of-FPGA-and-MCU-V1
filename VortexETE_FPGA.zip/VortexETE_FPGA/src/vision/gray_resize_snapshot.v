`timescale 1ns/1ps
// Validate the entire source DVP frame and resize it to OUT_WIDTH x OUT_HEIGHT gray8.
// Endpoint-aligned nearest-neighbor: sx=floor(dx*(IN_WIDTH-1)/(OUT_WIDTH-1)),
// sy=floor(dy*(IN_HEIGHT-1)/(OUT_HEIGHT-1)). Both first and last source pixels are mapped.
// Integer DDA uses constants/adds/compares only in the pixel-clock datapath.
// No source-size framebuffer; only the destination is written to RAM.
module gray_resize_snapshot #(
    parameter integer IN_WIDTH=640,IN_HEIGHT=480,OUT_WIDTH=256,OUT_HEIGHT=256,WARMUP_FRAMES=10
)(
    input wire pclk,reset_n,camera_ready,vsync,href,
    input wire [7:0]data,input wire request_toggle,input wire [31:0]request_id,
    output reg done_toggle,output reg [31:0]done_id,output reg frame_ok,
    output reg [15:0]captured_lines,output reg [31:0]captured_pixels,
    output reg write_valid,output reg [15:0]write_address,output reg [7:0]write_gray
);
    localparam [1:0]WAIT_REQUEST=0,ARM=1,CAPTURE=2;
    localparam [31:0]SOURCE_PIXELS=IN_WIDTH*IN_HEIGHT;
    localparam [16:0]DEST_PIXELS=OUT_WIDTH*OUT_HEIGHT;
    localparam [15:0]X_DEN=OUT_WIDTH-1,Y_DEN=OUT_HEIGHT-1;
    localparam [16:0]LINE_BYTES=IN_WIDTH*2;
    localparam [15:0]X_STEP=(IN_WIDTH-1)/(OUT_WIDTH-1),X_REM=(IN_WIDTH-1)%(OUT_WIDTH-1);
    localparam [15:0]Y_STEP=(IN_HEIGHT-1)/(OUT_HEIGHT-1),Y_REM=(IN_HEIGHT-1)%(OUT_HEIGHT-1);
    reg [1:0]state;
    (* syn_preserve=1 *) reg [1:0]request_sync,ready_sync;
    reg request_seen,vs_d,href_d,bad_frame;
    reg [7:0]warmup,high_byte;
    reg [16:0]line_bytes,resized_pixels;
    reg [15:0]lines,target_x,target_y,x_error,y_error;
    reg [8:0]out_x,out_y;
    reg [31:0]pixels,active_id;
    wire frame_edge=vsync && !vs_d;
    wire [15:0]source_x=line_bytes[16:1];
    wire [16:0]next_x_error={1'b0,x_error}+{1'b0,X_REM};
    wire [16:0]next_y_error={1'b0,y_error}+{1'b0,Y_REM};
    wire [15:0]rgb565={high_byte,data};
    wire [7:0]red={rgb565[15:11],rgb565[15:13]};
    wire [7:0]green={rgb565[10:5],rgb565[10:9]};
    wire [7:0]blue={rgb565[4:0],rgb565[4:2]};
    wire [17:0]luminance=18'd77*red+18'd150*green+18'd29*blue+18'd128;
    always @(posedge pclk or negedge reset_n)begin
        if(!reset_n)begin
            request_sync<=0;ready_sync<=0;request_seen<=0;vs_d<=0;href_d<=0;
            state<=WAIT_REQUEST;warmup<=0;high_byte<=0;bad_frame<=0;
            line_bytes<=0;lines<=0;pixels<=0;active_id<=0;
            target_x<=0;target_y<=0;x_error<=0;y_error<=0;out_x<=0;out_y<=0;resized_pixels<=0;
            done_toggle<=0;done_id<=0;frame_ok<=0;captured_lines<=0;captured_pixels<=0;
            write_valid<=0;write_address<=0;write_gray<=0;
        end else begin
            request_sync<={request_sync[0],request_toggle};ready_sync<={ready_sync[0],camera_ready};
            vs_d<=vsync;href_d<=href;write_valid<=0;
            if(!ready_sync[1])warmup<=0;
            else if(frame_edge && warmup<WARMUP_FRAMES[7:0])warmup<=warmup+1'b1;
            if(request_sync[1]!=request_seen)begin
                request_seen<=request_sync[1];active_id<=request_id;state<=ARM;
                line_bytes<=0;lines<=0;pixels<=0;bad_frame<=0;
            end else case(state)
                WAIT_REQUEST:begin end
                ARM:if(frame_edge && ready_sync[1] && warmup>=WARMUP_FRAMES[7:0])begin
                    state<=CAPTURE;line_bytes<=0;lines<=0;pixels<=0;bad_frame<=href;
                    target_x<=0;target_y<=0;x_error<=0;y_error<=0;
                    out_x<=0;out_y<=0;resized_pixels<=0;
                end
                CAPTURE:begin
                    if(!ready_sync[1])bad_frame<=1;
                    if(frame_edge)begin
                        frame_ok<=!bad_frame && !href && !href_d && ready_sync[1] &&
                            lines==IN_HEIGHT[15:0] && pixels==SOURCE_PIXELS &&
                            out_y==OUT_HEIGHT && resized_pixels==DEST_PIXELS;
                        captured_lines<=lines;captured_pixels<=pixels;
                        done_id<=active_id;done_toggle<=~done_toggle;state<=WAIT_REQUEST;
                    end else if(!vsync)begin
                        if(href)begin
                            if(line_bytes<17'h1ffff)line_bytes<=line_bytes+1'b1;
                            if(lines>=IN_HEIGHT[15:0] || line_bytes>=LINE_BYTES)bad_frame<=1;
                            if(!line_bytes[0])high_byte<=data;
                            else begin
                                if(lines<IN_HEIGHT[15:0] && line_bytes<LINE_BYTES &&
                                   lines==target_y && out_y<OUT_HEIGHT && source_x==target_x && out_x<OUT_WIDTH)begin
                                    write_valid<=1;write_address<=resized_pixels[15:0];
                                    write_gray<=luminance[15:8];resized_pixels<=resized_pixels+1'b1;
                                    out_x<=out_x+1'b1;
                                    if(out_x<OUT_WIDTH-1)begin
                                        if(next_x_error>={1'b0,X_DEN})begin
                                            target_x<=target_x+X_STEP+16'd1;x_error<=next_x_error[15:0]-X_DEN;
                                        end else begin target_x<=target_x+X_STEP;x_error<=next_x_error[15:0];end
                                    end
                                end
                                if(pixels!=32'hffffffff)pixels<=pixels+1'b1;
                            end
                        end else if(href_d)begin
                            if(line_bytes!=LINE_BYTES)bad_frame<=1;
                            if(lines==target_y && out_y<OUT_HEIGHT)begin
                                if(out_x!=OUT_WIDTH)bad_frame<=1;
                                out_y<=out_y+1'b1;out_x<=0;target_x<=0;x_error<=0;
                                if(out_y<OUT_HEIGHT-1)begin
                                    if(next_y_error>={1'b0,Y_DEN})begin
                                        target_y<=target_y+Y_STEP+16'd1;y_error<=next_y_error[15:0]-Y_DEN;
                                    end else begin target_y<=target_y+Y_STEP;y_error<=next_y_error[15:0];end
                                end
                            end
                            if(lines!=16'hffff)lines<=lines+1'b1;
                            line_bytes<=0;
                        end
                    end
                end
                default:state<=WAIT_REQUEST;
            endcase
        end
    end
endmodule
