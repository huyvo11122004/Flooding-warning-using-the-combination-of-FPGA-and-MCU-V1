`timescale 1ns/1ps
// 3-stage input synchronizer, then require four consecutive changed samples.
// 50 MHz nominal; added latency is small compared with a 5 us SCK half-cycle.
// This rejects short pulses; it cannot repair long ringing or bad wiring.
module spi_sck_filter(input wire clk,reset_n,spi_sck,
                      output reg level,output wire rise,fall);
    (* syn_preserve=1 *) reg [2:0] sync_ff;
    reg [1:0] stable_count;
    reg previous;
    assign rise=level & ~previous;
    assign fall=~level & previous;
    always @(posedge clk or negedge reset_n) begin
        if(!reset_n)begin sync_ff<=0;stable_count<=0;level<=0;previous<=0;end
        else begin
            sync_ff<={sync_ff[1:0],spi_sck};
            previous<=level;
            if(sync_ff[2]==level)stable_count<=0;
            else if(stable_count==3)begin level<=sync_ff[2];stable_count<=0;end
            else stable_count<=stable_count+1'b1;
        end
    end
endmodule
