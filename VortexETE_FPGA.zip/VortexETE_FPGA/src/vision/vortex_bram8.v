`timescale 1ns/1ps
// Explicit 2048 x 8 semi-dual-port banks. One SDPB per bank; no automatic
// replication of a large inferred memory. Same 1-read-clock latency as v1.
// SDPB addresses are bit addresses: byte index occupies address bits [13:3].
// Reference: UG300, Table 3-8: SDPB has ONE shared RESET port.
// RESETA/RESETB are not SDPB ports on GW5A; do not copy the DPB interface.
module vortex_bram8 #(
    parameter integer DEPTH=65536
)(
    input wire write_clk,write_enable,
    input wire [15:0] write_address,input wire [7:0] write_data,
    input wire read_clk,read_enable,input wire [15:0] read_address,
    output wire [7:0] read_data
);
    localparam integer BANKS=(DEPTH+2047)/2048;
    wire [BANKS*8-1:0] bank_outputs;
    reg [4:0] selected_read_bank;
    always @(posedge read_clk)
        if(read_enable)selected_read_bank<=read_address[15:11];
    assign read_data=bank_outputs[{selected_read_bank,3'b000}+:8];
    genvar b;
    generate for(b=0;b<BANKS;b=b+1)begin: banks
        wire [31:0] q;
        localparam [4:0] BANK_ID=b;
        SDPB #(.BIT_WIDTH_0(8),.BIT_WIDTH_1(8),.READ_MODE(1'b0),
            .BLK_SEL_0(3'b000),.BLK_SEL_1(3'b000),.RESET_MODE("SYNC")) ram(
            .DO(q),.DI({24'b0,write_data}),
            .CLKA(write_clk),.CEA(write_enable && write_address[15:11]==BANK_ID),
            .CLKB(read_clk),.CEB(read_enable && read_address[15:11]==BANK_ID),
            .ADA({write_address[10:0],3'b000}),.ADB({read_address[10:0],3'b000}),
            .OCE(1'b1),.RESET(1'b0),
            .BLKSELA(3'b000),.BLKSELB(3'b000));
        assign bank_outputs[b*8+:8]=q[7:0];
    end endgenerate
endmodule
