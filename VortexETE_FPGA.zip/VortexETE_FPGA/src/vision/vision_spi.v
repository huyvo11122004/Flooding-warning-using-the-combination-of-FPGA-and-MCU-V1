`timescale 1ns/1ps
// Camera adapter for the existing MCU register transport. No image ROM.
// 03 AH AL dummy data..., 02 AH AL value; SPI mode 0 <=100 kHz.
module vision_spi #(
    parameter integer WIDTH=256,HEIGHT=256,WARNING_PERCENT=5,CRITICAL_PERCENT=25
)(
    input wire clk,reset_n,spi_cs_n,spi_sck,spi_mosi,
    output wire spi_miso,
    input wire can_start,ready,input wire [7:0] status,
    input wire [31:0] frame_id,input wire [383:0] result_packet,
    output reg start_command,ack_command,
    output wire roi_command,
    output wire [7:0] sensor_level,
    output reg [31:0] ack_frame_id,
    output wire [15:0] roi_x0,roi_y0,roi_x1,roi_y1,
    output wire led_level,led_written
);
    localparam WAIT_RESULT=0,CRC=1,HELD=2,WAIT_RELEASE=3;
    reg [1:0] state;
    reg [207:0] payload;
    reg [15:0] result_crc;
    reg [4:0] crc_index;
    reg [7:0] scratch,command_status;
    wire write_valid;
    wire [15:0] write_address;
    wire [7:0] write_data;
    wire cs_seen,command_seen;
    wire adapter_busy=status[0] || state==CRC || state==WAIT_RELEASE ||
                      (ready && state==WAIT_RESULT);
    wire adapter_ready=ready && state==HELD;
    wire invalid_result=!result_packet[24] || result_packet[47:40]!=0 || result_packet[39:32]>2;
    reg [479:0] registers;
    assign sensor_level=8'hff; // Actual depth/sensor level belongs to the MCU.
    assign roi_command=1'b0;
    assign roi_x0=0;assign roi_y0=0;assign roi_x1=WIDTH;assign roi_y1=HEIGHT;
    assign led_level=1'b0;assign led_written=1'b0;
    function [15:0] crc_byte;
        input [15:0] crc;input [7:0] value;integer j;reg [15:0] c;
        begin
            c=crc^{value,8'd0};
            for(j=0;j<8;j=j+1)c=c[15] ? (c<<1)^16'h1021 : c<<1;
            crc_byte=c;
        end
    endfunction
    always @* begin
        registers=0;
        registers[0+:40]=40'h05075452AC; // paired camera ID, not old ROM ID
        registers[5*8+:8]=8'h7a; // INT8 + region + decision + camera
        registers[6*8+:8]={4'd0,1'b1,(adapter_ready && payload[22*8+:8]==3),adapter_busy,adapter_ready};
        registers[7*8+:8]=command_status;
        registers[16*8+:8]=scratch;
        if(adapter_ready)begin
            registers[32*8+:208]=payload;
            registers[58*8+:16]=result_crc;
        end
    end
    water_spi_transport transport(.clk(clk),.reset_n(reset_n),.spi_cs_n(spi_cs_n),
        .spi_sck(spi_sck),.spi_mosi(spi_mosi),.spi_miso(spi_miso),.registers(registers),
        .write_valid(write_valid),.write_address(write_address),.write_data(write_data),
        .cs_seen(cs_seen),.command_seen(command_seen));
    always @(posedge clk or negedge reset_n)begin
        if(!reset_n)begin
            state<=WAIT_RESULT;payload<=0;result_crc<=16'hffff;crc_index<=0;
            scratch<=0;command_status<=0;start_command<=0;ack_command<=0;ack_frame_id<=0;
        end else begin
            start_command<=0;ack_command<=0;
            case(state)
                WAIT_RESULT:if(ready)begin
                    // Controller holds a complete frame result until ACK.
                    payload<={(invalid_result ? 16'hffff : result_packet[192+:16]),8'h43,(invalid_result ? 8'd3 : result_packet[39:32]),
                              CRITICAL_PERCENT[7:0],WARNING_PERCENT[7:0],HEIGHT[15:0],WIDTH[15:0],
                              result_packet[160+:32],result_packet[128+:32],
                              result_packet[96+:32],result_packet[64+:32]};
                    result_crc<=16'hffff;crc_index<=0;state<=CRC;
                end
                CRC:if(!ready)state<=WAIT_RESULT;
                    else begin
                        result_crc<=crc_byte(result_crc,payload[crc_index*8+:8]);
                        if(crc_index==25)state<=HELD;else crc_index<=crc_index+1'b1;
                    end
                HELD:if(!ready)state<=WAIT_RESULT; // UART may ACK while MCU is idle.
                WAIT_RELEASE:if(!ready)state<=WAIT_RESULT;
            endcase
            if(write_valid)begin
                if(write_address==16'h10)scratch<=write_data;
                if(write_address==8)begin
                    case(write_data)
                        1:if(can_start && state==WAIT_RESULT)begin
                            start_command<=1;command_status<=0;
                        end else command_status<=1;
                        2:if(adapter_busy)command_status<=1;
                          else begin
                            command_status<=0;
                            if(adapter_ready)begin
                                ack_command<=1;ack_frame_id<=frame_id;state<=WAIT_RELEASE;
                            end
                          end
                        3:command_status<=0;
                        default:command_status<=2;
                    endcase
                end
            end
        end
    end
endmodule
