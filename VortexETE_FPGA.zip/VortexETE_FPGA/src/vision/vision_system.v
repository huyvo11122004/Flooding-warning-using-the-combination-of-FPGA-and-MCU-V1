`timescale 1ns/1ps
module vision_system #(
    parameter integer WIDTH=256,HEIGHT=256,CLK_HZ=50_000_000,
    parameter integer CAMERA_WIDTH=WIDTH,CAMERA_HEIGHT=HEIGHT,
    parameter integer WARMUP_FRAMES=10,WARNING_PERCENT=5,CRITICAL_PERCENT=25,
    parameter integer CONFIG_TIMEOUT=CLK_HZ*12,CAPTURE_TIMEOUT=CLK_HZ*12
)(
    input wire clk,reset_n,camera_clk,camera_reset_n,camera_ready,
    input wire camera_vsync,camera_href,input wire [7:0] camera_data,
    input wire spi_cs_n,spi_sck,spi_mosi,output wire spi_miso,
    output wire busy,ready,camera_awake,led_level,led_written,
    output wire [7:0] status_out
);
    wire req,done_toggle,snap_ok,engine_start,engine_done,can_start,dump_lock;
    wire [31:0] frame_id,snap_id,snap_pixels;
    wire [15:0] snap_lines;
    wire unused_engine_busy;
    wire write_valid;wire [15:0] write_address;wire [7:0] write_gray;
    wire [31:0] water_roi,roi_pixels,water_total,infer_cycles;
    wire [15:0] image_crc,mask_crc,roi_crc;
    wire [7:0] gray_min,gray_max,status;
    assign status_out=status;
    wire [15:0] roi_x0,roi_y0,roi_x1,roi_y1;
    wire spi_start,spi_ack,spi_roi;
    wire [31:0] spi_ack_id;
    wire [7:0] sensor_level;
    wire [15:0] new_x0,new_y0,new_x1,new_y1;
    wire [383:0] packet;
    wire [15:0] debug_address;
    wire [7:0] debug_gray,debug_mask,debug_roi;
    assign dump_lock=1'b0;
    assign debug_address=16'd0;
    vision_snapshot #(.WIDTH(WIDTH),.HEIGHT(HEIGHT),.WARMUP_FRAMES(WARMUP_FRAMES),
        .CAMERA_WIDTH(CAMERA_WIDTH),.CAMERA_HEIGHT(CAMERA_HEIGHT)) snapshot(
        .pclk(camera_clk),.reset_n(camera_reset_n),.camera_ready(camera_ready),
        .vsync(camera_vsync),.href(camera_href),.data(camera_data),
        .request_toggle(req),.request_id(frame_id),.done_toggle(done_toggle),.done_id(snap_id),
        .frame_ok(snap_ok),.captured_lines(snap_lines),.captured_pixels(snap_pixels),
        .write_valid(write_valid),.write_address(write_address),.write_gray(write_gray));
    vision_engine #(.WIDTH(WIDTH),.HEIGHT(HEIGHT)) engine(
        .clk(clk),.reset_n(reset_n),.camera_clk(camera_clk),.camera_write(write_valid),
        .camera_address(write_address),.camera_gray(write_gray),.start(engine_start),
        .roi_x0(roi_x0),.roi_y0(roi_y0),.roi_x1(roi_x1),.roi_y1(roi_y1),
        .busy(unused_engine_busy),.done(engine_done),.water_roi(water_roi),.roi_pixels(roi_pixels),
        .water_total(water_total),.inference_cycles(infer_cycles),
        .image_crc(image_crc),.mask_crc(mask_crc),.roi_crc(roi_crc),.gray_min(gray_min),.gray_max(gray_max),
        .debug_address(debug_address),.debug_enable(dump_lock),.debug_gray(debug_gray),.debug_mask(debug_mask),.debug_roi(debug_roi));
    vision_control #(.WIDTH(WIDTH),.HEIGHT(HEIGHT),.CLK_HZ(CLK_HZ),
        .CONFIG_TIMEOUT(CONFIG_TIMEOUT),.CAPTURE_TIMEOUT(CAPTURE_TIMEOUT),
        .WARNING_PERCENT(WARNING_PERCENT),.CRITICAL_PERCENT(CRITICAL_PERCENT)) control(
        .clk(clk),.reset_n(reset_n),.camera_ready(camera_ready),.transport_lock(dump_lock),
        .start_command(spi_start),.sensor_level(sensor_level),
        .ack_command(spi_ack),.ack_frame_id(spi_ack_id),
        .roi_command(spi_roi),.new_x0(new_x0),
        .new_y0(new_y0),.new_x1(new_x1),.new_y1(new_y1),
        .roi_x0(roi_x0),.roi_y0(roi_y0),.roi_x1(roi_x1),.roi_y1(roi_y1),
        .can_start(can_start),.ready(ready),.busy(busy),.camera_awake(camera_awake),.status(status),
        .snapshot_request(req),.frame_id(frame_id),.snapshot_done_toggle(done_toggle),
        .snapshot_id(snap_id),.snapshot_ok(snap_ok),.snapshot_lines(snap_lines),.snapshot_pixels(snap_pixels),
        .engine_start(engine_start),.engine_done(engine_done),.engine_water_roi(water_roi),
        .engine_roi_pixels(roi_pixels),.engine_water_total(water_total),.engine_cycles(infer_cycles),
        .engine_image_crc(image_crc),.engine_mask_crc(mask_crc),.engine_roi_crc(roi_crc),.engine_min(gray_min),.engine_max(gray_max),
        .result_packet(packet));
    vision_spi #(.WIDTH(WIDTH),.HEIGHT(HEIGHT),.WARNING_PERCENT(WARNING_PERCENT),.CRITICAL_PERCENT(CRITICAL_PERCENT)) spi(
        .clk(clk),.reset_n(reset_n),.spi_cs_n(spi_cs_n),.spi_sck(spi_sck),.spi_mosi(spi_mosi),.spi_miso(spi_miso),
        .can_start(can_start),.ready(ready),.status(status),.frame_id(frame_id),.result_packet(packet),
        .start_command(spi_start),.sensor_level(sensor_level),.ack_command(spi_ack),.ack_frame_id(spi_ack_id),
        .roi_command(spi_roi),.roi_x0(new_x0),.roi_y0(new_y0),.roi_x1(new_x1),.roi_y1(new_y1),
        .led_level(led_level),.led_written(led_written));
endmodule
