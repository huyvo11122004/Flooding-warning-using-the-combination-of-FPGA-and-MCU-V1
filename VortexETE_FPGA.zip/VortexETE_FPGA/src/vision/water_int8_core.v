`timescale 1ns/1ps
// Time-multiplexed 9 -> 8 ReLU -> 1 INT8 network.
// patch_u8[8*k +: 8]: raw grayscale byte; k = TL,TC,TR,ML,MC,MR,BL,BC,BR.
// Input/output use valid/ready. One patch is processed at a time.
module water_int8_core (
    input  wire        clk,
    input  wire        reset_n,
    input  wire        in_valid,
    output wire        in_ready,
    input  wire [71:0] patch_u8,
    output reg         out_valid,
    input  wire        out_ready,
    output reg         out_water,
    output reg signed [31:0] out_logit
);
    // Generated from water_int8.json; do not edit weights manually.
// SHA256: 79ecce85e3e65e24bf35eef9fc1d807c80c3a40eb7dd403e7f05d8e8568a8c84
localparam [63:0] WATER_REQUANT_MULTIPLIER = 64'd45813;
localparam integer WATER_REQUANT_SHIFT = 24;
localparam [63:0] WATER_ROUNDING_OFFSET = 64'd8388608;
localparam signed [31:0] WATER_BIAS2 = 32'h000000bf;
function signed [7:0] weight1;
    input [6:0] address;
    begin
        case (address)
            7'd0: weight1 = 8'sh02;
            7'd1: weight1 = 8'she0;
            7'd2: weight1 = 8'sh53;
            7'd3: weight1 = 8'sh14;
            7'd4: weight1 = 8'shf2;
            7'd5: weight1 = 8'shff;
            7'd6: weight1 = 8'sh1d;
            7'd7: weight1 = 8'sh06;
            7'd8: weight1 = 8'shff;
            7'd9: weight1 = 8'sh0b;
            7'd10: weight1 = 8'she6;
            7'd11: weight1 = 8'sh0c;
            7'd12: weight1 = 8'sh13;
            7'd13: weight1 = 8'sh01;
            7'd14: weight1 = 8'sh39;
            7'd15: weight1 = 8'sh0d;
            7'd16: weight1 = 8'sh01;
            7'd17: weight1 = 8'sh36;
            7'd18: weight1 = 8'shcf;
            7'd19: weight1 = 8'shbd;
            7'd20: weight1 = 8'sh0c;
            7'd21: weight1 = 8'sh00;
            7'd22: weight1 = 8'sh61;
            7'd23: weight1 = 8'sh0b;
            7'd24: weight1 = 8'shfd;
            7'd25: weight1 = 8'shc5;
            7'd26: weight1 = 8'sh58;
            7'd27: weight1 = 8'sh0b;
            7'd28: weight1 = 8'sh0c;
            7'd29: weight1 = 8'sh00;
            7'd30: weight1 = 8'sh16;
            7'd31: weight1 = 8'sh00;
            7'd32: weight1 = 8'shfc;
            7'd33: weight1 = 8'shfc;
            7'd34: weight1 = 8'shf7;
            7'd35: weight1 = 8'sh42;
            7'd36: weight1 = 8'sh0c;
            7'd37: weight1 = 8'sh00;
            7'd38: weight1 = 8'shf8;
            7'd39: weight1 = 8'sh18;
            7'd40: weight1 = 8'sh04;
            7'd41: weight1 = 8'sh4d;
            7'd42: weight1 = 8'shc5;
            7'd43: weight1 = 8'shdb;
            7'd44: weight1 = 8'sh1d;
            7'd45: weight1 = 8'sh00;
            7'd46: weight1 = 8'sh34;
            7'd47: weight1 = 8'sh1f;
            7'd48: weight1 = 8'sh05;
            7'd49: weight1 = 8'shc3;
            7'd50: weight1 = 8'sh7f;
            7'd51: weight1 = 8'sh20;
            7'd52: weight1 = 8'shea;
            7'd53: weight1 = 8'sh00;
            7'd54: weight1 = 8'sheb;
            7'd55: weight1 = 8'shee;
            7'd56: weight1 = 8'shfd;
            7'd57: weight1 = 8'sh02;
            7'd58: weight1 = 8'sh0f;
            7'd59: weight1 = 8'sh53;
            7'd60: weight1 = 8'sh04;
            7'd61: weight1 = 8'sh00;
            7'd62: weight1 = 8'shc3;
            7'd63: weight1 = 8'sh23;
            7'd64: weight1 = 8'sh04;
            7'd65: weight1 = 8'sh60;
            7'd66: weight1 = 8'shfa;
            7'd67: weight1 = 8'sh08;
            7'd68: weight1 = 8'sh24;
            7'd69: weight1 = 8'sh00;
            7'd70: weight1 = 8'shcf;
            7'd71: weight1 = 8'sh0d;
            default: weight1 = 8'd0;
        endcase
    end
endfunction
function signed [7:0] weight2;
    input [2:0] address;
    begin
        case (address)
            3'd0: weight2 = 8'shfa;
            3'd1: weight2 = 8'sh7f;
            3'd2: weight2 = 8'sh6c;
            3'd3: weight2 = 8'sh50;
            3'd4: weight2 = 8'shd0;
            3'd5: weight2 = 8'shff;
            3'd6: weight2 = 8'sh57;
            3'd7: weight2 = 8'shb8;
            default: weight2 = 8'd0;
        endcase
    end
endfunction
function signed [31:0] bias1;
    input [2:0] address;
    begin
        case (address)
            3'd0: bias1 = 32'shfffffbe1;
            3'd1: bias1 = 32'sh00001087;
            3'd2: bias1 = 32'sh00001751;
            3'd3: bias1 = 32'sh00001892;
            3'd4: bias1 = 32'sh0000231e;
            3'd5: bias1 = 32'shfffffcdb;
            3'd6: bias1 = 32'sh00000f68;
            3'd7: bias1 = 32'sh00002ce0;
            default: bias1 = 32'd0;
        endcase
    end
endfunction


    localparam [2:0] IDLE = 3'd0, MAC1 = 3'd1, RELU = 3'd2,
                     REQUANT = 3'd3, MAC2 = 3'd4, OUTPUT_HOLD = 3'd5;
    reg [2:0] state;
    reg [2:0] channel;
    reg [3:0] tap;
    reg [71:0] patch_q; // nine INT8 registers; never infer a RAM
    reg [63:0] hidden; // eight INT8 registers; never infer a RAM
    reg signed [31:0] accumulator;
    reg [63:0] requant_product;
    integer i;

    wire [6:0] weight1_address = {tap, channel}; // tap*8 + channel
    wire signed [7:0] multiply_a = (state == MAC1) ? $signed(patch_q[tap*8+:8]) : $signed(hidden[{channel,3'b000}+:8]);
    wire signed [7:0] multiply_b = (state == MAC1) ? weight1(weight1_address) : weight2(channel);
    wire signed [15:0] product = multiply_a * multiply_b;
    wire signed [31:0] product_extended = $signed({{16{product[15]}}, product});
    wire signed [31:0] accumulated = accumulator + product_extended;
    wire [63:0] shifted_activation = requant_product >> WATER_REQUANT_SHIFT;

    assign in_ready = reset_n && (state == IDLE);

    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            state <= IDLE;
            channel <= 3'd0;
            tap <= 4'd0;
            accumulator <= 32'sd0;
            requant_product <= 64'd0;
            out_valid <= 1'b0;
            out_water <= 1'b0;
            out_logit <= 32'sd0;
        end else begin
            case (state)
                IDLE: begin
                    if (in_valid) begin
                        for (i = 0; i < 9; i = i + 1)
                            // XOR changes uint8 0..255 into signed INT8 I-128.
                            patch_q[i*8+:8] <= patch_u8[i*8 +: 8] ^ 8'h80;
                        channel <= 3'd0;
                        tap <= 4'd0;
                        accumulator <= bias1(3'd0);
                        state <= MAC1;
                    end
                end
                MAC1: begin
                    accumulator <= accumulated;
                    if (tap == 4'd8)
                        state <= RELU;
                    else
                        tap <= tap + 4'd1;
                end
                RELU: begin
                    if (accumulator <= 32'sd0) begin
                        hidden[{channel,3'b000}+:8] <= 8'sd0;
                        if (channel == 3'd7) begin
                            channel <= 3'd0;
                            accumulator <= WATER_BIAS2;
                            state <= MAC2;
                        end else begin
                            channel <= channel + 3'd1;
                            tap <= 4'd0;
                            accumulator <= bias1(channel + 3'd1);
                            state <= MAC1;
                        end
                    end else begin
                        // Explicit 64-bit arithmetic avoids signed 32-bit overflow.
                        requant_product <= ({32'd0, accumulator[31:0]} * WATER_REQUANT_MULTIPLIER)
                                           + WATER_ROUNDING_OFFSET;
                        state <= REQUANT;
                    end
                end
                REQUANT: begin
                    if (shifted_activation > 64'd127)
                        hidden[{channel,3'b000}+:8] <= 8'sd127;
                    else
                        hidden[{channel,3'b000}+:8] <= {1'b0, shifted_activation[6:0]};
                    if (channel == 3'd7) begin
                        channel <= 3'd0;
                        accumulator <= WATER_BIAS2;
                        state <= MAC2;
                    end else begin
                        channel <= channel + 3'd1;
                        tap <= 4'd0;
                        accumulator <= bias1(channel + 3'd1);
                        state <= MAC1;
                    end
                end
                MAC2: begin
                    accumulator <= accumulated;
                    if (channel == 3'd7) begin
                        out_logit <= accumulated;
                        out_water <= (accumulated >= 32'sd0);
                        out_valid <= 1'b1;
                        state <= OUTPUT_HOLD;
                    end else
                        channel <= channel + 3'd1;
                end
                OUTPUT_HOLD: begin
                    if (out_ready) begin
                        out_valid <= 1'b0;
                        state <= IDLE;
                    end
                end
                default: begin
                    state <= IDLE;
                    out_valid <= 1'b0;
                end
            endcase
        end
    end
endmodule
