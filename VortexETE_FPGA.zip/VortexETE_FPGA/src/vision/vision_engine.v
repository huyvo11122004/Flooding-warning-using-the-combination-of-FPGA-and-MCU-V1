`timescale 1ns/1ps
// The camera writes one port. Once its completion handshake arrives, the
// camera holds that frame; water inference runs first over the whole image.
// ROI inference runs only if at least one water pixel was detected.
// The debug port shares the read address only while inference is idle.
module vision_engine #(
    parameter integer WIDTH=256, HEIGHT=256
)(
    input wire clk, reset_n,
    input wire camera_clk, camera_write,
    input wire [15:0] camera_address,
    input wire [7:0] camera_gray,
    input wire start,
    input wire [15:0] roi_x0,roi_y0,roi_x1,roi_y1,
    output wire busy,
    output reg done,
    output reg [31:0] water_roi,roi_pixels,water_total,inference_cycles,
    output reg [15:0] image_crc,mask_crc,roi_crc,
    output reg [7:0] gray_min,gray_max,
    input wire [15:0] debug_address,input wire debug_enable,
    output wire [7:0] debug_gray,
    output wire [7:0] debug_mask,debug_roi
);
    localparam [2:0] IDLE=0,READ_REQUEST=1,READ_CAPTURE=2,SUBMIT=3,WAIT_RESULT=4;
    localparam [31:0] FRAME_PIXELS=WIDTH*HEIGHT, MASK_BYTES=WIDTH*HEIGHT/8;
    reg [2:0] state;
    reg roi_phase;
    wire [7:0] mask_read_data;
    wire stored_water=mask_read_data[pixel_index[2:0]];
    wire [7:0] read_data;
    reg [7:0] mask_byte,roi_byte;
    reg [15:0] x,y;
    reg [4:0] tap;
    reg [151:0] features;
    wire [71:0] patch=features[71:0];
    reg signed [17:0] dx,dy;
    always @*begin
        dx=0;dy=0;
        if(tap<9)begin
            if(tap==0 || tap==3 || tap==6)dx=-18'sd1;
            if(tap==2 || tap==5 || tap==8)dx=18'sd1;
            if(tap<3)dy=-18'sd1;
            if(tap>=6)dy=18'sd1;
        end else case(tap)
            9:begin dx=-18'sd16;dy=-18'sd16;end
            10:begin dx=0;dy=-18'sd16;end
            11:begin dx=18'sd16;dy=-18'sd16;end
            12:begin dx=-18'sd16;dy=0;end
            13:begin dx=18'sd16;dy=0;end
            14:begin dx=-18'sd16;dy=18'sd16;end
            15:begin dx=0;dy=18'sd16;end
            16:begin dx=18'sd16;dy=18'sd16;end
            default:begin dx=0;dy=0;end
        endcase
    end
    wire signed [17:0] source_x=$signed({2'b0,x})+dx;
    wire signed [17:0] source_y=$signed({2'b0,y})+dy;
    wire [15:0] sx=source_x<0 ? 16'd0 : source_x>=WIDTH ? WIDTH-1 : source_x[15:0];
    wire [15:0] sy=source_y<0 ? 16'd0 : source_y>=HEIGHT ? HEIGHT-1 : source_y[15:0];
    wire [31:0] scaled_x=({16'd0,x}<<8)/WIDTH;
    wire [31:0] scaled_y=({16'd0,y}<<8)/HEIGHT;
    wire [31:0] sample_address={16'b0,sy}*WIDTH[31:0]+{16'b0,sx};
    wire [31:0] pixel_index={16'b0,y}*WIDTH[31:0]+{16'b0,x};
    wire [15:0] ram_address=busy ? sample_address[15:0] : debug_address;
    wire core_ready,core_valid,core_water,roi_ready,roi_valid,roi_bit;
    wire signed [31:0] unused_logit,roi_logit;
    wire commit_water=state==WAIT_RESULT && !roi_phase && core_valid;
    wire commit_roi=state==WAIT_RESULT && roi_phase && roi_valid;
    wire commit_pixel=commit_water || commit_roi;
    wire [7:0] packed_byte={core_water,mask_byte[6:0]};
    wire [7:0] packed_roi={roi_bit,roi_byte[6:0]};
    function [15:0] crc_byte;
        input [15:0] initial_crc;input [7:0] value;
        integer j;reg [15:0] c;
        begin
            c=initial_crc^{value,8'b0};
            for(j=0;j<8;j=j+1)c=c[15] ? (c<<1)^16'h1021 : c<<1;
            crc_byte=c;
        end
    endfunction
    // The complete validated frame is still stored with all 8 grayscale bits.
    // 32 SDPB gray +4 water mask +4 automatic ROI mask =40 banks at256x256.
    vortex_bram8 #(.DEPTH(WIDTH*HEIGHT)) frame_store(
        .write_clk(camera_clk),.write_enable(camera_write),
        .write_address(camera_address),.write_data(camera_gray),
        .read_clk(clk),.read_enable((state==READ_REQUEST || (!busy && debug_enable)) && ram_address<FRAME_PIXELS),
        .read_address(ram_address),.read_data(read_data));
    vortex_bram8 #(.DEPTH(WIDTH*HEIGHT/8)) mask_store(
        .write_clk(clk),.write_enable(commit_water && pixel_index[2:0]==7),
        .write_address({3'b0,pixel_index[15:3]}),.write_data(packed_byte),
        .read_clk(clk),.read_enable((roi_phase && state==READ_REQUEST && tap==0) ||
            (!busy && debug_enable && debug_address<MASK_BYTES)),
        .read_address(roi_phase && busy ? {3'b0,pixel_index[15:3]} : debug_address),
        .read_data(mask_read_data));
    assign debug_mask=mask_read_data;
    vortex_bram8 #(.DEPTH(WIDTH*HEIGHT/8)) roi_store(
        .write_clk(clk),.write_enable(commit_pixel && pixel_index[2:0]==7),
        .write_address({3'b0,pixel_index[15:3]}),.write_data(roi_phase ? packed_roi : 8'd0),
        .read_clk(clk),.read_enable(debug_enable && debug_address<MASK_BYTES),
        .read_address(debug_address),.read_data(debug_roi));
    assign debug_gray=read_data;
    assign busy=state!=IDLE;
    water_int8_core core(.clk(clk),.reset_n(reset_n),
        .in_valid(state==SUBMIT && !roi_phase),.in_ready(core_ready),.patch_u8(patch),
        .out_valid(core_valid),.out_ready(commit_water),
        .out_water(core_water),.out_logit(unused_logit));
    road_int8_core road_core(.clk(clk),.reset_n(reset_n),
        .in_valid(state==SUBMIT && roi_phase),.in_ready(roi_ready),.features_u8(features),
        .out_valid(roi_valid),.out_ready(commit_roi),.out_roi(roi_bit),.out_logit(roi_logit));
    always @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin
            state<=IDLE;roi_phase<=0;x<=0;y<=0;tap<=0;features<=0;done<=0;
            water_roi<=0;roi_pixels<=0;water_total<=0;inference_cycles<=0;
            image_crc<=16'hffff;mask_crc<=16'hffff;roi_crc<=16'hffff;
            gray_min<=255;gray_max<=0;mask_byte<=0;roi_byte<=0;
        end else begin
            done<=0;
            if(busy) inference_cycles<=inference_cycles+1'b1;
            case(state)
                IDLE:if(start)begin
                    state<=READ_REQUEST;roi_phase<=0;x<=0;y<=0;tap<=0;mask_byte<=0;roi_byte<=0;
                    water_roi<=0;roi_pixels<=0;water_total<=0;inference_cycles<=0;
                    image_crc<=16'hffff;mask_crc<=16'hffff;roi_crc<=16'hffff;gray_min<=255;gray_max<=0;
                end
                READ_REQUEST:state<=READ_CAPTURE;
                READ_CAPTURE:begin
                    features[tap*8+:8]<=read_data;
                    if((!roi_phase && tap==8) || (roi_phase && tap==16))begin
                        features[17*8+:8]<=scaled_x[7:0];features[18*8+:8]<=scaled_y[7:0];state<=SUBMIT;
                    end
                    else begin tap<=tap+1'b1;state<=READ_REQUEST;end
                end
                SUBMIT:if(roi_phase ? roi_ready : core_ready)begin
                    if(!roi_phase)begin
                        image_crc<=crc_byte(image_crc,patch[39:32]);
                        if(patch[39:32]<gray_min)gray_min<=patch[39:32];
                        if(patch[39:32]>gray_max)gray_max<=patch[39:32];
                    end
                    state<=WAIT_RESULT;
                end
                WAIT_RESULT:if(commit_pixel)begin
                    if(!roi_phase)begin
                        mask_byte[pixel_index[2:0]]<=core_water;
                        if(core_water)water_total<=water_total+1'b1;
                        if(pixel_index[2:0]==7)begin
                            mask_crc<=crc_byte(mask_crc,packed_byte);
                            // Clear every ROI byte while detecting water. A dry
                            // frame can never expose the previous frame's ROI.
                            roi_crc<=crc_byte(roi_crc,8'd0);
                        end
                    end else begin
                        roi_byte[pixel_index[2:0]]<=roi_bit;
                        if(pixel_index[2:0]==7)roi_crc<=crc_byte(roi_crc,packed_roi);
                        if(roi_bit)begin
                            roi_pixels<=roi_pixels+1'b1;
                            if(stored_water)water_roi<=water_roi+1'b1;
                        end
                    end
                    if(x==WIDTH[15:0]-16'd1 && y==HEIGHT[15:0]-16'd1)begin
                        // Include the final water decision before choosing the
                        // next pass. Never launch road_core on an all-dry frame.
                        if(!roi_phase && (water_total!=0 || core_water))begin
                            roi_phase<=1;x<=0;y<=0;tap<=0;roi_byte<=0;
                            roi_crc<=16'hffff;state<=READ_REQUEST;
                        end else begin state<=IDLE;done<=1;end
                    end else begin
                        if(x==WIDTH[15:0]-16'd1)begin x<=0;y<=y+1'b1;end
                        else x<=x+1'b1;
                        tap<=0;state<=READ_REQUEST;
                    end
                end
                default:state<=IDLE;
            endcase
        end
    end
endmodule
