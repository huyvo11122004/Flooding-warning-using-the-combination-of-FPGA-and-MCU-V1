`timescale 1ns/1ps
// Same request/completion contract as v7; validate source, store resized gray.
// Supported: 2<=WIDTH,HEIGHT<=256; source dimensions >= output dimensions.
module vision_snapshot #(
    parameter integer WIDTH=256,HEIGHT=256,WARMUP_FRAMES=10,
    parameter integer CAMERA_WIDTH=WIDTH,CAMERA_HEIGHT=HEIGHT
)(
    input wire pclk,reset_n,camera_ready,vsync,href,
    input wire [7:0]data,input wire request_toggle,input wire [31:0]request_id,
    output wire done_toggle,output wire [31:0]done_id,output wire frame_ok,
    output wire [15:0]captured_lines,output wire [31:0]captured_pixels,
    output wire write_valid,output wire [15:0]write_address,output wire [7:0]write_gray
);
    gray_resize_snapshot #(.IN_WIDTH(CAMERA_WIDTH),.IN_HEIGHT(CAMERA_HEIGHT),
        .OUT_WIDTH(WIDTH),.OUT_HEIGHT(HEIGHT),.WARMUP_FRAMES(WARMUP_FRAMES)) resize(
        .pclk(pclk),.reset_n(reset_n),.camera_ready(camera_ready),.vsync(vsync),.href(href),.data(data),
        .request_toggle(request_toggle),.request_id(request_id),.done_toggle(done_toggle),.done_id(done_id),
        .frame_ok(frame_ok),.captured_lines(captured_lines),.captured_pixels(captured_pixels),
        .write_valid(write_valid),.write_address(write_address),.write_gray(write_gray));
endmodule
