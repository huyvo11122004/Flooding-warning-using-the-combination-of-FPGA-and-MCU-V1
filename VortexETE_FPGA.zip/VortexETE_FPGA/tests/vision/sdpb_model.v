`timescale 1ns/1ps
// Functional SDPB model for the exact 2048x8 / bypass configuration used here.
// Test only. Do NOT add to Gowin synthesis; the vendor provides SDPB there.
module SDPB #(
    parameter integer BIT_WIDTH_0=8,BIT_WIDTH_1=8,
    parameter READ_MODE=1'b0,BLK_SEL_0=3'b000,BLK_SEL_1=3'b000,
    parameter RESET_MODE="SYNC"
)(
    output reg [31:0] DO,input wire [31:0] DI,
    input wire CLKA,CLKB,CEA,CEB,OCE,RESET,
    input wire [13:0] ADA,ADB,input wire [2:0] BLKSELA,BLKSELB
);
    reg [7:0] mem[0:2047];
    initial begin
        if(BIT_WIDTH_0!=8 || BIT_WIDTH_1!=8 || READ_MODE!=0)
            $fatal(1,"SDPB test model only covers 2048x8 bypass");
    end
    always @(posedge CLKA)if(CEA && BLKSELA==BLK_SEL_0)
        mem[ADA[13:3]]<=DI[7:0];
    always @(posedge CLKB)if(RESET)DO<=0;
        else if(CEB && BLKSELB==BLK_SEL_1)DO<={24'b0,mem[ADB[13:3]]};
endmodule
