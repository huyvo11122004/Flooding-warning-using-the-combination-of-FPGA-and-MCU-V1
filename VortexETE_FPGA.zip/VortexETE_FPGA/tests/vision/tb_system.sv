`timescale 1ns/1ps
module tb_system;
reg clk=0,pclk=0,rst=0,penable=1,configured=1,vs=0,hr=0;
reg [7:0] data=0;
reg cs=1,sck=0,mosi=0;
wire miso,busy,ready,awake;
always #10 clk=~clk;
always begin #40;if(penable)pclk=~pclk;end
vision_system #(.WIDTH(8),.HEIGHT(8),.CLK_HZ(50_000_000),.CAMERA_WIDTH(20),.CAMERA_HEIGHT(14),
 .WARMUP_FRAMES(1),.CONFIG_TIMEOUT(1000000),.CAPTURE_TIMEOUT(1000000)) dut(
 .clk(clk),.reset_n(rst),.camera_clk(pclk),.camera_reset_n(rst),.camera_ready(configured && awake),
 .camera_vsync(vs),.camera_href(hr),.camera_data(data),
 .spi_cs_n(cs),.spi_sck(sck),.spi_mosi(mosi),.spi_miso(miso),
 .busy(busy),.ready(ready),.camera_awake(awake),.led_level(),.led_written());
reg [15:0] rgb[0:63];reg [7:0] gray[0:63],labels[0:63],packed_expected[0:7],roi_expected[0:7],packet[0:47];
integer malformed=0,scene=0,y,x,k,j,f;
reg [7:0] value,uvalue;
reg [31:0] first_id;
reg [15:0] source_pixel;
// Embed the 8x8 reference scene at the exact 20x14 endpoint sampling sites.
// Unselected source pixels differ deliberately, detecting incorrect resizing.
function [15:0] source_rgb(input integer sx,input integer sy);
 integer dx,dy,ix,iy;
 begin
  ix=-1;iy=-1;
  for(dx=0;dx<8;dx=dx+1)if(sx==dx*19/7)ix=dx;
  for(dy=0;dy<8;dy=dy+1)if(sy==dy*13/7)iy=dy;
  source_rgb=(ix>=0 && iy>=0) ? rgb[iy*8+ix] : 16'hf81f;
 end
endfunction
task tick;begin @(negedge pclk);end endtask
// Camera source deliberately keeps its clock independent of the logic clock.
initial begin
 $readmemh("tests/vision/vectors/auto_small_anh_goc/rgb.mem",rgb);
 $readmemh("tests/vision/vectors/auto_small_anh_goc/input.mem",gray);
 $readmemh("tests/vision/vectors/auto_small_anh_goc/labels.mem",labels);
 $readmemh("tests/vision/vectors/auto_small_anh_goc/mask.mem",packed_expected);
 $readmemh("tests/vision/vectors/auto_small_anh_goc/roi_mask.mem",roi_expected);
 forever begin
  wait(rst && awake);tick;vs=1;hr=0;repeat(8)tick;vs=0;repeat(8)tick;
  for(y=0;y<14;y=y+1)begin
   hr=1;
   // One short line and one long line preserve total pixels but must FAIL.
   for(x=0;x<(malformed ? (y==0 ? 19 : y==1 ? 21 : 20) : 20);x=x+1)begin
    source_pixel=source_rgb(x,y);data=source_pixel[15:8];tick;data=source_pixel[7:0];tick;
   end
   hr=0;repeat(8)tick;
  end
  repeat(8)tick;
 end
end
task select_bus;begin cs=0;#3000;end endtask
task release_bus;begin #3000;cs=1;sck=0;#3000;end endtask
task transfer(input[7:0]tx,output[7:0]rx);integer b;begin
 rx=0;for(b=7;b>=0;b=b-1)begin
  mosi=tx[b];#5000;sck=1;#1;rx[b]=miso;#4999;sck=0;
 end #3000;
end endtask

reg [7:0] registers[0:59];
reg [7:0] saved[0:59];
reg [15:0] calc_crc;
reg [31:0] expected_water;
function [31:0] le32(input integer at);
 begin le32={registers[at+3],registers[at+2],registers[at+1],registers[at]};end
endfunction
task write_reg(input[15:0]address,input[7:0]v);begin
 select_bus;transfer(2,value);transfer(address[15:8],value);transfer(address[7:0],value);
 transfer(v,value);release_bus;
end endtask
task read_regs;begin
 select_bus;transfer(3,value);transfer(0,value);transfer(0,value);transfer(0,value);
 for(j=0;j<60;j=j+1)transfer(0,registers[j]);release_bus;
end endtask
task start_spi;begin
 write_reg(8,1);
 if(dut.spi.command_status!==0)$fatal(1,"START rejected");
end endtask
task wait_result;begin wait(dut.spi.adapter_ready);read_regs;end endtask
task check_crc;integer a,b;begin
 calc_crc=16'hffff;
 for(a=32;a<58;a=a+1)begin
  calc_crc=calc_crc^{registers[a],8'd0};
  for(b=0;b<8;b=b+1)calc_crc=calc_crc[15]?(calc_crc<<1)^16'h1021:calc_crc<<1;
 end
 if({registers[59],registers[58]}!==calc_crc)$fatal(1,"SPI payload CRC mismatch");
end endtask
task acknowledge;begin
 write_reg(8,2);if(ready || dut.spi.adapter_ready)$fatal(1,"ACK failed");
end endtask
initial begin
 #1;rst=0;#100;rst=1;#5000;
 read_regs;
 if(registers[0]!==8'hac || registers[4]!==5 || registers[5]!==8'h7a || registers[6]!==8)
  $fatal(1,"Camera ID/capabilities/idle status");
 if(dut.roi_x0!=0 || dut.roi_y0!=0 || dut.roi_x1!=8 || dut.roi_y1!=8)
  $fatal(1,"Default must cover the entire captured image");
 for(k=0;k<6;k=k+1)begin
  case(k)0:uvalue=0;1:uvalue=255;2:uvalue=85;3:uvalue=170;4:uvalue=90;5:uvalue=165;endcase
  write_reg(16,uvalue);read_regs;
  if(registers[16]!==uvalue)$fatal(1,"Scratch echo mismatch");
 end
 // Incomplete register writes and Flash B9 cannot launch a scan.
 select_bus;transfer(2,value);transfer(0,value);transfer(8,value);release_bus;
 select_bus;transfer(8'hb9,value);release_bus;
 if(dut.frame_id!=0)$fatal(1,"Partial write/Flash sleep launched capture");
 select_bus;transfer(8'h9f,value);transfer(0,value);if(value!==8'ha5)$fatal(1,"Legacy ID A5");
 transfer(0,value);if(value!==8'h5a)$fatal(1,"Legacy ID 5A");
 transfer(0,value);if(value!==8'h12)$fatal(1,"Legacy ID 12");
 transfer(0,value);if(value!==8'h34)$fatal(1,"Legacy ID 34");release_bus;
 start_spi;wait_result;check_crc;
 expected_water=17;
 if(registers[6]!==9 || registers[54]!==2 || registers[55]!==8'h43 ||
    le32(36)!==expected_water || le32(40)!==27 || le32(44)!==42)
  $fatal(1,"Counts must come from camera/INT8, got water=%0d area=%0d",le32(36),le32(40));
 if({registers[57],registers[56]}!==16'd6296)$fatal(1,"FPGA 17/27 percentage not transmitted");
 if(awake)$fatal(1,"Camera not asleep after snapshot");
 first_id=le32(32);
 for(k=0;k<60;k=k+1)saved[k]=registers[k];
 write_reg(8,1);if(dut.spi.command_status!==1)$fatal(1,"Held START not rejected");
 write_reg(8,3);read_regs;
 for(k=32;k<60;k=k+1)if(registers[k]!==saved[k])$fatal(1,"Held result changed");
 // Verify the exact resized bytes and the automatically computed masks.
 if(dut.snap_pixels!=280 || dut.snap_lines!=14)$fatal(1,"source geometry must be 20x14");
 force dut.dump_lock=1'b1;
 for(k=0;k<64;k=k+1)begin
  force dut.debug_address=k;repeat(3)@(negedge clk);
  if(dut.debug_gray!==gray[k])$fatal(1,"resized gray differs at %0d",k);
 end
 for(k=0;k<8;k=k+1)begin
  force dut.debug_address=k;repeat(3)@(negedge clk);
  if(dut.debug_mask!==packed_expected[k] || dut.debug_roi!==roi_expected[k])
   $fatal(1,"auto ROI or water mask differs at %0d",k);
 end
 release dut.debug_address;release dut.dump_lock;
 acknowledge;
 // Change camera pixels, not ROM/files/weights; counts and level must change.
 $readmemh("tests/vision/vectors/auto_small_khong_ngap_binh_dong/rgb.mem",rgb);
 scene=1;start_spi;wait_result;check_crc;
 if(le32(32)!==first_id+1 || le32(36)!==0 || le32(40)!==19 || le32(44)!==35 || registers[54]!==0 || {registers[57],registers[56]}!==0)
  $fatal(1,"New camera scene did not change the result water=%0d level=%0d",le32(36),registers[54]);
 acknowledge;
 // Valid dry scene: no road inference, no previous ROI and no 0/0 divide.
 $readmemh("tests/vision/vectors/water_first/dry_rgb.mem",rgb);
 start_spi;wait_result;check_crc;
 if(le32(36)!==0 || le32(40)!==0 || le32(44)!==0 || registers[54]!==0 ||
    {registers[57],registers[56]}!==0 || registers[6]!==9)
  $fatal(1,"No-water/ROI-skipped packet not valid Normal");
 force dut.dump_lock=1'b1;
 for(k=0;k<8;k=k+1)begin
  force dut.debug_address=k;repeat(3)@(negedge clk);
  if(dut.debug_roi!==0 || dut.debug_mask!==0)$fatal(1,"Old ROI leaked through no-water frame");
 end
 release dut.debug_address;release dut.dump_lock;
 acknowledge;
 $readmemh("tests/vision/vectors/auto_small_anh_goc/rgb.mem",rgb);
 scene=0;malformed=1;start_spi;wait_result;check_crc;
 if(registers[6]!==13 || registers[54]!==3 || le32(36)!==0)
  $fatal(1,"Bad geometry accepted as valid");
 acknowledge;malformed=0;
 penable=0;start_spi;wait_result;check_crc;
 if(registers[6]!==13 || registers[54]!==3 || le32(40)!==0)$fatal(1,"Missing PCLK not reported");
 acknowledge;penable=1;
 configured=0;start_spi;wait_result;check_crc;
 if(registers[6]!==13 || registers[54]!==3)$fatal(1,"Config timeout not reported");
 acknowledge;configured=1;
 start_spi;wait(busy);#100;rst=0;#200;rst=1;#1000;
 if(ready || busy || awake || dut.spi.adapter_ready)$fatal(1,"Reset did not clear job");
 $display("PASS real register SPI + independent DVP + INT8: new camera scenes change ROI area27->19 and waterROI17->0, Critical->Normal; learned automatic ROI; six scratch patterns; transmitted FPGA percentage62.96->0.00 percent with level2->0, CRC/hold/ACK; 20x14 DVP resized to 8x8 exact gray/water/ROI masks over SPI-only system; dry no-water skips ROI/clears old masks with valid Normal packet; malformed geometry/config/missing-PCLK errors");
 $finish;
end
initial begin #300000000;$fatal(1,"System watchdog");end
endmodule
