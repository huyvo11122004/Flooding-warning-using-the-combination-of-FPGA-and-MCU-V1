`timescale 1ns/1ps
module tb_water_first;
reg clk=0,camclk=0,rst=0,start=0,write=0,debug=0;
always #10 clk=~clk;always #17 camclk=~camclk;
reg[15:0]wa=0,da=0;reg[7:0]wd=0;
wire busy,done;wire[31:0]wr,rp,wt,cycles;wire[15:0]ic,mc,rc;wire[7:0]dg,dm,dr;
vision_engine #(.WIDTH(8),.HEIGHT(8)) dut(.clk(clk),.reset_n(rst),.camera_clk(camclk),
 .camera_write(write),.camera_address(wa),.camera_gray(wd),.start(start),
 .roi_x0(16'd0),.roi_y0(16'd0),.roi_x1(16'd8),.roi_y1(16'd8),
 .busy(busy),.done(done),.water_roi(wr),.roi_pixels(rp),.water_total(wt),.inference_cycles(cycles),
 .image_crc(ic),.mask_crc(mc),.roi_crc(rc),.gray_min(),.gray_max(),
 .debug_address(da),.debug_enable(debug),.debug_gray(dg),.debug_mask(dm),.debug_roi(dr));
reg[7:0]image[0:63],water[0:63],roi[0:63];
integer wc=0,roc=0,launches=0,i,j,expected_wr,expected_rp,expected_wt;
reg[7:0]expected_m,expected_r;reg[15:0]expected_ic,expected_mc,expected_rc;
function[15:0]crc(input[15:0]c0,input[7:0]v);integer k;reg[15:0]c;begin
 c=c0^{v,8'd0};for(k=0;k<8;k=k+1)c=c[15]?(c<<1)^16'h1021:c<<1;crc=c;end endfunction
always @(posedge clk)if(rst)begin
 if(dut.road_core.in_valid && dut.roi_ready)launches=launches+1;
 if(dut.commit_water)begin
  if(roc || dut.core_water!==water[wc][0])$fatal(1,"water pass differs or ROI ran too soon pixel%0d",wc);
  wc=wc+1;
 end
 if(dut.commit_roi)begin
  if(wc!=64 || dut.roi_bit!==roi[roc][0])$fatal(1,"ROI pass mismatch pixel%0d",roc);
  roc=roc+1;
 end
end
task run_scene(input integer dry,input integer final_only);begin
 debug=0;wc=0;roc=0;launches=0;
 if(dry || final_only)begin
  if(dry)begin
   $readmemh("tests/vision/vectors/water_first/dry.mem",image);
   $readmemh("tests/vision/vectors/water_first/dry_water.mem",water);
   $readmemh("tests/vision/vectors/water_first/dry_roi.mem",roi);
  end else begin
   $readmemh("tests/vision/vectors/water_first/last_only.mem",image);
   $readmemh("tests/vision/vectors/water_first/last_only_water.mem",water);
   $readmemh("tests/vision/vectors/water_first/last_only_roi.mem",roi);
  end
 end else begin
  $readmemh("tests/vision/vectors/auto_small_anh_goc/input.mem",image);
  $readmemh("tests/vision/vectors/auto_small_anh_goc/labels.mem",water);
  $readmemh("tests/vision/vectors/auto_small_anh_goc/roi.mem",roi);
 end
 for(i=0;i<64;i=i+1)begin @(negedge camclk);write=1;wa=i;wd=image[i];end
 @(negedge camclk);write=0;
 @(negedge clk);start=1;@(negedge clk);start=0;
 wait(done);@(negedge clk);
 if(wc!=64 || (dry ? roc!=0 || launches!=0 : roc!=64 || launches!=64))
  $fatal(1,"unexpected number of water/ROI evaluations %0d/%0d, launches%0d",wc,roc,launches);
 expected_wr=0;expected_rp=0;expected_wt=0;
 expected_ic=16'hffff;expected_mc=16'hffff;expected_rc=16'hffff;
 for(i=0;i<64;i=i+1)begin
  expected_wt=expected_wt+water[i];expected_rp=expected_rp+roi[i];expected_wr=expected_wr+(water[i]&roi[i]);
  expected_ic=crc(expected_ic,image[i]);
 end
 if(wt!=expected_wt || rp!=expected_rp || wr!=expected_wr)$fatal(1,"count mismatch");
 if(final_only && wt!=1)$fatal(1,"last-pixel-water case was not exercised");
 debug=1;
 for(i=0;i<8;i=i+1)begin
  expected_m=0;expected_r=0;
  for(j=0;j<8;j=j+1)begin expected_m[j]=water[i*8+j][0];expected_r[j]=roi[i*8+j][0];end
  expected_mc=crc(expected_mc,expected_m);expected_rc=crc(expected_rc,expected_r);
  da=i;repeat(3)@(negedge clk);
  if(dm!==expected_m || dr!==expected_r)$fatal(1,"mask byte mismatch, old ROI leaked at %0d",i);
 end
 if(ic!==expected_ic || mc!==expected_mc || rc!==expected_rc)$fatal(1,"CRC mismatch");
 $display("PASS water-first scene dry=%0d last_only=%0d: water%0d ROI%0d intersection%0d, %0d ROI launches, masks/CRCs exact",dry,final_only,wt,rp,wr,launches);
end endtask
initial begin
 #1;rst=0;#100;rst=1;
 run_scene(0,0);run_scene(1,0);run_scene(0,1);run_scene(1,0);run_scene(0,0);
 $display("PASS no ROI invocation on dry frames, wet/dry/wet reuse, last-pixel water launches ROI, all independent mask/CRC checks");$finish;
end
initial begin #10000000;$fatal(1,"water-first watchdog");end
endmodule
