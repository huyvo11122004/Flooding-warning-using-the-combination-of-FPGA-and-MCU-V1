`timescale 1ns/1ps
module tb_control;
reg clk=0,rst=0,cam=0,lock=0,start=0,ack=0,rcmd=0,sdone=0,sok=1,edone=0;
always #10 clk=~clk;
reg [31:0] ackid=0,sid=0,water=0,area=10000,total=30000;
reg [7:0] sensor=1,minimum=10,maximum=240;
reg [15:0] nx0=0,ny0=0,nx1=256,ny1=256;
wire req,es,can_start,ready,busy,awake;wire [31:0] fid;wire[383:0]packet;
wire[15:0]x0,y0,x1,y1;
integer clock_tick=0,trigger_tick=0;
reg ready_d=0;
always @(posedge clk)begin
 if(!rst)begin clock_tick=0;trigger_tick=0;ready_d=0;end
 else begin
  clock_tick=clock_tick+1;
  if(start && can_start)trigger_tick=clock_tick;
  if(ready && !ready_d && packet[240+:32]!==clock_tick-trigger_tick-1)
   $fatal(1,"Trigger-to-READY cycle count mismatch got=%0d expected=%0d",packet[240+:32],clock_tick-trigger_tick-1);
  ready_d=ready;
 end
end
vision_control #(.CONFIG_TIMEOUT(100),.CAPTURE_TIMEOUT(100)) dut(
 .clk(clk),.reset_n(rst),.camera_ready(cam),.transport_lock(lock),
 .start_command(start),.sensor_level(sensor),.ack_command(ack),.ack_frame_id(ackid),
 .roi_command(rcmd),.new_x0(nx0),.new_y0(ny0),.new_x1(nx1),.new_y1(ny1),
 .roi_x0(x0),.roi_y0(y0),.roi_x1(x1),.roi_y1(y1),.can_start(can_start),
 .ready(ready),.busy(busy),.camera_awake(awake),.status(),.snapshot_request(req),.frame_id(fid),
 .snapshot_done_toggle(sdone),.snapshot_id(sid),.snapshot_ok(sok),
 .snapshot_lines(16'd256),.snapshot_pixels(32'd65536),.engine_start(es),.engine_done(edone),
 .engine_water_roi(water),.engine_roi_pixels(area),.engine_water_total(total),
 .engine_cycles(32'd123),.engine_image_crc(16'h1234),.engine_mask_crc(16'h5678),.engine_roi_crc(16'h9012),
 .engine_min(minimum),.engine_max(maximum),.result_packet(packet));
function [15:0] crc(input[367:0]p);integer i,j;reg[15:0]c;begin
 c=65535;for(i=0;i<46;i=i+1)begin c=c^{p[i*8+:8],8'b0};
 for(j=0;j<8;j=j+1)c=c[15]?(c<<1)^16'h1021:c<<1;end crc=c;end endfunction
task kick;begin @(negedge clk);start=1;@(negedge clk);start=0;end endtask
task acknowledge(input[31:0]id);begin @(negedge clk);ackid=id;ack=1;@(negedge clk);ack=0;end endtask
task check_packet(input[7:0]level,err);reg[383:0]copy;begin
 wait(ready);@(negedge clk);
 if(packet[32+:8]!==level || packet[40+:8]!==err)$fatal(1,"Wrong result level/error %h",packet);
 if(err==0 && (packet[304+:16]!==16'h9012 || !packet[29] || packet[27]))$fatal(1,"Auto ROI CRC/flags metadata");
 if(packet[368+:16]!==crc(packet[367:0]))$fatal(1,"Packet CRC mismatch");
 copy=packet;kick;repeat(4)@(negedge clk);
 if(packet!==copy || !ready)$fatal(1,"Result overwritten without ACK");
 acknowledge(fid+1);if(!ready)$fatal(1,"Wrong ACK cleared result");
 acknowledge(fid);if(ready)$fatal(1,"Correct ACK failed");
end endtask
task inference(input integer w,input[7:0]level);begin
 water=w;cam=1;kick;wait(dut.state==2);repeat(4)@(negedge clk);
 sid=fid;sdone=~sdone;wait(es);@(negedge clk);edone=1;@(negedge clk);edone=0;
 wait(ready);if(packet[192+:16]!==w)$fatal(1,"Restoring divider mismatch");
 check_packet(level,0);
end endtask
initial begin
 #1;rst=0;#100;rst=1;
 lock=1;kick;if(fid!=0)$fatal(1,"Dump lock ignored");lock=0;
 // Legacy rectangle commands must not replace automatic scene ROI.
 nx0=3;ny0=4;nx1=2;ny1=8;rcmd=1;@(negedge clk);rcmd=0;
 if(x0!=0 || y0!=0 || x1!=256 || y1!=256)$fatal(1,"Auto ROI policy changed by legacy command");
 inference(499,0);inference(500,1);inference(2499,1);inference(2500,2);inference(10000,2);
 sensor=2;inference(2500,2);if(!awake)$fatal(1,"Critical stream not retained after ACK");
 sensor=0;inference(499,0);if(awake)$fatal(1,"Normal job did not return camera to sleep");
 area=100;water=1;cam=1;kick;wait(dut.state==2);repeat(4)@(negedge clk);
 sid=fid;sdone=~sdone;wait(es);@(negedge clk);edone=1;@(negedge clk);edone=0;
 check_packet(255,6);
 // No detected water intentionally skips ROI and never divides 0/0.
 area=0;water=0;total=0;kick;wait(dut.state==2);repeat(4)@(negedge clk);
 sid=fid;sdone=~sdone;wait(es);@(negedge clk);edone=1;@(negedge clk);edone=0;
 wait(ready);if(packet[192+:16]!==0)$fatal(1,"dry coverage convention");check_packet(0,0);
 // A flat/invalid dry input must remain Unknown, never a successful skip.
 maximum=minimum;kick;wait(dut.state==2);repeat(4)@(negedge clk);
 sid=fid;sdone=~sdone;wait(es);@(negedge clk);edone=1;@(negedge clk);edone=0;
 check_packet(255,5);maximum=240;
 total=30000;
 area=0;water=0;kick;wait(dut.state==2);repeat(4)@(negedge clk);
 sid=fid;sdone=~sdone;wait(es);@(negedge clk);edone=1;@(negedge clk);edone=0;
 check_packet(255,4);area=10000;
 maximum=minimum;kick;wait(dut.state==2);repeat(4)@(negedge clk);
 sid=fid;sdone=~sdone;wait(es);@(negedge clk);edone=1;@(negedge clk);edone=0;
 check_packet(255,5);maximum=240;
 cam=0;repeat(4)@(negedge clk);kick;check_packet(255,1);
 cam=1;kick;check_packet(255,2);
 // A late result from the timed-out job must not authorize inference.
 sid=fid;sdone=~sdone;repeat(6)@(negedge clk);if(es)$fatal(1,"Late capture accepted");
 kick;wait(dut.state==2);sid=fid-1;sdone=~sdone;repeat(6)@(negedge clk);
 if(dut.state!=2)$fatal(1,"Wrong frame ID accepted");
 sid=fid;sok=0;sdone=~sdone;check_packet(255,3);sok=1;
 $display("PASS controller: 4.99/5/24.99/25/100 percent, sequential divider, automatic ROI policy, small/empty ROI and low-contrast rejection, CRC, hold/ACK, dump lock, config/capture timeouts and stale-frame rejection");
 $finish;
end
initial begin #2000000;$fatal(1,"Control watchdog");end
endmodule
