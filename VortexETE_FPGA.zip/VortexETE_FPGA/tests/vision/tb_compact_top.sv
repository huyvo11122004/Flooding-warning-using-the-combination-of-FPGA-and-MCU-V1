`timescale 1ns/1ps
module tb_compact_top;
reg clk=0,pclk=0,rst=0,cs=1,sck=0,mosi=0;
always #10 clk=~clk;always #25 pclk=~pclk;
wire miso,pwdn,ddr_rst;wire[3:0]led;tri1 sda;
vortex_camera_ai_compact dut(.clk50M(clk),.reset_n(rst),.camera_sdat(sda),
 .camera_vsync(1'b0),.camera_href(1'b0),.camera_pclk(pclk),.camera_data(8'b0),
 .spi_cs_n(cs),.spi_sck(sck),.spi_mosi(mosi),.spi_miso(miso),
 .camera_pwdn(pwdn),.led(led),.O_ddr_reset_n(ddr_rst));
integer mclk_edges=0;
always @(posedge dut.camera_xclk)if(rst)mclk_edges=mclk_edges+1;
reg[7:0]received;
task transfer(input[7:0]v,output[7:0]r);integer j;begin
 r=0;for(j=7;j>=0;j=j-1)begin mosi=v[j];#5000;sck=1;#1;r[j]=miso;#4999;sck=0;end
 #3000;
end endtask
initial begin
 #1;rst=0;#100;rst=1;#1000000;
 if(ddr_rst!==0 || !pwdn || dut.vision_busy || dut.vision_ready)$fatal(1,"Compact idle/reset/sleep");
 if(!led[0] || mclk_edges<24995 || mclk_edges>25005)$fatal(1,"PLL/camera clock");
 if(dut.camera_init.IMAGE_WIDTH!=640 || dut.camera_init.IMAGE_HEIGHT!=480 ||
    dut.vision.snapshot.resize.IN_WIDTH!=640 || dut.vision.snapshot.resize.OUT_WIDTH!=256)
    $fatal(1,"Camera VGA and destination dimensions disagree");
 if(dut.vision.engine.frame_store.BANKS!=32 || dut.vision.engine.mask_store.BANKS!=4 ||
    dut.vision.engine.roi_store.BANKS!=4)$fatal(1,"Unexpected RAM topology");
 cs=0;#3000;transfer(8'h9f,received);transfer(0,received);
 if(received!==8'ha5)$fatal(1,"SPI ID");cs=1;#5000;
 // State forcing tests wiring only; functional jobs run in tb_system.
 @(negedge clk);force dut.vision.control.state=4'd7;
 #100;if(led[2:1]!==2'b10 || !pwdn)$fatal(1,"HOLD LEDs/sleep");
 @(negedge clk);force dut.vision.control.state=4'd1;
 #100;if(led[2:1]!==2'b01 || pwdn)$fatal(1,"WAKE LEDs/power");
 release dut.vision.control.state;
 rst=0;#100;if(led!==0 || ddr_rst!==0)$fatal(1,"Compact reset");
 $display("PASS standalone top: full VGA config -> 256x256 resize, 40 RAM banks, SPI ID, sleep/LEDs/reset, no UART/HDMI");$finish;
end
initial begin #3000000;$fatal(1,"Compact top watchdog");end
endmodule
