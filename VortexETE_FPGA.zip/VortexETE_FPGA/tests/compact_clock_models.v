`timescale 1ns/1ps
// Functional clock models only; not vendor PLL/clock timing simulation.
module Gowin_PLL(input clkin,reset,output lock,clkout0,clkout1,clkout2);
reg mclk=0;always @(posedge clkin or posedge reset)if(reset)mclk<=0;else mclk<=~mclk;
reg fast=0;always #2.5 fast=~fast;
assign clkout2=mclk;assign clkout0=fast;assign clkout1=clkin;assign lock=~reset;
endmodule
module CLKDIV(input HCLKIN,RESETN,CALIB,output CLKOUT);
parameter DIV_MODE="5";
integer n=0;reg q=0;
always @(posedge HCLKIN or negedge HCLKIN or negedge RESETN)
 if(!RESETN)begin n<=0;q<=0;end
 else if(n==4)begin n<=0;q<=~q;end else n<=n+1;
assign CLKOUT=q;
endmodule
