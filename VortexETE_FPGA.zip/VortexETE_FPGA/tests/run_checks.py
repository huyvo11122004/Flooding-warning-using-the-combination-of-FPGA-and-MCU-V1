"""Portable checks for the actual enabled SPI/camera project; no Gowin P&R claim."""
from pathlib import Path
import subprocess
import tempfile
import sys
import shutil
R=Path(__file__).resolve().parents[1]
for tool in ('iverilog','vvp'):
    if not shutil.which(tool):
        raise SystemExit('Install Icarus Verilog and put iverilog/vvp on PATH')
subprocess.run([sys.executable,str(R/'tests/run_water_first_checks.py')],check=True)
camera=['src/camera_init/camera_init.v','src/camera_init/i2c_control/i2c_control.v',
        'src/camera_init/i2c_control/i2c_bit_shift.v','src/camera_init/ov5640_init_table_rgb.v',
        'src/camera_init/ov5640_init_table_jpeg.v']
vision=[str(p.relative_to(R)) for p in sorted((R/'src/vision').glob('*.v'))]
tests=[('tb_resize_capture',['tests/tb_resize_capture.sv','src/vision/gray_resize_snapshot.v']),
       ('tb_vga_table',['tests/tb_vga_table.sv','src/camera_init/ov5640_init_table_rgb.v']),
       ('tb_camera_config',['tests/tb_camera_config.v',*camera]),
       ('tb_compact_top',['tests/vision/tb_compact_top.sv','tests/vision/sdpb_model.v',
                          'tests/compact_clock_models.v','src/reset_release.v',
                          'src/compact/vortex_camera_ai_compact.v',*camera,*vision])]
with tempfile.TemporaryDirectory() as tmp:
    for top,files in tests:
        out=str(Path(tmp)/top)
        subprocess.run(['iverilog','-g2012','-s',top,'-o',out,*files],cwd=R,check=True)
        subprocess.run(['vvp',out],cwd=R,check=True)
print('PASS FPGA: water-first, control, integrated SPI/capture, VGA resize, SCCB, top wiring')
