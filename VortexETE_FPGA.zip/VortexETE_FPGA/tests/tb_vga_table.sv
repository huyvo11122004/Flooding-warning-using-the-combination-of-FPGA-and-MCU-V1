`timescale 1ns/1ps
module tb_vga_table;
 reg clk=0;reg[7:0]addr=0;wire[23:0]q;
 always #5 clk=~clk;
 ov5640_init_table_rgb #(.IMAGE_WIDTH(640),.IMAGE_HEIGHT(480)) dut(.clk(clk),.addr(addr),.q(q));
 task check(input[7:0]a,input[23:0]v);begin
  @(negedge clk);addr=a;@(posedge clk);#1;if(q!==v)$fatal(1,"table addr %d = %h != %h",a,q,v);
 end endtask
 initial begin
  check(56,24'h430061);check(57,24'h501f01);
  check(211,24'h382041);check(218,24'h380304);check(221,24'h380607);check(222,24'h38079b);
  check(223,24'h380802);check(224,24'h380980);check(225,24'h380a01);check(226,24'h380be0);
  check(228,24'h380d68);check(229,24'h380e03);check(230,24'h380fd8);check(231,24'h381306);
  check(249,24'h5001a3);check(254,24'h300802);
  $display("PASS full VGA window/timing, 640x480 output, RGB565, ISP scaling enabled");$finish;
 end
endmodule
