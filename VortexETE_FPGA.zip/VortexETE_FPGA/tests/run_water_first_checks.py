"""Functional checks for water-first gating, no Gowin/ARM timing claim."""
from pathlib import Path
import subprocess,tempfile
R=Path(__file__).resolve().parents[1]
sources=sorted((R/'src/vision').glob('*.v'))+[R/'tests/vision/sdpb_model.v']
with tempfile.TemporaryDirectory() as tmp:
 for top in ['tb_water_first','tb_control','tb_system']:
  out=str(Path(tmp)/top)
  subprocess.run(['iverilog','-g2012','-s',top,'-o',out,str(R/f'tests/vision/{top}.sv'),*map(str,sources)],cwd=R,check=True)
  subprocess.run(['vvp',out],cwd=R,check=True)
