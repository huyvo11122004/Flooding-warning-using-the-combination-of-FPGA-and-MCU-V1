`timescale 1ns/1ps
module tb_camera_config;
 reg clk=0,reset_n=0,accept=0;
 always #5 clk=~clk;
 tri1 sda;
 wire scl,done,ack_seen,nack_seen,cam_reset,pwdn,verify_failed;
 wire [7:0] index,value,expected;
 wire [15:0] chipid,readaddr;
 reg slave_low=0,active=0,reading=0;
 integer bits=0,byte_index=0,writes=0,reads=0,i;
 reg [7:0] rx=0,hi;
 reg [15:0] pointer=0;
 reg [7:0] mem[0:65535];
 reg w_hi_ok=0,w_lo_ok=0,h_hi_ok=0,h_lo_ok=0;
 assign sda=slave_low ? 1'b0 : 1'bz;
 camera_init #(.SYS_CLOCK(1000000),.SCL_CLOCK(100000),
     .IMAGE_WIDTH(640),.IMAGE_HEIGHT(480)) dut(
     .Clk(clk),.Rst_n(reset_n),.Init_Done(done),
     .Ack_Seen(ack_seen),.Nack_Seen(nack_seen),.Debug_Index(index),
     .Debug_ChipId(chipid),.Debug_ReadAddr(readaddr),.Debug_ReadValue(value),
     .Debug_Expected(expected),.Verify_Failed(verify_failed),
     .camera_rst_n(cam_reset),.camera_pwdn(pwdn),.i2c_sclk(scl),.i2c_sdat(sda));
 always @(negedge sda) if(scl && reset_n) begin
     active=1;bits=0;byte_index=0;rx=0;reading=0;
 end
 always @(posedge sda) if(scl && reset_n) begin active=0;slave_low=0;end
 always @(posedge scl) if(active) begin
     if(bits<8 && !(reading && byte_index==1)) begin
         rx={rx[6:0],sda};
         if(bits==7) case(byte_index)
             0: begin
                 if(rx!==8'h78 && rx!==8'h79) $fatal(1,"Wrong SCCB address %h",rx);
                 reading=rx[0];if(reading) reads=reads+1;
             end
             1:hi=rx;
             2:pointer={hi,rx};
             3: if(accept) begin
                 writes=writes+1;
                 // Inject a faulty readback even though the write is ACKed.
                 mem[pointer]=(pointer==16'h3036) ? 8'h55 : rx;
                 case(pointer)
                     16'h3808:begin if(rx!==8'h02)$fatal;w_hi_ok=1;end
                     16'h3809:begin if(rx!==8'h80)$fatal;w_lo_ok=1;end
                     16'h380a:begin if(rx!==8'h01)$fatal;h_hi_ok=1;end
                     16'h380b:begin if(rx!==8'he0)$fatal;h_lo_ok=1;end
                 endcase
             end
         endcase
     end
     bits=bits+1;
 end
 always @(negedge scl) if(active) begin
     if(bits==8) slave_low=(reading && byte_index==1) ? 0 : accept;
     else if(bits==9) begin
         bits=0;byte_index=byte_index+1;
         slave_low=(reading && byte_index==1) ? !mem[pointer][7] : 0;
     end else if(reading && byte_index==1) slave_low=!mem[pointer][7-bits];
 end
 initial begin
     for(i=0;i<65536;i=i+1)mem[i]=0;
     mem[16'h300b]=8'h40; // High ID byte intentionally wrong first.
     #20;reset_n=1;
     wait(nack_seen);repeat(20)@(negedge clk);
     if(done || ack_seen || index!==0)$fatal(1,"NACK must retry same entry");
     accept=1;
     wait(verify_failed);
     if(done || readaddr!==16'h300a || value!==0 || expected!==8'h56)
         $fatal(1,"Wrong sensor ID must block capture");
     mem[16'h300a]=8'h56;
     wait(readaddr==16'h3036 && value==8'h55);
     if(done)$fatal(1,"ACKed but wrong register must block capture");
     mem[16'h3036]=8'h54;
     wait(done);repeat(5)@(negedge clk);
     if(!ack_seen || !nack_seen || !cam_reset || pwdn || chipid!==16'h5640)
         $fatal(1,"Bad final diagnostics chipid=%h",chipid);
     if(!w_hi_ok || !w_lo_ok || !h_hi_ok || !h_lo_ok)$fatal(1,"Wrong dimensions");
     if(writes!=255 || mem[16'h3035]!==8'h81 || mem[16'h503d]!==0 || mem[16'h3008]!==2)
         $fatal(1,"Slow live-image profile not applied");
     $display("PASS: serial SCCB 255 writes + 17-register readback; wrong ID, corrupt ACKed register and NACK all block completion; retry recovers, chip ID 5640");
     $finish;
 end
 initial begin #15000000;$fatal(1,"Configuration timeout index=%0d addr=%h value=%h",index,readaddr,value);end
endmodule
