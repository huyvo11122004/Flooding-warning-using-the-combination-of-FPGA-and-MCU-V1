`timescale 1ns/1ps
// End-to-end DVP resize test: complete VGA, edge coverage, invalid geometry.
module tb_resize_capture;
 reg pclk=0,reset_n=0,vs=0,href=0,camera_ready=1,request=0;
 reg[7:0]data=0;reg[31:0]id=0;
 wire done_toggle,ok,wvalid;wire[31:0]done_id,pixels;wire[15:0]lines,waddr;wire[7:0]gray;
 always #5 pclk=~pclk;
 gray_resize_snapshot #(.WARMUP_FRAMES(0)) dut(.pclk(pclk),.reset_n(reset_n),
 .camera_ready(camera_ready),.vsync(vs),.href(href),.data(data),.request_toggle(request),.request_id(id),
 .done_toggle(done_toggle),.done_id(done_id),.frame_ok(ok),.captured_lines(lines),.captured_pixels(pixels),
 .write_valid(wvalid),.write_address(waddr),.write_gray(gray));
 integer count=0,last_x=0,last_y=0;reg check_pixels=0;
 function[15:0]pattern(input integer x,input integer y);
  begin pattern=((x>>3)<<11)|((y>>2)<<5)|(((x+y)&255)>>3);end
 endfunction
 function[7:0]expected(input integer x,input integer y);
  integer r,g,b;reg[15:0]p;begin p=pattern(x,y);
   r={p[15:11],p[15:13]};g={p[10:5],p[10:9]};b={p[4:0],p[4:2]};
   expected=(77*r+150*g+29*b+128)>>8;
  end
 endfunction
 always @(posedge pclk)if(wvalid)begin
  if(check_pixels)begin
   if(waddr!==count[15:0])$fatal(1,"not contiguous output");
   if(gray!==expected(((count%256)*639)/255,((count/256)*479)/255))
    $fatal(1,"wrong resize pixel %0d",count);
  end
  if(count==65535)begin last_x=dut.target_x;last_y=dut.target_y;end
  count=count+1;
 end
 task frame(input integer nr_lines,input integer bad_line,input integer bad_width,input integer odd_tail);
  integer x,y,w;reg[15:0]p;reg before_done;
  begin
   count=0;before_done=done_toggle;
   @(negedge pclk);id=id+1;request=~request;href=0;vs=0;
   repeat(5)@(negedge pclk);
   vs=1;repeat(4)@(negedge pclk);vs=0;
   for(y=0;y<nr_lines;y=y+1)begin
    w=y==bad_line ? bad_width : 640;
    for(x=0;x<w;x=x+1)begin
     p=pattern(x,y);href=1;data=p[15:8];@(negedge pclk);data=p[7:0];@(negedge pclk);
    end
    if(y==bad_line && odd_tail)begin data=0;@(negedge pclk);end
    href=0;repeat(3)@(negedge pclk);
   end
   repeat(4)@(negedge pclk);vs=1;repeat(4)@(negedge pclk);vs=0;
   if(done_toggle==before_done || done_id!=id)$fatal(1,"missing capture completion");
  end
 endtask
 initial begin
  #30;reset_n=1;repeat(5)@(negedge pclk);
  check_pixels=1;frame(480,-1,0,0);check_pixels=0;
  if(!ok || count!=65536 || lines!=480 || pixels!=307200)$fatal(1,"complete VGA rejected");
  if(last_x!=639 || last_y!=479)$fatal(1,"last source edge not reached");
  $display("PASS all 65536 resized pixels, including four VGA corners");
  frame(479,-1,0,0);if(ok)$fatal(1,"truncated frame accepted");
  frame(481,-1,0,0);if(ok)$fatal(1,"extra line accepted");
  frame(480,200,639,0);if(ok)$fatal(1,"short row accepted");
  frame(480,200,640,1);if(ok)$fatal(1,"odd byte row accepted");
  $display("PASS short/extra frame, short row and odd byte rejected");$finish;
 end
 initial begin #100000000;$fatal(1,"capture test timeout");end
endmodule
